<div class="btn-group" role="group">
    <!-- Bouton Éditer -->
    <button type="button" 
            class="btn btn-sm btn-info edit-client-btn" 
            data-id="<?php echo e($client->id); ?>"
            data-bs-toggle="tooltip" 
            title="Modifier">
        <i class="bi bi-pencil"></i>
    </button>
    
    <!-- Bouton Activer/Désactiver -->
    <?php if($client->is_active): ?>
        <button type="button" 
                class="btn btn-sm btn-warning toggle-status-btn" 
                data-id="<?php echo e($client->id); ?>"
                data-action="deactivate"
                data-bs-toggle="tooltip" 
                title="Désactiver">
            <i class="bi bi-toggle-off"></i>
        </button>
    <?php else: ?>
        <button type="button" 
                class="btn btn-sm btn-success toggle-status-btn" 
                data-id="<?php echo e($client->id); ?>"
                data-action="activate"
                data-bs-toggle="tooltip" 
                title="Activer">
            <i class="bi bi-toggle-on"></i>
        </button>
    <?php endif; ?>
    
    <!-- Bouton Supprimer - Ouvre directement la modal -->
    <button type="button" 
            class="btn btn-sm btn-danger delete-client-trigger" 
            data-id="<?php echo e($client->id); ?>"
            data-name="<?php echo e($client->raison_sociale); ?>"
            data-bs-toggle="modal" 
            data-bs-target="#deleteClientModal"
            data-bs-toggle="tooltip" 
            title="Supprimer">
        <i class="bi bi-trash"></i>
    </button>
</div><?php /**PATH D:\My Project\CheckTime\resources\views/clients/partials/actions.blade.php ENDPATH**/ ?>