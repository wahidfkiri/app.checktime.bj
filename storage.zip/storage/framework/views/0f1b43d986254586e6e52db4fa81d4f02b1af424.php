[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\My Project\CheckTime-Client\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>