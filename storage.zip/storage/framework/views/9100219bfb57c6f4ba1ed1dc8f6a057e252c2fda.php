

<?php $__env->startSection('content'); ?>
<div id="main" class="layout-navbar navbar-fixed">
    <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = App\View\Components\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
    <div id="main-content">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Liste des employés</h3>
                        <p class="text-subtitle text-muted">
                            <span id="sync-status">Chargement...</span>
                            <span id="last-sync-info" class="badge bg-light text-dark ms-2"></span>
                        </p>
                    </div>
                    <div class="col-12 col-md-6 order-md-2 order-first">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active">Employés</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <section class="section">
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-end">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="zone_filter" class="form-label">Zone</label>
                                    <select class="form-select" id="zone_filter">
                                        <option value="">Toutes les zones</option>
                                        <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($zone->area_id); ?>"><?php echo e($zone->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="status_filter" class="form-label">Statut</label>
                                    <select class="form-select" id="status_filter">
                                        <option value="">Tous</option>
                                        <option value="active">Actif</option>
                                        <option value="inactive">Inactif</option>
                                        <option value="suspended">Suspendu</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="emp_code_filter" class="form-label">Code employé</label>
                                    <input type="text" class="form-control" id="emp_code_filter" placeholder="Code...">
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group text-start">
                                    <label class="form-label d-block">&nbsp;</label>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-success" id="create-employee-button" data-bs-toggle="modal" data-bs-target="#createEmployeeModal">
                                            <i class="bi bi-plus-circle me-1"></i> Créer
                                        </button>
                                        <button type="button" class="btn btn-primary" id="sync_button">
                                            <i class="bi bi-arrow-repeat me-1"></i> Synchroniser
                                        </button>
                                        <button type="button" class="btn btn-secondary" id="reset_filters">
                                            <i class="bi bi-x-circle me-1"></i> Reset Filtres
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <div class="alert alert-light border" id="sync-status-container" style="display: none;">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <strong>Client:</strong> <span id="client-name"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Dernière synchro:</strong> <span id="last-sync"></span>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Total employés:</strong> <span id="total-employees"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-info alert-dismissible fade show d-none" id="sync-alert" role="alert">
                            <div class="d-flex align-items-center">
                                <div class="spinner-border spinner-border-sm me-2" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <strong>Synchronisation en cours...</strong> Veuillez patienter.
                            </div>
                        </div>
                        
                        <div class="table-responsive">
                            <table id="employees-table" class="table table-striped table-hover dt-responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Code</th>
                                        <th>Nom complet</th>
                                        <th>Zone</th>
                                        <th>Département</th>
                                        <th>Téléphone</th>
                                        <th>Email</th>
                                        <th>Statut</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Les données seront chargées via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<!-- Modal de création d'employé -->
<div class="modal fade" id="createEmployeeModal" tabindex="-1" aria-labelledby="createEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createEmployeeModalLabel">Créer un nouvel employé</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="createEmployeeForm">
                <div class="modal-body">
                    <div class="row">
                        <!-- <div class="col-md-12">
                            <div class="mb-3">
                                <label for="emp_code" class="form-label">Code employé <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="emp_code" name="emp_code" required maxlength="50">
                                <div class="invalid-feedback" id="emp_code-error"></div>
                            </div>
                        </div> -->
                        <div class="col-md-6 d-none">
                            <div class="mb-3">
                                <label for="status" class="form-label">Statut <span class="text-danger">*</span></label>
                                <select class="form-select" id="status" name="status">
                                    <option value="">Sélectionner un statut</option>
                                    <option value="active">Actif</option>
                                    <option value="inactive">Inactif</option>
                                    <option value="suspended">Suspendu</option>
                                </select>
                                <div class="invalid-feedback" id="status-error"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="first_name" class="form-label">Prénom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="first_name" name="first_name" required maxlength="100">
                                <div class="invalid-feedback" id="first_name-error"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="last_name" class="form-label">Nom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="last_name" name="last_name" required maxlength="100">
                                <div class="invalid-feedback" id="last_name-error"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" maxlength="255">
                                <div class="invalid-feedback" id="email-error"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="phone" class="form-label">Téléphone</label>
                                <input type="text" class="form-control" id="phone" name="phone" maxlength="20">
                                <div class="invalid-feedback" id="phone-error"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="area_id" class="form-label">Zone</label>
                                <select class="form-select" id="area_id" name="area_id">
                                    <option value="">Sélectionner une zone</option>
                                    <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($zone->area_id); ?>"><?php echo e($zone->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback" id="area_id-error"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="department_id" class="form-label">Département</label>
                                <select class="form-select" id="department_id" name="department_id">
                                    <option value="">Sélectionner un département</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->department_id); ?>"><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback" id="department_id-error"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="address" class="form-label">Adresse</label>
                        <textarea class="form-control" id="address" name="address" rows="2" maxlength="500"></textarea>
                        <div class="invalid-feedback" id="address-error"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary" id="submit-create-employee">
                        <span id="create-employee-text">Créer</span>
                        <span id="create-employee-spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal d'édition d'employé -->
<div class="modal fade" id="editEmployeeModal" tabindex="-1" aria-labelledby="editEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editEmployeeModalLabel">Modifier l'employé</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editEmployeeForm">
                <input type="hidden" id="edit_employee_id" name="id">
                <div class="modal-body">
                    <div class="row">
                        <!-- <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_emp_code" class="form-label">Code employé <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="edit_emp_code" name="emp_code" required maxlength="50">
                                <div class="invalid-feedback" id="edit_emp_code-error"></div>
                            </div>
                        </div> -->
                        <!-- <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_status" class="form-label">Statut <span class="text-danger">*</span></label>
                                <select class="form-select" id="edit_status" name="status" required>
                                    <option value="">Sélectionner un statut</option>
                                    <option value="active">Actif</option>
                                    <option value="inactive">Inactif</option>
                                    <option value="suspended">Suspendu</option>
                                </select>
                                <div class="invalid-feedback" id="edit_status-error"></div>
                            </div>
                        </div> -->
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_first_name" class="form-label">Prénom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="edit_first_name" name="first_name" required maxlength="100">
                                <div class="invalid-feedback" id="edit_first_name-error"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_last_name" class="form-label">Nom <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="edit_last_name" name="last_name" required maxlength="100">
                                <div class="invalid-feedback" id="edit_last_name-error"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="edit_email" name="email" maxlength="255">
                                <div class="invalid-feedback" id="edit_email-error"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_phone" class="form-label">Téléphone</label>
                                <input type="text" class="form-control" id="edit_phone" name="phone" maxlength="20">
                                <div class="invalid-feedback" id="edit_phone-error"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_area_id" class="form-label">Zone</label>
                                <select class="form-select" id="edit_area_id" name="area_id">
                                    <option value="">Sélectionner une zone</option>
                                    <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($zone->area_id); ?>"><?php echo e($zone->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback" id="edit_area_id-error"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_department_id" class="form-label">Département</label>
                                <select class="form-select" id="edit_department_id" name="department_id">
                                    <option value="">Sélectionner un département</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->department_id); ?>"><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="invalid-feedback" id="edit_department_id-error"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_address" class="form-label">Adresse</label>
                        <textarea class="form-control" id="edit_address" name="address" rows="2" maxlength="500"></textarea>
                        <div class="invalid-feedback" id="edit_address-error"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary" id="submit-edit-employee">
                        <span id="edit-employee-text">Enregistrer</span>
                        <span id="edit-employee-spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal de suppression d'employé -->
<div class="modal fade" id="deleteEmployeeModal" tabindex="-1" aria-labelledby="deleteEmployeeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteEmployeeModalLabel">Confirmer la suppression</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Êtes-vous sûr de vouloir supprimer cet employé ?</p>
                <p><strong>Code:</strong> <span id="delete-employee-code"></span></p>
                <p><strong>Nom complet:</strong> <span id="delete-employee-name"></span></p>
                <p class="text-danger"><small>Cette action est irréversible.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                <button type="button" class="btn btn-danger" id="confirm-delete-employee">
                    <span id="delete-employee-text">Supprimer</span>
                    <span id="delete-employee-spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    // Variables globales
    let employeeToDelete = null;
    let departmentsCache = {};
    
    // Charger le statut de synchronisation
    loadSyncStatus();
    
    // Initialiser DataTable
    var table = $('#employees-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('employees.local')); ?>",
            data: function (d) {
                d.zone_id = $('#zone_filter').val();
                d.emp_code = $('#emp_code_filter').val();
                d.name = $('#name_filter').val();
                d.status = $('#status_filter').val();
            }
        },
        columns: [
            { 
                data: 'emp_code', 
                name: 'emp_code',
                width: '10%'
            },
            { 
                data: 'full_name', 
                name: 'full_name',
                width: '20%'
            },
            { 
                data: 'area_name', 
                name: 'area_name',
                width: '15%'
            },
            { 
                data: 'dept_name', 
                name: 'dept_name',
                width: '15%'
            },
            { 
                data: 'phone', 
                name: 'phone',
                width: '10%'
            },
            { 
                data: 'email', 
                name: 'email',
                width: '15%'
            },
            { 
                data: 'status_badge', 
                name: 'status',
                width: '10%'
            },
            {
                data: null, 
                orderable: false,
                searchable: false,
                width: '5%',
                render: function(data, type, row) {
                    return `
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-warning edit-employee-btn" 
                                data-id="${row.employee_id}"
                                data-emp_code="${row.emp_code}"
                                data-first_name="${row.first_name}"
                                data-last_name="${row.last_name}"
                                data-email="${row.email}"
                                data-phone="${row.phone}"
                                data-area_id="${row.area_id}"
                                data-department_id="${row.department_id}"
                                data-status="${row.status}"
                                data-address="${row.address || ''}">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-danger delete-employee-btn" 
                                data-id="${row.employee_id}"
                                data-emp_code="${row.emp_code}"
                                data-full_name="${row.full_name}">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        language: {
            url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/French.json"
        },
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Tous"]],
        order: [[1, 'asc']],
        responsive: true,
        drawCallback: function(settings) {
            var api = this.api();
            var pageInfo = api.page.info();
            $('.dataTables_info').html(
                'Affichage de ' + (pageInfo.start + 1) + ' à ' + 
                pageInfo.end + ' sur ' + pageInfo.recordsTotal + ' entrées'
            );
            
            // Réattacher les événements après le redessinage du tableau
            attachActionButtons();
        }
    });

    // Attacher les événements aux boutons d'action
    function attachActionButtons() {
        // Bouton d'édition
        $('.edit-employee-btn').off('click').on('click', function() {
            const employeeData = {
                id: $(this).data('id'),
                emp_code: $(this).data('emp_code'),
                first_name: $(this).data('first_name'),
                last_name: $(this).data('last_name'),
                email: $(this).data('email'),
                phone: $(this).data('phone'),
                area_id: $(this).data('area_id'),
                department_id: $(this).data('department_id'),
                status: $(this).data('status'),
                address: $(this).data('address')
            };
            
            openEditModal(employeeData);
        });
        
        // Bouton de suppression
        $('.delete-employee-btn').off('click').on('click', function() {
            const employeeId = $(this).data('id');
            const empCode = $(this).data('emp_code');
            const fullName = $(this).data('full_name');
            
            openDeleteModal(employeeId, empCode, fullName);
        });
    }
    
    // Charger les départements pour une zone
    function loadDepartmentsForZone(zoneId, targetSelect, selectedId = null) {
        if (departmentsCache[zoneId]) {
            populateDepartmentSelect(targetSelect, departmentsCache[zoneId], selectedId);
            return;
        }
        
        $.ajax({
            url: "<?php echo e(url('departments/by-zone')); ?>/" + zoneId,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    departmentsCache[zoneId] = response.data;
                    populateDepartmentSelect(targetSelect, response.data, selectedId);
                }
            },
            error: function() {
                // En cas d'erreur, laisser le select vide
                $(targetSelect).html('<option value="">Sélectionner un département</option>');
            }
        });
    }
    
    // Remplir le select des départements
    function populateDepartmentSelect(selectElement, departments, selectedId = null) {
        let html = '<option value="">Sélectionner un département</option>';
        
        departments.forEach(function(department) {
            const selected = department.id == selectedId ? 'selected' : '';
            html += `<option value="${department.id}" ${selected}>${department.name}</option>`;
        });
        
        $(selectElement).html(html);
    }
    
    // Ouvrir la modal d'édition
    function openEditModal(employeeData) {
        // Remplir les champs du formulaire
        $('#edit_employee_id').val(employeeData.id);
        $('#edit_emp_code').val(employeeData.emp_code);
        $('#edit_first_name').val(employeeData.first_name);
        $('#edit_last_name').val(employeeData.last_name);
        $('#edit_email').val(employeeData.email);
        $('#edit_phone').val(employeeData.phone);
        $('#edit_status').val(employeeData.status);
        $('#edit_address').val(employeeData.address);
        
        // Sélectionner la zone
        $('#edit_area_id').val(employeeData.area_id);
        
        // Charger les départements pour la zone sélectionnée
        // if (employeeData.area_id) {
        //     loadDepartmentsForZone(employeeData.area_id, '#edit_department_id', employeeData.department_id);
        // } else {
        //     $('#edit_department_id').html('<option value="">Sélectionner un département</option>');
        // }
        
        // Réinitialiser les erreurs
        $('.is-invalid').removeClass('is-invalid');
        $('.invalid-feedback').text('');
        
        $('#editEmployeeModal').modal('show');
    }
    
    // Ouvrir la modal de suppression
    function openDeleteModal(id, empCode, fullName) {
        employeeToDelete = id;
        $('#delete-employee-code').text(empCode);
        $('#delete-employee-name').text(fullName);
        $('#deleteEmployeeModal').modal('show');
    }
    
    // Événement lors du changement de zone dans le formulaire de création
    // $('#area_id').on('change', function() {
    //     const zoneId = $(this).val();
    //     if (zoneId) {
    //         loadDepartmentsForZone(zoneId, '#department_id');
    //     } else {
    //         $('#department_id').html('<option value="">Sélectionner un département</option>');
    //     }
    // });
    
    // Événement lors du changement de zone dans le formulaire d'édition
    // $('#edit_area_id').on('change', function() {
    //     const zoneId = $(this).val();
    //     if (zoneId) {
    //         loadDepartmentsForZone(zoneId, '#edit_department_id');
    //     } else {
    //         $('#edit_department_id').html('<option value="">Sélectionner un département</option>');
    //     }
    // });
    
    // Appliquer les filtres
    function applyFilters() {
        table.ajax.reload();
    }

    // Événements pour les filtres avec debounce
    var filterTimeout;
    $('#zone_filter, #status_filter').on('change', function() {
        applyFilters();
    });
    
    $('#emp_code_filter').on('keyup', function() {
        clearTimeout(filterTimeout);
        filterTimeout = setTimeout(applyFilters, 500);
    });

    // Réinitialiser les filtres
    $('#reset_filters').on('click', function() {
        $('#zone_filter').val('');
        $('#emp_code_filter').val('');
        $('#name_filter').val('');
        $('#status_filter').val('');
        applyFilters();
    });

    // Synchronisation normale
    $('#sync_button').on('click', function() {
        performSync(false);
    });
    
    // Reset et Sync
    $('#reset_sync').on('click', function() {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Tous les employés seront supprimés et resynchronisés. Cette action est irréversible.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, continuer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                performSync(true);
            }
        });
    });
    
    function performSync(reset = false) {
        var $button = reset ? $('#reset_sync') : $('#sync_button');
        var originalText = $button.html();
        var action = reset ? 'reset-sync' : 'sync';
        
        $button.prop('disabled', true).html('<i class="bi bi-arrow-repeat spin"></i> En cours...');
        $('#sync-alert').removeClass('d-none');
        
        $.ajax({
            url: "<?php echo e(url('employees')); ?>/" + action,
            type: 'POST',
            data: {
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(response) {
                if (response.success) {
                    showSweetAlert('success', 
                        reset ? 'Reset & Sync réussi' : 'Synchronisation réussie', 
                        response.message
                    );
                    
                    // Recharger les données et le statut
                    table.ajax.reload();
                    setTimeout(function() {
                        loadSyncStatus();
                    }, 1000);
                } else {
                    showSweetAlert('error', 
                        'Erreur', 
                        response.message
                    );
                }
            },
            error: function(xhr) {
                showSweetAlert('error', 
                    'Erreur', 
                    'Erreur lors de l\'opération. ' + 
                    (xhr.responseJSON?.error || 'Veuillez réessayer ultérieurement.')
                );
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
                $('#sync-alert').addClass('d-none');
            }
        });
    }
    
    // Charger le statut de synchronisation
    function loadSyncStatus() {
        $.ajax({
            url: "<?php echo e(url('employees/sync-status')); ?>",
            type: 'GET',
            success: function(response) {
                if (response.client_name !== 'Non associé') {
                    $('#sync-status-container').show();
                    $('#client-name').text(response.client_name);
                    $('#last-sync').text(response.last_sync);
                    $('#total-employees').text(response.total_employees);
                }
                updateSyncStatusUI(response);
            }
        });
    }

    function updateSyncStatusUI(status) {
        var statusText = 'Synchronisé';
        var statusClass = 'text-success';
        var badgeClass = 'bg-success';
        var badgeText = 'À jour';
        
        if (!status.last_sync || status.last_sync === 'Jamais') {
            statusText = 'Jamais synchronisé';
            statusClass = 'text-danger';
            badgeClass = 'bg-danger';
            badgeText = 'Non sync';
        }
        
        $('#sync-status').html(statusText).removeClass('text-danger text-warning text-success').addClass(statusClass);
        $('#last-sync-info').html(badgeText).removeClass('bg-danger bg-warning bg-success bg-info bg-light').addClass(badgeClass);
    }
    
    // Gestion de la création d'employé
    $('#createEmployeeForm').on('submit', function(e) {
        e.preventDefault();
        
        // Récupérer les données du formulaire
        var formData = {
            emp_code: $('#emp_code').val(),
            first_name: $('#first_name').val(),
            last_name: $('#last_name').val(),
            email: $('#email').val(),
            phone: $('#phone').val(),
            area_id: $('#area_id').val(),
            department_id: $('#department_id').val(),
            status: $('#status').val(),
            address: $('#address').val(),
            _token: "<?php echo e(csrf_token()); ?>"
        };
        
        // Désactiver le bouton et afficher le spinner
        $('#submit-create-employee').prop('disabled', true);
        $('#create-employee-text').addClass('d-none');
        $('#create-employee-spinner').removeClass('d-none');
        
        // Réinitialiser les erreurs
        $('.is-invalid').removeClass('is-invalid');
        $('.invalid-feedback').text('');
        
        // Envoyer la requête AJAX
        $.ajax({
            url: "<?php echo e(route('employees.store')); ?>",
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    // Fermer la modal
                    $('#createEmployeeModal').modal('hide');
                    
                    // Réinitialiser le formulaire
                    $('#createEmployeeForm')[0].reset();
                    $('#department_id').html('<option value="">Sélectionner un département</option>');
                    
                    // Afficher un message de succès
                    Swal.fire({
                        icon: 'success',
                        title: 'Succès',
                        text: response.message || 'Employé créé avec succès',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    
                    // Recharger le tableau
                    table.ajax.reload();
                    
                    // Mettre à jour le statut de synchronisation
                    loadSyncStatus();
                } else {
                    // Afficher les erreurs
                    showSweetAlert('error', 'Erreur', response.message);
                }
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    // Validation errors
                    var errors = xhr.responseJSON.errors;
                    $.each(errors, function(key, value) {
                        var input = $('#' + key);
                        input.addClass('is-invalid');
                        input.next('.invalid-feedback').text(value[0]);
                    });
                } else {
                    showSweetAlert('error', 'Erreur', 
                        'Une erreur est survenue lors de la création. ' + 
                        (xhr.responseJSON?.message || 'Veuillez réessayer.')
                    );
                }
            },
            complete: function() {
                // Réactiver le bouton
                $('#submit-create-employee').prop('disabled', false);
                $('#create-employee-text').removeClass('d-none');
                $('#create-employee-spinner').addClass('d-none');
            }
        });
    });
    
    // Gestion de l'édition d'employé
    $('#editEmployeeForm').on('submit', function(e) {
        e.preventDefault();
        
        const employeeId = $('#edit_employee_id').val();
        
        // Récupérer les données du formulaire
        var formData = {
            emp_code: $('#edit_emp_code').val(),
            first_name: $('#edit_first_name').val(),
            last_name: $('#edit_last_name').val(),
            email: $('#edit_email').val(),
            phone: $('#edit_phone').val(),
            area_id: $('#edit_area_id').val(),
            department_id: $('#edit_department_id').val(),
            status: $('#edit_status').val(),
            address: $('#edit_address').val(),
            _token: "<?php echo e(csrf_token()); ?>"
        };
        
        // Désactiver le bouton et afficher le spinner
        $('#submit-edit-employee').prop('disabled', true);
        $('#edit-employee-text').addClass('d-none');
        $('#edit-employee-spinner').removeClass('d-none');
        
        // Réinitialiser les erreurs
        $('.is-invalid').removeClass('is-invalid');
        $('.invalid-feedback').text('');
        
        // Envoyer la requête AJAX
        $.ajax({
            url: "<?php echo e(url('employees')); ?>/" + employeeId,
            type: 'PUT',
            data: formData,
            success: function(response) {
                if (response.success) {
                    // Fermer la modal
                    $('#editEmployeeModal').modal('hide');
                    
                    // Afficher un message de succès
                    Swal.fire({
                        icon: 'success',
                        title: 'Succès',
                        text: response.message || 'Employé modifié avec succès',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    
                    // Recharger le tableau
                    table.ajax.reload();
                    
                    // Mettre à jour le statut de synchronisation
                    loadSyncStatus();
                } else {
                    // Afficher les erreurs
                    showSweetAlert('error', 'Erreur', response.message);
                }
            },
            error: function(xhr) {
                if (xhr.status === 422) {
                    // Validation errors
                    var errors = xhr.responseJSON.errors;
                    $.each(errors, function(key, value) {
                        var input = $('#edit_' + key);
                        input.addClass('is-invalid');
                        input.next('.invalid-feedback').text(value[0]);
                    });
                } else {
                    showSweetAlert('error', 'Erreur', 
                        'Une erreur est survenue lors de la modification. ' + 
                        (xhr.responseJSON?.message || 'Veuillez réessayer.')
                    );
                }
            },
            complete: function() {
                // Réactiver le bouton
                $('#submit-edit-employee').prop('disabled', false);
                $('#edit-employee-text').removeClass('d-none');
                $('#edit-employee-spinner').addClass('d-none');
            }
        });
    });
    
    // Gestion de la suppression d'employé
    $('#confirm-delete-employee').on('click', function() {
        if (!employeeToDelete) return;
        
        // Désactiver le bouton et afficher le spinner
        $(this).prop('disabled', true);
        $('#delete-employee-text').addClass('d-none');
        $('#delete-employee-spinner').removeClass('d-none');
        
        // Envoyer la requête AJAX
        $.ajax({
            url: "<?php echo e(url('employees')); ?>/" + employeeToDelete,
            type: 'DELETE',
            data: {
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(response) {
                if (response.success) {
                    // Fermer la modal
                    $('#deleteEmployeeModal').modal('hide');
                    
                    // Réinitialiser la variable
                    employeeToDelete = null;
                    
                    // Afficher un message de succès
                    Swal.fire({
                        icon: 'success',
                        title: 'Succès',
                        text: response.message || 'Employé supprimé avec succès',
                        timer: 3000,
                        showConfirmButton: false
                    });
                    
                    // Recharger le tableau
                    table.ajax.reload();
                    
                    // Mettre à jour le statut de synchronisation
                    loadSyncStatus();
                } else {
                    // Afficher les erreurs
                    showSweetAlert('error', 'Erreur', response.message);
                    
                    // Fermer la modal
                    $('#deleteEmployeeModal').modal('hide');
                }
            },
            error: function(xhr) {
                showSweetAlert('error', 'Erreur', 
                    'Une erreur est survenue lors de la suppression. ' + 
                    (xhr.responseJSON?.message || 'Veuillez réessayer.')
                );
                
                // Fermer la modal
                $('#deleteEmployeeModal').modal('hide');
            },
            complete: function() {
                // Réactiver le bouton
                $('#confirm-delete-employee').prop('disabled', false);
                $('#delete-employee-text').removeClass('d-none');
                $('#delete-employee-spinner').addClass('d-none');
            }
        });
    });
    
    // Réinitialiser le formulaire quand la modal de création se ferme
    $('#createEmployeeModal').on('hidden.bs.modal', function() {
        $('#createEmployeeForm')[0].reset();
        $('#department_id').html('<option value="">Sélectionner un département</option>');
        $('.is-invalid').removeClass('is-invalid');
        $('.invalid-feedback').text('');
        $('#submit-create-employee').prop('disabled', false);
        $('#create-employee-text').removeClass('d-none');
        $('#create-employee-spinner').addClass('d-none');
    });
    
    // Réinitialiser quand la modal d'édition se ferme
    $('#editEmployeeModal').on('hidden.bs.modal', function() {
        $('#submit-edit-employee').prop('disabled', false);
        $('#edit-employee-text').removeClass('d-none');
        $('#edit-employee-spinner').addClass('d-none');
    });
    
    // Réinitialiser quand la modal de suppression se ferme
    $('#deleteEmployeeModal').on('hidden.bs.modal', function() {
        employeeToDelete = null;
        $('#confirm-delete-employee').prop('disabled', false);
        $('#delete-employee-text').removeClass('d-none');
        $('#delete-employee-spinner').addClass('d-none');
    });
    
    function showSweetAlert(icon, title, text, timer = null) {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: timer || 5000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });
        
        Toast.fire({
            icon: icon,
            title: title,
            text: text
        });
    }

    // Vérifier périodiquement le statut
    setInterval(loadSyncStatus, 30000);

    $('<style>')
        .text('.spin { animation: spin 1s linear infinite; } @keyframes spin { 100% { transform: rotate(360deg); } }')
        .appendTo('head');
});
</script>
<style>
    .dataTables_wrapper {
        padding: 10px 0;
    }
    .dataTables_length,
    .dataTables_filter {
        margin-bottom: 15px;
    }
    .dataTables_filter input {
        margin-left: 10px;
    }
    .dt-responsive {
        width: 100% !important;
    }
    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }
    .btn-group .btn {
        margin-right: 5px;
        border-radius: 4px !important;
    }
    .badge {
        font-size: 0.75em;
        padding: 0.35em 0.65em;
    }
    #sync-alert {
        margin-bottom: 1rem;
    }
    #sync-status-container {
        background-color: #f8f9fa;
        border-left: 4px solid #0d6efd;
    }
    #create-employee-button {
        background-color: #198754;
        border-color: #198754;
    }
    #create-employee-button:hover {
        background-color: #157347;
        border-color: #146c43;
    }
    .modal-content {
        border-radius: 10px;
    }
    .modal-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
        border-radius: 10px 10px 0 0;
    }
    .modal-title {
        color: #333;
        font-weight: 600;
    }
    .btn-group .btn-sm {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
    .btn-warning {
        background-color: #ffc107;
        border-color: #ffc107;
    }
    .btn-warning:hover {
        background-color: #e0a800;
        border-color: #d39e00;
    }
    .modal-lg {
        max-width: 800px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\CheckTime-Client\resources\views/employees/index.blade.php ENDPATH**/ ?>