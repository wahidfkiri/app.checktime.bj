<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Rapport Présence & Ponctualité - <?php echo e($start_date); ?> au <?php echo e($end_date); ?></title>
    <style>
        @page {
            margin: 20px;
            font-family: DejaVu Sans, sans-serif;
        }
        
        body { 
            font-family: DejaVu Sans, sans-serif; 
            font-size: 10px; 
            line-height: 1.3;
            color: #000;
        }
        
        .header { 
            text-align: center; 
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #000;
        }
        
        
        .header-content {
            text-align: center;
            padding-top: 5px;
        }
        .title { 
            font-size: 16px; 
            font-weight: bold; 
            margin-bottom: 5px;
            text-transform: uppercase;
        }
        
        .subtitle { 
            font-size: 12px; 
            margin-bottom: 3px;
        }
        
        .period-info { 
            text-align: center;
            margin-bottom: 10px;
            font-size: 11px;
            font-weight: bold;
        }
        
        .client-info {
            text-align: left;
            margin-bottom: 10px;
            font-size: 10px;
        }
        
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 10px;
            font-size: 9px;
        }
        
        th { 
            background-color: #f2f2f2; 
            font-weight: bold; 
            padding: 6px 4px; 
            border: 1px solid #000;
            text-align: center;
            vertical-align: middle;
            font-size: 9px;
        }
        
        td { 
            padding: 5px 4px; 
            border: 1px solid #000;
            vertical-align: middle;
            text-align: center;
        }
        
        .employee-name {
            text-align: left;
            font-weight: bold;
        }
        
        .total-row {
            background-color: #e6e6e6;
            font-weight: bold;
        }
        
        .rate-high { color: #008000; font-weight: bold; }
        .rate-medium { color: #ff9900; font-weight: bold; }
        .rate-low { color: #ff0000; font-weight: bold; }
        
        .footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 20px;
            text-align: center;
            font-size: 8px;
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 5px;
            background-color: white;
        }
        
        .page-number:before {
            content: "Page " counter(page);
        }
        
        /* Styles spécifiques pour le tableau */
        .col-order { width: 5%; }
        .col-name { width: 20%; text-align: left; }
        .col-presence { width: 25%; }
        .col-ponctualite { width: 25%; }
        .col-observation { width: 25%; text-align: left; }
        
        .sub-header {
            background-color: #e0e0e0;
            font-weight: bold;
        }
        
        .section-title {
            font-weight: bold;
            background-color: #f8f8f8;
        }
        
        .presence-present { color: #008000; }
        .presence-absent { color: #ff0000; }
        .ponctualite-ontime { color: #008000; }
        .ponctualite-late { color: #ff9900; }
        
        .total-rate {
            font-size: 8px;
            color: #666;
            font-weight: normal;
        }
        
        .sort-info {
            text-align: center;
            font-size: 9px;
            font-style: italic;
            margin-bottom: 5px;
            color: #555;
        }
    </style>
</head>
<body>
    <!-- En-tête -->
    <div class="header">
        <!-- Logo du client -->
         <?php if(isset($client->logo) && $client->logo): ?>
        <img src="<?php echo $_SERVER["DOCUMENT_ROOT"]; ?>/storage/app/public/<?php echo $client->logo; ?>" alt="<?php echo e($client->raison_sociale); ?>" class="client-logo">
    <?php endif; ?>
        <div class="header-content">
        <div class="title">RAPPORT DE PRÉSENCE & PONCTUALITÉ</div>
        <div class="period-info">
            Période : <?php echo e(\Carbon\Carbon::parse($start_date)->format('d/m/Y')); ?> au <?php echo e(\Carbon\Carbon::parse($end_date)->format('d/m/Y')); ?>

            (<?php echo e($period_days); ?> jours)
        </div>
        <div class="client-info">
            Client : <?php echo e($client->name); ?> | 
            Employés : <?php echo e($total_employees); ?> | 
            Exporté le : <?php echo e($export_date->format('d/m/Y à H:i')); ?>

        </div>
    </div>
    </div>
    
    <!-- Information sur le tri -->
    <div class="sort-info">
        Les employés sont classés par ordre décroissant de la somme des taux de présence et ponctualité
    </div>
    
    <!-- Tableau principal -->
    <table>
        <thead>
            <tr>
                <th rowspan="2" class="col-order">N° d'ordre</th>
                <th rowspan="2" class="col-name">Nom et Prénoms</th>
                <th colspan="4" class="section-title">PRÉSENCE AU POSTE</th>
                <th colspan="3" class="section-title">PONCTUALITÉ</th>
                <th rowspan="2" class="col-observation">Observation</th>
            </tr>
            <tr class="sub-header">
                <!-- Sous-colonnes Présence -->
                <th>Présence</th>
                <th>Absence</th>
                <th>Taux de présence</th>
                <th style="width: 8%;">Détail</th>
                
                <!-- Sous-colonnes Ponctualité -->
                <th>A l'heure</th>
                <th>Retard</th>
                <th>Taux de ponctualité</th>
            </tr>
        </thead>
        <tbody>
            <?php
                // Calculer et trier les données par somme des taux
                $sortedData = collect($report_data)->map(function($employee) {
                    $presenceRate = floatval($employee['presence_data']['rate'] ?? 0);
                    $ponctualiteRate = floatval($employee['ponctualite_data']['rate'] ?? 0);
                    $employee['total_rate'] = $presenceRate + $ponctualiteRate;
                    return $employee;
                })->sortByDesc('total_rate')->values();
            ?>
            
            <?php $__currentLoopData = $sortedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!-- N° d'ordre -->
                <td><?php echo e($index + 1); ?></td>
                
                <!-- Nom et Prénoms -->
                <td class="employee-name">
                    <?php echo e($employee['employee_name']); ?><br>
                    <small style="color: #666;">(<?php echo e($employee['employee_code']); ?>)</small>
                </td>
                
                <!-- Présence au Poste -->
                <td class="presence-present"><?php echo e($employee['presence_data']['present']); ?></td>
                <td class="presence-absent"><?php echo e($employee['presence_data']['absent']); ?></td>
                <td>
                    <span class="rate-<?php echo e($employee['presence_data']['rate'] >= 90 ? 'high' : ($employee['presence_data']['rate'] >= 80 ? 'medium' : 'low')); ?>">
                        <?php echo e($employee['presence_data']['rate']); ?>%
                    </span>
                </td>
                <td><?php echo e($employee['presence_data']['present_days_display']); ?></td>
                
                <!-- Ponctualité -->
                <td class="ponctualite-ontime"><?php echo e($employee['ponctualite_data']['on_time']); ?></td>
                <td class="ponctualite-late"><?php echo e($employee['ponctualite_data']['late']); ?></td>
                <td>
                    <span class="rate-<?php echo e($employee['ponctualite_data']['rate'] >= 90 ? 'high' : ($employee['ponctualite_data']['rate'] >= 80 ? 'medium' : 'low')); ?>">
                        <?php echo e($employee['ponctualite_data']['rate']); ?>%
                    </span>
                </td>
                
                <!-- Observation -->
                <td style="text-align: left; font-size: 8px;">
                    <?php echo e($employee['observation']); ?>

                    <br>
                    <span class="total-rate">Total taux: <?php echo e(number_format($employee['total_rate'], 1)); ?>%</span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <!-- Ligne des totaux -->
            <tr class="total-row">
                <td colspan="2" style="text-align: right;"><strong>TOTAUX / MOYENNES :</strong></td>
                
                <!-- Totaux Présence -->
                <td><strong><?php echo e($totals['total_presence_present']); ?></strong></td>
                <td><strong><?php echo e($totals['total_presence_absent']); ?></strong></td>
                <td>
                    <strong class="rate-<?php echo e($totals['avg_presence_rate'] >= 90 ? 'high' : ($totals['avg_presence_rate'] >= 80 ? 'medium' : 'low')); ?>">
                        <?php echo e($totals['avg_presence_rate']); ?>%
                    </strong>
                </td>
                <td>-</td>
                
                <!-- Totaux Ponctualité -->
                <td><strong><?php echo e($totals['total_ponctualite_on_time']); ?></strong></td>
                <td><strong><?php echo e($totals['total_ponctualite_late']); ?></strong></td>
                <td>
                    <strong class="rate-<?php echo e($totals['avg_ponctualite_rate'] >= 90 ? 'high' : ($totals['avg_ponctualite_rate'] >= 80 ? 'medium' : 'low')); ?>">
                        <?php echo e($totals['avg_ponctualite_rate']); ?>%
                    </strong>
                </td>
                
                <td>-</td>
            </tr>
        </tbody>
    </table>
    
    <!-- Légende et notes -->
    <div style="margin-top: 15px; font-size: 8px; color: #666;">
        <p><strong>Légende :</strong></p>
        <p>
            • <span style="color: #008000;">Taux ≥ 90%</span> : Excellent | 
            • <span style="color: #ff9900;">Taux 80-89%</span> : Satisfaisant | 
            • <span style="color: #ff0000;">Taux &lt; 80%</span> : À améliorer
        </p>
        <p><strong>Notes :</strong> 
        1. Les employés sont classés par ordre décroissant de la somme des taux de présence et ponctualité.<br>
        2. Les statistiques portent uniquement sur les jours ouvrés (lundi-vendredi).<br>
        3. Les weekends et jours fériés ne sont pas inclus dans le calcul.</p>
    </div>
    
    <!-- Pied de page -->
    <div class="footer">
        <span class="page-number"></span> | 
        Rapport généré par le logiciel CHECKTIME le <?php echo e($export_date->format('d/m/Y à H:i')); ?>

    </div>
</body>
</html><?php /**PATH D:\My Project\CheckTime-Client\resources\views/reports/exports/custom-report-pdf.blade.php ENDPATH**/ ?>