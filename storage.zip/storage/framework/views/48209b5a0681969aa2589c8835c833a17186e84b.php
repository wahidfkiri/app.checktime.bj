

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-chart-bar"></i> Rapport Personnalisé - Présence & Ponctualité
                    </h5>
                </div>
                
                <div class="card-body">
                    <!-- Formulaire de filtres -->
                    <form id="reportForm" method="POST" action="<?php echo e(route('reports.custom.generate')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <div class="col-md-3">
                                <label for="start_date" class="form-label">Date de début *</label>
                                <input type="date" class="form-control" id="start_date" name="start_date" required>
                            </div>
                            
                            <div class="col-md-3">
                                <label for="end_date" class="form-label">Date de fin *</label>
                                <input type="date" class="form-control" id="end_date" name="end_date" required>
                            </div>
                            
                            <div class="col-md-3">
                                <label for="emp_code" class="form-label">Employé</label>
                                <select class="form-control" id="emp_code" name="emp_code">
                                    <option value="all">Tous les employés</option>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($employee['emp_code']); ?>"><?php echo e($employee['emp_code']); ?> - <?php echo e($employee['full_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="button" id="generateBtn" class="btn btn-primary me-2">
                                    <i class="fas fa-sync-alt"></i> Générer
                                </button>
                                <button type="button" id="exportPdfBtn" class="btn btn-danger">
                                    <i class="fas fa-file-pdf"></i> Exporter PDF
                                </button>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Résultats du rapport -->
                    <div id="reportResults" style="display: none;">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            <span id="reportSummary"></span>
                        </div>
                        
                        <!-- Aperçu du tableau -->
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-sm" id="previewTable">
                                <thead class="table-dark">
                                    <tr>
                                        <th rowspan="2">N° d'ordre</th>
                                        <th rowspan="2">Nom et Prénoms</th>
                                        <th colspan="4" class="text-center">PRÉSENCE AU POSTE</th>
                                        <th colspan="3" class="text-center">PONCTUALITÉ</th>
                                        <th rowspan="2">Observation</th>
                                    </tr>
                                    <tr class="table-secondary">
                                        <th>Présence</th>
                                        <th>Absence</th>
                                        <th>Taux de présence</th>
                                        <th>Détail</th>
                                        <th>A l'heure</th>
                                        <th>Retard</th>
                                        <th>Taux de ponctualité</th>
                                    </tr>
                                </thead>
                                <tbody id="reportTableBody">
                                    <!-- Les données seront insérées ici -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Message d'erreur -->
                    <div id="errorAlert" class="alert alert-danger" style="display: none;"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function() {
    // Générer le rapport
    $('#generateBtn').click(function() {
        generateReport();
    });
    
    // Exporter en PDF
    $('#exportPdfBtn').click(function() {
        exportToPdf();
    });
    
    // Fonction pour générer le rapport
    function generateReport() {
        const form = $('#reportForm');
        const formData = form.serialize();
        
        // Validation
        if (!$('#start_date').val() || !$('#end_date').val()) {
            showError('Veuillez sélectionner une période.');
            return;
        }
        
        // Afficher le chargement
        $('#generateBtn').html('<i class="fas fa-spinner fa-spin"></i> Génération...').prop('disabled', true);
        $('#errorAlert').hide();
        $('#reportResults').hide();
        
        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    displayReportData(response.data, response.period);
                    $('#reportSummary').html(
                        'Rapport généré avec succès. ' + 
                        response.total_employees + ' employé(s) trouvé(s). ' +
                        'Période : ' + response.period.start_date + ' au ' + response.period.end_date
                    );
                    $('#reportResults').show();
                } else {
                    showError(response.error || 'Erreur lors de la génération du rapport.');
                }
            },
            error: function(xhr) {
                let errorMessage = 'Erreur serveur. Veuillez réessayer.';
                if (xhr.responseJSON && xhr.responseJSON.error) {
                    errorMessage = xhr.responseJSON.error;
                }
                showError(errorMessage);
            },
            complete: function() {
                $('#generateBtn').html('<i class="fas fa-sync-alt"></i> Générer').prop('disabled', false);
            }
        });
    }
    
    // Fonction pour exporter en PDF
    function exportToPdf() {
        const form = $('#reportForm');
        
        // Validation
        if (!$('#start_date').val() || !$('#end_date').val()) {
            showError('Veuillez sélectionner une période.');
            return;
        }
        
        // Créer un formulaire pour l'export PDF
        const pdfForm = document.createElement('form');
        pdfForm.method = 'POST';
        pdfForm.action = '<?php echo e(route("reports.custom.export.pdf")); ?>';
        pdfForm.style.display = 'none';
        
        // Ajouter le token CSRF
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '_token';
        csrfInput.value = '<?php echo e(csrf_token()); ?>';
        pdfForm.appendChild(csrfInput);
        
        // Ajouter les autres champs
        const fields = ['start_date', 'end_date', 'emp_code'];
        fields.forEach(fieldName => {
            const field = document.createElement('input');
            field.type = 'hidden';
            field.name = fieldName;
            field.value = $('#' + fieldName).val();
            pdfForm.appendChild(field);
        });
        
        // Ajouter le formulaire au DOM et le soumettre
        document.body.appendChild(pdfForm);
        pdfForm.submit();
        document.body.removeChild(pdfForm);
    }
    
    // Fonction pour afficher les données du rapport
    function displayReportData(data, period) {
        const tbody = $('#reportTableBody');
        tbody.empty();
        
        if (data.length === 0) {
            tbody.append(
                '<tr>' +
                '<td colspan="10" class="text-center text-muted">Aucune donnée disponible pour les critères sélectionnés.</td>' +
                '</tr>'
            );
            return;
        }
        
        data.forEach((employee, index) => {
            const presenceRateClass = getRateClass(employee.presence_data.rate);
            const ponctualiteRateClass = getRateClass(employee.ponctualite_data.rate);
            
            const row = 
                '<tr>' +
                '<td>' + employee.order_number + '</td>' +
                '<td>' + 
                    '<strong>' + employee.employee_name + '</strong><br>' +
                    '<small class="text-muted">' + employee.employee_code + '</small>' +
                '</td>' +
                '<td class="text-success fw-bold">' + employee.presence_data.present + '</td>' +
                '<td class="text-danger fw-bold">' + employee.presence_data.absent + '</td>' +
                '<td><span class="' + presenceRateClass + '">' + employee.presence_data.rate + '%</span></td>' +
                '<td><small>' + employee.presence_data.present_days_display + '</small></td>' +
                '<td class="text-success fw-bold">' + employee.ponctualite_data.on_time + '</td>' +
                '<td class="text-warning fw-bold">' + employee.ponctualite_data.late + '</td>' +
                '<td><span class="' + ponctualiteRateClass + '">' + employee.ponctualite_data.rate + '%</span></td>' +
                '<td><small>' + employee.observation + '</small></td>' +
                '</tr>';
            
            tbody.append(row);
        });
    }
    
    // Fonction pour déterminer la classe CSS en fonction du taux
    function getRateClass(rate) {
        if (rate >= 90) return 'text-success';
        if (rate >= 80) return 'text-warning';
        return 'text-danger';
    }
    
    // Fonction pour afficher les erreurs
    function showError(message) {
        $('#errorAlert').html('<i class="fas fa-exclamation-triangle"></i> ' + message).show();
        $('#reportResults').hide();
    }
    
    // Définir les dates par défaut (dernier mois)
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const lastDay = new Date(today.getFullYear(), today.getMonth(), 0);
    
    $('#start_date').val(firstDay.toISOString().split('T')[0]);
    $('#end_date').val(lastDay.toISOString().split('T')[0]);
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\CheckTime-Client\resources\views/reports/custom-presence.blade.php ENDPATH**/ ?>