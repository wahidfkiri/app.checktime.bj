<?php echo e($slot); ?>

<?php /**PATH D:\My Project\CheckTime-Client\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>