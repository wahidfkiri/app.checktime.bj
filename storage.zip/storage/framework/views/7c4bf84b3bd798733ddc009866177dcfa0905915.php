

<?php $__env->startSection('content'); ?>
<div id="main" class="layout-navbar navbar-fixed">
    <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = App\View\Components\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
    <div id="main-content">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Rapport Absences & Retards</h3>
                        <p class="text-subtitle text-muted">Analyse détaillée des présences, absences et retards</p>
                    </div>
                </div>
            </div>

            <section class="section">
                <div class="card">
                    <div class="card-header">
                        <!-- Filtres -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6 class="card-title">Filtres du rapport</h6>
                                        <!-- Formulaire pour PDF -->
                                        <form id="exportPdfForm" action="<?php echo e(route('admin.reports.export.pdf')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="start_date" id="pdf_start_date">
                                            <input type="hidden" name="end_date" id="pdf_end_date">
                                            <input type="hidden" name="emp_code" id="pdf_emp_code">
                                        </form>
                                        
                                        <div class="row g-3">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="report_start_date" class="form-label">Date début</label>
                                                    <input type="date" class="form-control" id="report_start_date" 
                                                           value="<?php echo e(date('Y-m-d', strtotime('-7 days'))); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="report_end_date" class="form-label">Date fin</label>
                                                    <input type="date" class="form-control" id="report_end_date" 
                                                           value="<?php echo e(date('Y-m-d')); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label for="report_emp_code" class="form-label">Employé</label>
                                                    <select class="form-control" id="report_emp_code">
                                                        <option value="all">Tous les employés</option>
                                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($employee['emp_code']); ?>">
                                                                <?php echo e($employee['emp_code']); ?> - <?php echo e($employee['full_name']); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group text-start">
                                                    <label class="form-label d-block" style="margin-bottom:0px;">&nbsp;</label>
                                                    <div class="d-flex flex-wrap gap-2">
                                                        <button type="button" class="btn btn-primary" id="generate_report">
                                                            <i class="bi bi-file-earmark-text me-1"></i> Générer
                                                        </button>
                                                        <button type="button" class="btn btn-success" id="export_excel">
                                                            <i class="bi bi-file-excel me-1"></i> Excel
                                                        </button>
                                                        <button type="button" class="btn btn-danger" id="export_pdf">
                                                            <i class="bi bi-file-pdf me-1"></i> PDF
                                                        </button>
                                                        <button type="button" class="btn btn-info" id="preview_pdf">
                                                            <i class="bi bi-eye me-1"></i> Aperçu
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-12">
                                                <div class="alert alert-info alert-sm p-2 mb-0">
                                                    <i class="bi bi-info-circle me-1"></i>
                                                    <strong>Règle d'affichage :</strong> 
                                                    <span class="badge bg-success ms-2">Présent</span> (au moins un pointage)
                                                    <span class="badge bg-danger ms-2">Absent</span> (aucun pointage)
                                                    <span class="badge bg-warning ms-2">Retard</span> (arrivée après horaire prévu)
                                                    <span class="badge bg-info ms-2">Congé/Permission</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <!-- Résumé statistique amélioré -->
                        <div id="report-summary" class="row mb-3 d-none">
                            <div class="col-md-12">
                                <div class="card border-success">
                                    <div class="card-body">
                                        <h6 class="card-title">📊 Résumé détaillé du rapport</h6>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="border rounded p-2 bg-light mb-2">
                                                    <small class="text-muted">Période analysée</small>
                                                    <h5 class="mb-0" id="total-days">0</h5>
                                                    <small>jours</small>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="border rounded p-2 bg-light mb-2">
                                                    <small class="text-muted">Employés concernés</small>
                                                    <h5 class="mb-0" id="total-employees">0</h5>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="border rounded p-2 bg-light mb-2">
                                                    <small class="text-muted">Enregistrements</small>
                                                    <h5 class="mb-0" id="total-records">0</h5>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="border rounded p-2 bg-light mb-2">
                                                    <small class="text-muted">Heures totales</small>
                                                    <h5 class="mb-0" id="total-hours">0</h5>
                                                    <small>heures</small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-2">
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 text-center" style="background-color: #d4edda;">
                                                    <h5 class="mb-0 text-success" id="present-count">0</h5>
                                                    <small>Présents</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 text-center" style="background-color: #fff3cd;">
                                                    <h5 class="mb-0 text-warning" id="late-count">0</h5>
                                                    <small>Retards</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 text-center" style="background-color: #f8d7da;">
                                                    <h5 class="mb-0 text-danger" id="absent-count">0</h5>
                                                    <small>Absences</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 text-center" style="background-color: #d1ecf1;">
                                                    <h5 class="mb-0 text-info" id="leave-count">0</h5>
                                                    <small>Congés</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 text-center" style="background-color: #e2d1f1;">
                                                    <h5 class="mb-0 text-secondary" id="permission-count">0</h5>
                                                    <small>Permissions</small>
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-sm-4 mb-2">
                                                <div class="border rounded p-2 text-center" style="background-color: #cff4fc;">
                                                    <h5 class="mb-0" id="weekend-count">0</h5>
                                                    <small>Weekends</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Chargement -->
                        <div class="alert alert-info alert-dismissible fade show d-none" id="report-loading" role="alert">
                            <div class="d-flex align-items-center">
                                <div class="spinner-border spinner-border-sm me-2" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <strong id="report-loading-message">Chargement des données...</strong>
                            </div>
                        </div>
                        
                        <!-- Tableau principal -->
                        <div class="table-responsive">
                            <table id="report-table" class="table table-striped table-hover" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Jour</th>
                                        <th>Code</th>
                                        <th>Employé</th>
                                        <th>Planning</th>
                                        <th>Type</th>
                                        <th>Arrivée</th>
                                        <th>Départ</th>
                                        <th>Retard</th>
                                        <th>Départ anticipé</th>
                                        <th>Heures travaillées</th>
                                        <th>Statut</th>
                                        <th>Observations</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="10" class="text-end">Totaux :</th>
                                        <th id="footer-total-hours">0h</th>
                                        <th colspan="2"></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        
                        <!-- Légende détaillée -->
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-body py-2">
                                        <div class="d-flex flex-wrap align-items-center">
                                            <span class="me-3"><i class="bi bi-info-circle"></i> <strong>Légende :</strong></span>
                                            <span class="badge bg-success me-2">Présent</span>
                                            <span class="badge bg-warning me-2">Retard</span>
                                            <span class="badge bg-danger me-2">Absent</span>
                                            <span class="badge bg-info me-2">Congé</span>
                                            <span class="badge bg-secondary me-2">Permission</span>
                                            <span class="badge bg-light text-dark me-2">Weekend</span>
                                            <span class="badge bg-dark me-2">Non planifié</span>
                                            <span class="ms-3"><i class="bi bi-clock-history"></i> Retard > 0</span>
                                            <span class="ms-3"><i class="bi bi-clock"></i> Départ anticipé</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.bootstrap5.min.css">

<script>
$(document).ready(function() {
    // Variables
    var reportTable;
    
    // Fonctions utilitaires
    function showReportLoading(message) {
        $('#report-loading-message').text(message || 'Chargement des données...');
        $('#report-loading').removeClass('d-none');
    }
    
    function hideReportLoading() {
        $('#report-loading').addClass('d-none');
    }
    
    function showSweetAlert(icon, title, text, showConfirm = false) {
        if (showConfirm) {
            return Swal.fire({
                icon: icon,
                title: title,
                html: text,
                showCancelButton: true,
                confirmButtonText: 'Oui, continuer',
                cancelButtonText: 'Annuler'
            });
        } else {
            Swal.fire({
                icon: icon,
                title: title,
                html: text,
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
        }
    }
    
    // Obtenir le nom du jour en français
    function getDayName(dateStr) {
        var date = new Date(dateStr);
        var days = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
        return days[date.getDay()];
    }
    
    // Formater les minutes en heures:minutes
    function formatMinutesToHours(minutes) {
        if (minutes === null || minutes === undefined) return '-';
        if (minutes === 0) return '0';
        
        var hours = Math.floor(minutes / 60);
        var mins = minutes % 60;
        
        if (hours > 0) {
            return hours + 'h' + (mins > 0 ? ' ' + mins + 'min' : '');
        } else {
            return mins + 'min';
        }
    }
    
    // Formater les heures décimales
    function formatDecimalHours(hours) {
        if (!hours && hours !== 0) return '-';
        if (hours === 0) return '0h';
        
        var h = Math.floor(hours);
        var m = Math.round((hours - h) * 60);
        
        if (m === 0) {
            return h + 'h';
        } else {
            return h + 'h ' + m + 'min';
        }
    }
    
    // Mettre à jour le résumé
    function updateReportSummary(data) {
        var present = 0;
        var presentLate = 0;
        var absent = 0;
        var leave = 0;
        var permission = 0;
        var weekend = 0;
        var days = new Set();
        var employees = new Set();
        var totalHours = 0;
        
        data.forEach(function(row) {
            days.add(row.date);
            employees.add(row.employee_code);
            
            if (row.work_hours) {
                totalHours += parseFloat(row.work_hours);
            }
            
            if (row.status === 'present') {
                if (row.is_late) {
                    presentLate++;
                } else {
                    present++;
                }
            } else if (row.status === 'absent') {
                absent++;
            } else if (row.status === 'leave') {
                leave++;
            } else if (row.status === 'permission') {
                permission++;
            } else if (row.status === 'weekend') {
                weekend++;
            }
        });
        
        $('#total-days').text(days.size);
        $('#total-employees').text(employees.size);
        $('#total-records').text(data.length);
        $('#total-hours').text(totalHours.toFixed(1));
        $('#present-count').text(present);
        $('#late-count').text(presentLate);
        $('#absent-count').text(absent);
        $('#leave-count').text(leave);
        $('#permission-count').text(permission);
        $('#weekend-count').text(weekend);
        $('#footer-total-hours').text(formatDecimalHours(totalHours));
        
        $('#report-summary').removeClass('d-none');
    }
    
    // Valider les dates avant export
    function validateDatesForExport() {
        var startDate = $('#report_start_date').val();
        var endDate = $('#report_end_date').val();
        
        if (!startDate || !endDate) {
            showSweetAlert('error', 'Erreur', 'Veuillez sélectionner une période.');
            return false;
        }
        
        if (new Date(startDate) > new Date(endDate)) {
            showSweetAlert('error', 'Erreur', 'La date de début ne peut pas être après la date de fin.');
            return false;
        }
        
        var daysDiff = Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)) + 1;
        if (daysDiff > 31) {
            showSweetAlert('warning', 'Attention', 
                'La période sélectionnée dépasse 31 jours. ' +
                'Cela peut affecter les performances.<br><br>' +
                'Période: ' + daysDiff + ' jours');
        }
        
        return true;
    }
    
    // Initialiser DataTable
    function initReportTable() {
        reportTable = $('#report-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(route('admin.reports.data')); ?>",
                type: 'GET',
                data: function(d) {
                    return {
                        start_date: $('#report_start_date').val(),
                        end_date: $('#report_end_date').val(),
                        emp_code: $('#report_emp_code').val(),
                        draw: d.draw,
                        start: d.start,
                        length: d.length,
                        order: d.order,
                        columns: d.columns,
                        search: d.search
                    };
                },
                beforeSend: function() {
                    showReportLoading('Chargement des données...');
                },
                complete: function() {
                    hideReportLoading();
                },
                error: function(xhr) {
                    hideReportLoading();
                    var errorMsg = xhr.responseJSON?.error || 'Erreur de chargement des données';
                    showSweetAlert('error', 'Erreur', errorMsg);
                },
                dataSrc: function(json) {
                    if (json.error) {
                        showSweetAlert('error', 'Erreur', json.error);
                        return [];
                    }
                    
                    if (json.data) {
                        updateReportSummary(json.data);
                        return json.data;
                    }
                    
                    return [];
                }
            },
            columns: [
                { 
                    data: 'date',
                    render: function(data) {
                        return data ? new Date(data).toLocaleDateString('fr-FR') : '-';
                    }
                },
                { 
                    data: 'date',
                    render: function(data) {
                        return getDayName(data);
                    }
                },
                { 
                    data: 'employee_code',
                    render: function(data) {
                        return data || '-';
                    }
                },
                { 
                    data: 'employee_name',
                    render: function(data) {
                        return data || '-';
                    }
                },
                { 
                    data: null,
                    render: function(data) {
                        if (data.schedule_start === '-' && data.schedule_end === '-') {
                            return '<span class="text-muted">Non planifié</span>';
                        } else {
                            return data.schedule_start + ' → ' + data.schedule_end;
                        }
                    }
                },
                { 
                    data: 'schedule_type',
                    render: function(data) {
                        if (!data || data === 'Non planifié') {
                            return '<span class="badge bg-secondary">Non planifié</span>';
                        }
                        
                        var badges = {
                            'fixe': 'badge bg-primary',
                            'rotation': 'badge bg-info',
                            'planifie': 'badge bg-success'
                        };
                        
                        var badgeClass = badges[data] || 'badge bg-secondary';
                        return '<span class="' + badgeClass + '">' + data + '</span>';
                    }
                },
                { 
                    data: 'actual_arrival',
                    render: function(data, type, row) {
                        if (!data) return '-';
                        
                        if (row.is_late) {
                            return '<span class="text-danger"><i class="bi bi-exclamation-triangle-fill me-1"></i>' + data + '</span>';
                        }
                        return '<span class="text-success"><i class="bi bi-check-circle-fill me-1"></i>' + data + '</span>';
                    }
                },
                { 
                    data: 'actual_departure',
                    render: function(data, type, row) {
                        if (!data) return '-';
                        
                        if (row.is_early_leave) {
                            return '<span class="text-warning"><i class="bi bi-exclamation-triangle-fill me-1"></i>' + data + '</span>';
                        }
                        return '<span class="text-success"><i class="bi bi-check-circle-fill me-1"></i>' + data + '</span>';
                    }
                },
                { 
                    data: 'late_minutes',
                    render: function(data, type, row) {
                        if (data === null || data === undefined) return '-';
                        if (data === 0) return '<span class="text-success">À l\'heure</span>';
                        
                        var formatted = formatMinutesToHours(data);
                        return '<span class="text-danger"><i class="bi bi-clock-history me-1"></i>' + formatted + '</span>';
                    }
                },
                { 
                    data: 'early_leave_minutes',
                    render: function(data, type, row) {
                        if (data === null || data === undefined) return '-';
                        if (data === 0) return '<span class="text-success">Normal</span>';
                        
                        var formatted = formatMinutesToHours(data);
                        return '<span class="text-warning"><i class="bi bi-clock me-1"></i>' + formatted + '</span>';
                    }
                },
                { 
                    data: 'work_hours',
                    render: function(data) {
                        return formatDecimalHours(data);
                    }
                },
                { 
                    data: 'status',
                    render: function(data, type, row) {
                        var badgeClass = 'secondary';
                        var icon = '';
                        var text = data;
                        
                        switch(data) {
                            case 'present':
                                if (row.is_late) {
                                    badgeClass = 'warning';
                                    text = 'Retard';
                                    icon = '<i class="bi bi-exclamation-triangle-fill me-1"></i>';
                                } else {
                                    badgeClass = 'success';
                                    text = 'Présent';
                                    icon = '<i class="bi bi-check-circle-fill me-1"></i>';
                                }
                                break;
                            case 'absent':
                                badgeClass = 'danger';
                                text = 'Absent';
                                icon = '<i class="bi bi-x-circle-fill me-1"></i>';
                                break;
                            case 'leave':
                                badgeClass = 'info';
                                text = 'Congé';
                                icon = '<i class="bi bi-calendar-check-fill me-1"></i>';
                                break;
                            case 'permission':
                                badgeClass = 'secondary';
                                text = 'Permission';
                                icon = '<i class="bi bi-person-check-fill me-1"></i>';
                                break;
                            case 'weekend':
                                badgeClass = 'light';
                                text = 'Weekend';
                                icon = '<i class="bi bi-calendar-week-fill me-1"></i>';
                                break;
                            default:
                                badgeClass = 'secondary';
                                text = data;
                        }
                        
                        return '<span class="badge bg-' + badgeClass + '">' + icon + ' ' + text + '</span>';
                    }
                },
                { 
                    data: null,
                    render: function(data) {
                        var observations = [];
                        
                        if (data.is_weekend) observations.push('Weekend');
                        if (data.is_on_leave) observations.push('Congé');
                        if (data.has_permission) observations.push('Permission');
                        
                        if (data.all_punches && data.all_punches.length > 0) {
                            observations.push(data.all_punches.length + ' pointage(s)');
                            
                            // Ajouter les heures de pointage si disponibles
                            if (data.all_punches.length > 2) {
                                observations.push('Multiples pointages');
                            }
                        }
                        
                        if (data.is_late && data.late_minutes > 0) {
                            observations.push('Retard: ' + formatMinutesToHours(data.late_minutes));
                        }
                        
                        if (data.is_early_leave && data.early_leave_minutes > 0) {
                            observations.push('Départ anticipé: ' + formatMinutesToHours(data.early_leave_minutes));
                        }
                        
                        if (!data.schedule_start || data.schedule_start === '-') {
                            observations.push('Pas de planning');
                        }
                        
                        return observations.length > 0 ? observations.join(' • ') : '-';
                    }
                }
            ],
            language: {
                url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/French.json",
                search: "Rechercher:",
                lengthMenu: "Afficher _MENU_ entrées",
                info: "Affichage de _START_ à _END_ sur _TOTAL_ entrées",
                infoEmpty: "Affichage 0 à 0 sur 0 entrées",
                infoFiltered: "(filtré de _MAX_ entrées totales)",
                paginate: {
                    first: "Premier",
                    last: "Dernier",
                    next: "Suivant",
                    previous: "Précédent"
                }
            },
            pageLength: 25,
            order: [[0, 'desc']],
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'excel',
                    text: '<i class="bi bi-file-excel me-1"></i> Excel',
                    className: 'btn btn-success btn-sm',
                    title: 'Rapport Absences Retards',
                    messageTop: function() {
                        var startDate = $('#report_start_date').val();
                        var endDate = $('#report_end_date').val();
                        var empCode = $('#report_emp_code').val();
                        var empName = $('#report_emp_code option:selected').text();
                        
                        return 'Période: ' + startDate + ' au ' + endDate + '\n' +
                               'Employé: ' + empName + '\n' +
                               'Généré le: ' + new Date().toLocaleDateString('fr-FR');
                    },
                    exportOptions: {
                        columns: ':visible',
                        format: {
                            body: function(data, row, column, node) {
                                // Nettoyer le HTML pour l'export Excel
                                return $(data).text() || data;
                            }
                        }
                    }
                },
                {
                    extend: 'print',
                    text: '<i class="bi bi-printer me-1"></i> Imprimer',
                    className: 'btn btn-secondary btn-sm',
                    title: 'Rapport Absences Retards',
                    messageTop: function() {
                        var startDate = $('#report_start_date').val();
                        var endDate = $('#report_end_date').val();
                        var empCode = $('#report_emp_code').val();
                        var empName = $('#report_emp_code option:selected').text();
                        
                        return '<h4>Rapport Absences et Retards</h4>' +
                               '<p>Période: ' + startDate + ' au ' + endDate + '</p>' +
                               '<p>Employé: ' + empName + '</p>' +
                               '<p>Généré le: ' + new Date().toLocaleDateString('fr-FR') + '</p><hr>';
                    },
                    exportOptions: {
                        columns: ':visible',
                        stripHtml: false
                    }
                },
                {
                    extend: 'colvis',
                    text: '<i class="bi bi-eye me-1"></i> Colonnes',
                    className: 'btn btn-info btn-sm'
                },
                {
                    text: '<i class="bi bi-arrow-counterclockwise"></i> Réinitialiser',
                    className: 'btn btn-warning btn-sm',
                    action: function(e, dt, node, config) {
                        dt.ajax.reload();
                    }
                }
            ],
            columnDefs: [
                { targets: [1], visible: true }, // Jour de la semaine
                { targets: [5], visible: true }, // Type de planning
                { targets: [8,9], className: 'text-center' }, // Centrer les minutes
                { targets: [10], className: 'text-end' } // Aligner les heures à droite
            ],
            drawCallback: function() {
                // Activer les tooltips Bootstrap
                $('[data-bs-toggle="tooltip"]').tooltip();
                
                // Mettre à jour le pied de tableau
                var api = this.api();
                var total = 0;
                
                api.column(10, {page:'current'}).data().each(function(value) {
                    // Extraire les heures de la chaîne formatée
                    if (value && value.includes('h')) {
                        var parts = value.replace('h', '').split(' ');
                        var hours = parseFloat(parts[0]) || 0;
                        var minutes = parts[1] ? parseFloat(parts[1].replace('min', '')) : 0;
                        total += hours + (minutes / 60);
                    }
                });
                
                $('#footer-total-hours').text(formatDecimalHours(total));
            }
        });
    }
    
    // Initialisation
    initReportTable();
    
    // Générer le rapport
    $('#generate_report').on('click', function() {
        if (!validateDatesForExport()) return;
        reportTable.ajax.reload();
    });
    
    // Exporter en Excel
    $('#export_excel').on('click', function() {
        if (!validateDatesForExport()) return;
        $('.buttons-excel').click();
    });
    
    // Exporter en PDF
    $('#export_pdf').on('click', function() {
        if (!validateDatesForExport()) return;
        
        var startDate = $('#report_start_date').val();
        var endDate = $('#report_end_date').val();
        var empCode = $('#report_emp_code').val();
        var empName = $('#report_emp_code option:selected').text();
        
        var message = 'Êtes-vous sûr de vouloir exporter en PDF ?<br><br>' +
                     '<strong>Période :</strong> ' + startDate + ' au ' + endDate + '<br>' +
                     '<strong>Employé :</strong> ' + empName;
        
        showSweetAlert('question', 'Exporter en PDF', message, true).then((result) => {
            if (result.isConfirmed) {
                $('#pdf_start_date').val(startDate);
                $('#pdf_end_date').val(endDate);
                $('#pdf_emp_code').val(empCode);
                
                showSweetAlert('info', 'Génération en cours', 'Le PDF est en cours de génération...');
                
                $('#exportPdfForm').submit();
            }
        });
    });
    
    // Prévisualiser PDF
    $('#preview_pdf').on('click', function() {
        if (!validateDatesForExport()) return;
        
        var startDate = $('#report_start_date').val();
        var endDate = $('#report_end_date').val();
        var empCode = $('#report_emp_code').val();
        
        var url = "<?php echo e(route('admin.reports.preview.pdf')); ?>";
        var params = new URLSearchParams({
            start_date: startDate,
            end_date: endDate,
            emp_code: empCode,
            _token: "<?php echo e(csrf_token()); ?>"
        });
        
        window.open(url + '?' + params.toString(), '_blank');
    });
    
    // Appliquer automatiquement quand on change les filtres
    $('#report_start_date, #report_end_date, #report_emp_code').on('change', function() {
        $('#generate_report').click();
    });
    
    // Raccourci clavier pour générer (Ctrl+Enter)
    $(document).on('keydown', function(e) {
        if (e.ctrlKey && e.keyCode === 13) {
            $('#generate_report').click();
        }
    });
    
    // Initialiser les tooltips
    $(function () {
        $('[data-bs-toggle="tooltip"]').tooltip();
    });
});
</script>

<style>
    .card-header { background-color: #f8f9fa; }
    .table th { background-color: #f1f5f9; font-weight: 600; white-space: nowrap; }
    .table td { vertical-align: middle; }
    
    .btn-group .btn { border-radius: 0.375rem !important; }
    
    .btn-export {
        min-width: 100px;
    }
    
    @media (max-width: 768px) {
        .d-flex.flex-wrap {
            flex-direction: column;
        }
        .d-flex.flex-wrap .btn {
            width: 100%;
            margin-bottom: 5px;
        }
        .btn-group { flex-direction: column; gap: 5px; }
    }
    
    #report-table th {
        background-color: #f1f5f9;
    }
    
    #report-table td {
        padding: 0.75rem;
    }
    
    .badge {
        font-size: 0.85em;
        font-weight: 500;
        padding: 0.4em 0.6em;
    }
    
    @media (max-width: 768px) {
        .table-responsive {
            font-size: 0.85rem;
        }
        
        #report-table th,
        #report-table td {
            padding: 0.5rem;
        }
    }
    
    #report-table td:empty::before {
        content: "-";
        color: #6c757d;
    }
    
    .text-success { color: #198754 !important; }
    .text-danger { color: #dc3545 !important; }
    .text-warning { color: #ffc107 !important; }
    
    #report-summary .border {
        transition: all 0.3s ease;
        border: 1px solid #dee2e6 !important;
    }
    
    #report-summary .border:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    /* Style pour les badges de statut */
    .bg-success { background-color: #198754 !important; }
    .bg-danger { background-color: #dc3545 !important; }
    .bg-warning { background-color: #ffc107 !important; color: #000 !important; }
    .bg-info { background-color: #0dcaf0 !important; color: #000 !important; }
    .bg-secondary { background-color: #6c757d !important; }
    .bg-light { background-color: #f8f9fa !important; color: #000 !important; }
    .bg-primary { background-color: #0d6efd !important; }
    
    /* Animation de chargement */
    #report-loading {
        animation: pulse 1.5s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.7; }
        100% { opacity: 1; }
    }
    
    /* Style pour le pied de tableau */
    tfoot {
        background-color: #f8f9fa;
        font-weight: 600;
    }
    
    /* Tooltips personnalisés */
    [data-bs-toggle="tooltip"] {
        cursor: help;
    }
    
    /* Amélioration de l'affichage des heures */
    .text-end {
        font-family: 'Courier New', monospace;
    }
    
    /* Badge pour les retards */
    .bg-warning {
        color: #000 !important;
    }
    
    /* Icônes dans les badges */
    .badge i {
        margin-right: 0.2em;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\CheckTime-Client\packages\vendor\report\src/Views/abscences/index.blade.php ENDPATH**/ ?>