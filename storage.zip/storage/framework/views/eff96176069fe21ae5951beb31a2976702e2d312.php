

<?php $__env->startSection('content'); ?>
<div id="main" class="layout-navbar navbar-fixed">
    <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = App\View\Components\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
    <div id="main-content">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Gestion des Clients</h3>
                        <p class="text-subtitle text-muted">
                            Gestion des entreprises clientes du système CheckTime
                        </p>
                    </div>
                    <div class="col-12 col-md-6 order-md-2 order-first">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active">Clients</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <section class="section">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="card-title">Liste des clients</h4>
                        <div>
                            <div class="btn-group me-2">
                                <button type="button" class="btn btn-outline-primary filter-btn active" data-status="all">
                                    Tous <?php echo e($all); ?>

                                </button>
                                <button type="button" class="btn btn-outline-success filter-btn" data-status="active">
                                    Actifs <?php echo e($actifs); ?>

                                </button>
                                <button type="button" class="btn btn-outline-danger filter-btn" data-status="inactive">
                                    Inactifs <?php echo e($inactifs); ?>

                                </button>
                            </div>
                            <button type="button" class="btn btn-primary" id="create-client-btn">
                                <i class="bi bi-plus-circle me-1"></i> Nouveau client
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="clients-table" class="table table-striped table-hover dt-responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Raison Sociale</th>
                                        <th>RCCM</th>
                                        <th>IFU</th>
                                        <th>Directeur</th>
                                        <th>Email</th>
                                        <th>Téléphone</th>
                                        <th>Statut</th>
                                        <th>Date création</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Les données seront chargées via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<!-- Modal de création -->
<div class="modal fade" id="createClientModal" tabindex="-1" aria-labelledby="createClientModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Contenu chargé via AJAX -->
        </div>
    </div>
</div>

<!-- Modal d'édition -->
<div class="modal fade" id="editClientModal" tabindex="-1" aria-labelledby="editClientModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Contenu chargé via AJAX -->
        </div>
    </div>
</div>
<style>
    .filter-btn.active {
        font-weight: bold;
        border-width: 2px;
    }
    #clients-table th {
        background-color: #f8f9fa;
        font-weight: 600;
    }
    .btn-group .btn {
        padding: 0.375rem 0.75rem;
    }
    .dataTables_wrapper {
        padding-top: 10px;
    }
    .swal2-popup {
        font-size: 1rem !important;
    }
    .swal2-title {
        font-size: 1.5rem !important;
    }
    .modal-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }
    .modal-title {
        font-weight: 600;
        color: #2c3e50;
    }
    .btn-sm {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
    .badge {
        font-size: 0.75em;
        padding: 0.3em 0.6em;
    }
    .btn-group-sm > .btn {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
    }
</style>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // =================== INITIALISATION DATATABLE ===================
        var table = $('#clients-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "<?php echo e(route('clients.datatable')); ?>",
                data: function(d) {
                    d.status = $('.filter-btn.active').data('status');
                },
                error: function(xhr, error, thrown) {
                    showSweetAlert('error', 
                        'Erreur de chargement', 
                        'Impossible de charger les données des clients. ' + 
                        (xhr.responseJSON?.error || 'Veuillez réessayer ultérieurement.')
                    );
                }
            },
            columns: [
                { 
                    data: 'DT_RowIndex', 
                    name: 'DT_RowIndex',
                    orderable: false,
                    searchable: false,
                    width: '3%',
                    className: 'text-center'
                },
                { 
                    data: 'nom_complet', 
                    name: 'raison_sociale',
                    render: function(data, type, row) {
                        return `<strong class="text-primary">${data}</strong>`;
                    }
                },
                { 
                    data: 'rccm', 
                    name: 'rccm',
                    className: 'text-uppercase font-monospace'
                },
                { 
                    data: 'ifu', 
                    name: 'ifu',
                    defaultContent: '<span class="text-muted">-</span>'
                },
                { 
                    data: 'directeur', 
                    name: 'directeur',
                    defaultContent: '<span class="text-muted">-</span>'
                },
                { 
                    data: 'email_linked', 
                    name: 'email'
                },
                { 
                    data: 'telephone_formatted', 
                    name: 'telephone',
                    defaultContent: '<span class="text-muted">-</span>'
                },
                { 
                    data: 'status_badge', 
                    name: 'is_active',
                    orderable: false,
                    searchable: false,
                    className: 'text-center'
                },
                { 
                    data: 'created_at', 
                    name: 'created_at',
                    className: 'text-center'
                },
                { 
                    data: 'actions', 
                    name: 'actions',
                    orderable: false,
                    searchable: false,
                    width: '15%',
                    className: 'text-center'
                }
            ],
            language: {
                url: "https://cdn.datatables.net/plug-ins/1.13.4/i18n/fr-FR.json"
            },
            responsive: true,
            order: [[1, 'asc']],
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Tous"]],
            dom: '<"row"<"col-md-6"l><"col-md-6"f>>rt<"row"<"col-md-6"i><"col-md-6"p>>',
            drawCallback: function() {
                // Initialiser les tooltips
                $('[data-bs-toggle="tooltip"]').tooltip();
            },
            initComplete: function() {
                // Personnaliser le champ de recherche
                $('#clients-table_filter input')
                    .addClass('form-control form-control-sm')
                    .attr('placeholder', 'Rechercher...')
                    .css('width', '250px');
            }
        });

        // =================== GESTION DES FILTRES ===================
        $('.filter-btn').click(function() {
            $('.filter-btn').removeClass('active');
            $(this).addClass('active');
            table.ajax.reload();
        });

        // =================== MODALE DE CRÉATION ===================
        $('#create-client-btn').click(function() {
            $.ajax({
                url: "<?php echo e(route('clients.create')); ?>",
                method: 'GET',
                beforeSend: function() {
                    $('#createClientModal .modal-content').html(`
                        <div class="modal-header">
                            <h5 class="modal-title">Chargement...</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body text-center py-5">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Chargement...</span>
                            </div>
                            <p class="mt-2 text-muted">Chargement du formulaire...</p>
                        </div>
                    `);
                },
                success: function(response) {
                    $('#createClientModal .modal-content').html(response);
                    $('#createClientModal').modal('show');
                },
                error: function(xhr) {
                    showSweetAlert('error', 
                        'Erreur', 
                        'Impossible de charger le formulaire de création. ' + 
                        (xhr.responseJSON?.error || 'Veuillez réessayer.')
                    );
                }
            });
        });

        // Soumission du formulaire de création
        $(document).on('submit', '#create-client-form', function(e) {
            e.preventDefault();
            
            var form = $(this);
            var submitBtn = form.find('button[type="submit"]');
            var originalText = submitBtn.html();
            
            submitBtn.prop('disabled', true);
            submitBtn.html('<span class="spinner-border spinner-border-sm" role="status"></span> Enregistrement...');
            
            $.ajax({
                url: form.attr('action'),
                method: 'POST',
                data: form.serialize(),
                success: function(response) {
                    if (response.success) {
                        $('#createClientModal').modal('hide');
                        table.ajax.reload(null, false);
                        showSweetAlert('success', 'Succès', response.message, 3000);
                        form[0].reset();
                    } else {
                        displayFormErrors(form, response.errors);
                    }
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        displayFormErrors(form, xhr.responseJSON.errors);
                    } else {
                        showSweetAlert('error', 'Erreur', 
                            xhr.responseJSON?.message || 'Une erreur est survenue lors de l\'enregistrement.'
                        );
                    }
                },
                complete: function() {
                    submitBtn.prop('disabled', false);
                    submitBtn.html(originalText);
                }
            });
        });

        // =================== MODALE D'ÉDITION ===================
        $(document).on('click', '.edit-client-btn', function() {
            var clientId = $(this).data('id');
            var btn = $(this);
            
            btn.prop('disabled', true);
            
            $.ajax({
                url: "/clients/" + clientId + "/edit",
                method: 'GET',
                beforeSend: function() {
                    $('#editClientModal .modal-content').html(`
                        <div class="modal-header">
                            <h5 class="modal-title">Chargement...</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body text-center py-5">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Chargement...</span>
                            </div>
                            <p class="mt-2 text-muted">Chargement des données...</p>
                        </div>
                    `);
                },
                success: function(response) {
                    $('#editClientModal .modal-content').html(response);
                    $('#editClientModal').modal('show');
                },
                error: function(xhr) {
                    showSweetAlert('error', 'Erreur', 
                        'Impossible de charger le formulaire d\'édition. ' + 
                        (xhr.responseJSON?.error || 'Veuillez réessayer.')
                    );
                },
                complete: function() {
                    btn.prop('disabled', false);
                }
            });
        });

        // Soumission du formulaire d'édition
        $(document).on('submit', '#edit-client-form', function(e) {
            e.preventDefault();
            
            var form = $(this);
            var clientId = form.data('client-id');
            var submitBtn = form.find('button[type="submit"]');
            var originalText = submitBtn.html();
            
            submitBtn.prop('disabled', true);
            submitBtn.html('<span class="spinner-border spinner-border-sm" role="status"></span> Mise à jour...');
            
            $.ajax({
                url: "/clients/" + clientId,
                method: 'POST',
                data: form.serialize() + '&_method=PUT',
                success: function(response) {
                    if (response.success) {
                        $('#editClientModal').modal('hide');
                        table.ajax.reload(null, false);
                        showSweetAlert('success', 'Succès', response.message, 3000);
                    } else {
                        displayFormErrors(form, response.errors);
                    }
                },
                error: function(xhr) {
                    if (xhr.status === 422) {
                        displayFormErrors(form, xhr.responseJSON.errors);
                    } else {
                        showSweetAlert('error', 'Erreur', 
                            xhr.responseJSON?.message || 'Une erreur est survenue lors de la mise à jour.'
                        );
                    }
                },
                complete: function() {
                    submitBtn.prop('disabled', false);
                    submitBtn.html(originalText);
                }
            });
        });

        // =================== SUPPRESSION AVEC SWEETALERT ===================
        $(document).on('click', '.btn-delete-client', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            var clientId = $(this).data('id');
            var clientName = $(this).data('name');
            
            console.log('Suppression demandée:', { id: clientId, name: clientName });
            
            if (!clientId || !clientName) {
                console.error('Données manquantes');
                showSweetAlert('error', 'Erreur', 'Données du client incomplètes.');
                return;
            }
            
            // Utilisation de SweetAlert pour la confirmation
            Swal.fire({
                title: 'Supprimer le client ?',
                html: `Êtes-vous sûr de vouloir supprimer <strong>"${clientName}"</strong> ?<br><br>
                      <span class="text-danger">
                          <i class="bi bi-exclamation-triangle-fill"></i> 
                          Cette action est irréversible !
                      </span>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Oui, supprimer !',
                cancelButtonText: 'Annuler',
                reverseButtons: true,
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return new Promise((resolve, reject) => {
                        $.ajax({
                            url: `/clients/${clientId}`,
                            type: 'DELETE',
                            data: {
                                _token: "<?php echo e(csrf_token()); ?>"
                            },
                            success: function(response) {
                                resolve(response);
                            },
                            error: function(xhr) {
                                var errorMsg = xhr.responseJSON?.message || 'Erreur lors de la suppression';
                                reject(errorMsg);
                            }
                        });
                    });
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {
                if (result.isConfirmed) {
                    if (result.value && result.value.success) {
                        // Recharger la table
                        table.ajax.reload(null, false);
                        
                        // Afficher notification de succès
                        Swal.fire({
                            icon: 'success',
                            title: 'Supprimé !',
                            text: result.value.message,
                            timer: 3000,
                            showConfirmButton: false
                        });
                    } else if (result.value) {
                        // Afficher erreur
                        Swal.fire({
                            icon: 'error',
                            title: 'Erreur',
                            text: result.value.message || 'Erreur lors de la suppression'
                        });
                    }
                }
            }).catch((error) => {
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: error
                });
            });
        });

        // =================== CHANGEMENT DE STATUT ===================
        $(document).on('click', '.toggle-status-btn', function() {
            var clientId = $(this).data('id');
            var action = $(this).data('action');
            var actionText = action === 'activate' ? 'activation' : 'désactivation';
            var btn = $(this);
            
            Swal.fire({
                title: 'Confirmer l\'' + actionText,
                text: action === 'activate' 
                    ? 'Voulez-vous vraiment activer ce client ?' 
                    : 'Voulez-vous vraiment désactiver ce client ?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Oui',
                cancelButtonText: 'Annuler',
                reverseButtons: true,
                showLoaderOnConfirm: true,
                preConfirm: function() {
                    return new Promise(function(resolve, reject) {
                        $.ajax({
                            url: "/clients/" + clientId + "/toggle-status",
                            method: 'POST',
                            data: {
                                _token: "<?php echo e(csrf_token()); ?>",
                                action: action
                            },
                            success: function(response) {
                                resolve(response);
                            },
                            error: function(xhr) {
                                var errorMsg = xhr.responseJSON?.message || 'Erreur lors du changement de statut.';
                                reject(errorMsg);
                            }
                        });
                    });
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    if (result.value.success) {
                        table.ajax.reload(null, false);
                        var message = action === 'activate' 
                            ? 'Client activé avec succès.' 
                            : 'Client désactivé avec succès.';
                        showSweetAlert('success', 'Succès', message, 3000);
                    } else {
                        showSweetAlert('error', 'Erreur', result.value.message);
                    }
                }
            }).catch((error) => {
                showSweetAlert('error', 'Erreur', error);
            });
        });

        // =================== VÉRIFICATION RCCM EN TEMPS RÉEL ===================
        $(document).on('blur', '#rccm', function() {
            var rccm = $(this).val();
            var clientId = $(this).data('client-id');
            
            if (rccm && rccm.length > 0) {
                $.ajax({
                    url: "<?php echo e(route('clients.check-rccm')); ?>",
                    method: 'GET',
                    data: {
                        rccm: rccm,
                        client_id: clientId || ''
                    },
                    success: function(response) {
                        var input = $('#rccm');
                        var feedback = $('#rccm-feedback');
                        
                        if (response.exists) {
                            input.addClass('is-invalid');
                            feedback.text(response.message).addClass('text-danger');
                        } else {
                            input.removeClass('is-invalid');
                            feedback.text('RCCM disponible').removeClass('text-danger').addClass('text-success');
                            setTimeout(function() {
                                feedback.text('');
                            }, 3000);
                        }
                    },
                    error: function(xhr) {
                        var errorMsg = xhr.responseJSON?.error || 'Erreur lors de la vérification du RCCM.';
                        showSweetAlert('error', 'Erreur', errorMsg);
                    }
                });
            }
        });

        // =================== FONCTIONS UTILITAIRES ===================
        
        function displayFormErrors(form, errors) {
            form.find('.is-invalid').removeClass('is-invalid');
            form.find('.invalid-feedback').remove();
            
            if (errors && Object.keys(errors).length > 0) {
                $.each(errors, function(field, messages) {
                    var input = form.find('[name="' + field + '"]');
                    var feedback = input.next('.invalid-feedback');
                    
                    input.addClass('is-invalid');
                    
                    if (feedback.length === 0) {
                        input.after('<div class="invalid-feedback">' + messages[0] + '</div>');
                    } else {
                        feedback.text(messages[0]);
                    }
                });
                
                var errorCount = Object.keys(errors).length;
                if (errorCount > 0) {
                    showSweetAlert('warning', 
                        'Formulaire invalide', 
                        'Veuillez corriger les ' + errorCount + ' erreur(s) dans le formulaire.'
                    );
                    
                    var firstError = form.find('.is-invalid').first();
                    if (firstError.length) {
                        $('html, body').animate({
                            scrollTop: firstError.offset().top - 100
                        }, 500);
                    }
                }
            }
        }
        
        function showSweetAlert(icon, title, text, timer = null) {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: timer || 5000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer);
                    toast.addEventListener('mouseleave', Swal.resumeTimer);
                }
            });
            
            Toast.fire({
                icon: icon,
                title: title,
                text: text
            });
        }

        
        
        // Gérer la fermeture des modales
        $(document).on('hidden.bs.modal', '.modal', function() {
            $(this).find('.is-invalid').removeClass('is-invalid');
            $(this).find('.invalid-feedback').remove();
            
            setTimeout(() => {
                if (!$(this).hasClass('show')) {
                    $(this).find('.modal-content').html('');
                }
            }, 300);
        });
        
        // Initialiser les tooltips
        $('[data-bs-toggle="tooltip"]').tooltip({
            trigger: 'hover',
            placement: 'top'
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\CheckTime\resources\views/clients/index.blade.php ENDPATH**/ ?>