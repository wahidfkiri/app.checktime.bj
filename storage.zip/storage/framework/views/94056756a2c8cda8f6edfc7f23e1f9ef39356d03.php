<div class="modal-header">
    <h5 class="modal-title" id="editClientModalLabel">Modifier le Client</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<form id="edit-client-form" data-client-id="<?php echo e($client->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="modal-body">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="raison_sociale" class="form-label">Raison Sociale *</label>
                <input type="text" class="form-control" id="raison_sociale" name="raison_sociale" 
                       value="<?php echo e(old('raison_sociale', $client->raison_sociale)); ?>" required>
                <div class="invalid-feedback"></div>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="sigle" class="form-label">Sigle</label>
                <input type="text" class="form-control" id="sigle" name="sigle" 
                       value="<?php echo e(old('sigle', $client->sigle)); ?>">
                <div class="invalid-feedback"></div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="rccm" class="form-label">RCCM *</label>
                <input type="text" class="form-control" id="rccm" name="rccm" 
                       value="<?php echo e(old('rccm', $client->rccm)); ?>" 
                       data-client-id="<?php echo e($client->id); ?>" required>
                <div class="invalid-feedback" id="rccm-feedback"></div>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="ifu" class="form-label">IFU</label>
                <input type="text" class="form-control" id="ifu" name="ifu" 
                       value="<?php echo e(old('ifu', $client->ifu)); ?>">
                <div class="invalid-feedback"></div>
            </div>
        </div>
        
        <div class="mb-3">
            <label for="directeur" class="form-label">Directeur</label>
            <input type="text" class="form-control" id="directeur" name="directeur" 
                   value="<?php echo e(old('directeur', $client->directeur)); ?>">
            <div class="invalid-feedback"></div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="email" class="form-label">Email *</label>
                <input type="email" class="form-control" id="email" name="email" 
                       value="<?php echo e(old('email', $client->email)); ?>" required>
                <div class="invalid-feedback"></div>
            </div>
            
            <div class="col-md-6 mb-3">
                <label for="telephone" class="form-label">Téléphone</label>
                <input type="text" class="form-control" id="telephone" name="telephone" 
                       value="<?php echo e(old('telephone', $client->telephone)); ?>">
                <div class="invalid-feedback"></div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12 mb-3">
                <label for="adresse" class="form-label">Adresse</label>
                <input type="text" class="form-control" id="adresse" name="adresse" 
                       value="<?php echo e(old('adresse', $client->adresse)); ?>">
                <div class="invalid-feedback"></div>
            </div>
        </div>
        <hr>
        <h5>Configuration d'accès au portail client</h5>
        <div class="mb-3">
            <label for="login_user" class="form-label">Login *</label>
            <input type="text" class="form-control" id="login_user" name="login_user" 
                   value="<?php echo e(old('login_user', $client->user->email ?? '')); ?>" required>
            <div class="invalid-feedback"></div>
        </div>
        <div class="mb-3">
            <label for="password_user" class="form-label">Password *</label>
            <input type="password" class="form-control" id="password_user" name="password_user">
            <div class="invalid-feedback"></div>
        </div>
        <div class="mb-3">
            <label for="password_confirmation" class="form-label">Confirm Password *</label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation">
            <div class="invalid-feedback"></div>
        </div>
        <hr>
        <h5>Configuration d'accès à l'API CheckTime</h5>
        <div class="mb-3">
            <label for="general_token" class="form-label">Génerale Token API *</label>
            <input type="text" class="form-control" id="general_token" name="general_token" 
                   value="<?php echo e(old('general_token', $client->accessConfigs->first()->general_token ?? '')); ?>" required>
            <div class="invalid-feedback"></div>
        </div>
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="is_active" name="is_active" value="1" 
                   <?php echo e(old('is_active', $client->is_active) ? 'checked' : ''); ?>>
            <label class="form-check-label" for="is_active">Client actif</label>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
        <button type="submit" class="btn btn-primary">
            <i class="bi bi-save me-1"></i> Mettre à jour
        </button>
    </div>
</form><?php /**PATH D:\My Project\CheckTime\resources\views/clients/modals/edit.blade.php ENDPATH**/ ?>