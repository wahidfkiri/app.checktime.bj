

<?php $__env->startSection('content'); ?>
<div id="main" class="layout-navbar navbar-fixed">
    <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = App\View\Components\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
    <div id="main-content">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Liste des employés</h3>
                        <p class="text-subtitle text-muted">
                            <span id="sync-status">Chargement...</span>
                            <span id="last-sync-info" class="badge bg-light text-dark ms-2"></span>
                        </p>
                    </div>
                    <div class="col-12 col-md-6 order-md-2 order-first">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active">Employés</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <section class="section">
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-end">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="client_filter" class="form-label">Client</label>
                                    <select class="form-select" id="client_filter">
                                        <option value="">Tous les clients</option>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($client->id); ?>"><?php echo e($client->raison_sociale); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="zone_filter" class="form-label">Zone</label>
                                    <select class="form-select" id="zone_filter">
                                        <option value="">Toutes les zones</option>
                                        <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="status_filter" class="form-label">Statut</label>
                                    <select class="form-select" id="status_filter">
                                        <option value="">Tous</option>
                                        <option value="active">Actif</option>
                                        <option value="inactive">Inactif</option>
                                        <option value="suspended">Suspendu</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="emp_code_filter" class="form-label">Code employé</label>
                                    <input type="text" class="form-control" id="emp_code_filter" placeholder="Code...">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group text-end">
                                    <label class="form-label d-block">&nbsp;</label>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-primary" id="sync_button">
                                            <i class="bi bi-arrow-repeat me-1"></i> Sync
                                        </button>
                                        <button type="button" class="btn btn-warning" id="force_sync">
                                            <i class="bi bi-arrow-clockwise me-1"></i> Force Sync
                                        </button>
                                        <button type="button" class="btn btn-secondary" id="reset_filters">
                                            <i class="bi bi-x-circle me-1"></i> Reset Filtres
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info alert-dismissible fade show d-none" id="sync-alert" role="alert">
                            <div class="d-flex align-items-center">
                                <div class="spinner-border spinner-border-sm me-2" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <strong>Synchronisation en cours...</strong> Veuillez patienter.
                            </div>
                        </div>
                        
                        <div class="table-responsive">
                            <table id="employees-table" class="table table-striped table-hover dt-responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <!-- <th>#</th> -->
                                        <th>Code</th>
                                        <th>Nom complet</th>
                                        <th>Client</th>
                                        <th>Zone</th>
                                        <th>Département</th>
                                        <th>Téléphone</th>
                                        <!-- <th>Email</th> -->
                                        <th>Statut</th>
                                        <!-- <th>Dernière mise à jour</th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Les données seront chargées via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    // Initialiser DataTable
    var table = $('#employees-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('employees.local')); ?>",
            data: function (d) {
                d.client_id = $('#client_filter').val();
                d.emp_code = $('#emp_code_filter').val();
                d.name = $('#name_filter').val();
                d.status = $('#status_filter').val();
            }
        },
        columns: [
            // { 
            //     data: 'DT_RowIndex', 
            //     name: 'DT_RowIndex', 
            //     orderable: false, 
            //     searchable: false,
            //     width: '5%'
            // },
            { 
                data: 'emp_code', 
                name: 'emp_code',
                width: '10%'
            },
            { 
                data: 'full_name', 
                name: 'full_name',
                width: '25%'
            },
            { 
                data: 'client_name', 
                name: 'client_name',
                width: '20%'
            },
            { 
                data: 'area_name', 
                name: 'area_name',
                width: '15%'
            },
            { 
                data: 'dept_name', 
                name: 'dept_name',
                width: '15%'
            },
            { 
                data: 'phone', 
                name: 'phone',
                width: '15%'
            },
            { 
                data: 'status_badge', 
                name: 'status',
                width: '10%'
            }
        ],
        language: {
            url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/French.json"
        },
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Tous"]],
        order: [[1, 'asc']],
        responsive: true,
        drawCallback: function(settings) {
            var api = this.api();
            var pageInfo = api.page.info();
            $('.dataTables_info').html(
                'Affichage de ' + (pageInfo.start + 1) + ' à ' + 
                pageInfo.end + ' sur ' + pageInfo.recordsTotal + ' entrées'
            );
        }
    });

    // Appliquer les filtres
    function applyFilters() {
        table.ajax.reload();
    }

    // Événements pour les filtres avec debounce
    var filterTimeout;
    $('#client_filter, #status_filter').on('change', function() {
        applyFilters();
    });
    
    $('#emp_code_filter, #name_filter').on('keyup', function() {
        clearTimeout(filterTimeout);
        filterTimeout = setTimeout(applyFilters, 500);
    });

    // Réinitialiser les filtres
    $('#reset_filters').on('click', function() {
        $('#client_filter').val('');
        $('#emp_code_filter').val('');
        $('#name_filter').val('');
        $('#status_filter').val('');
        applyFilters();
    });

    // Synchronisation normale
    $('#sync_button').on('click', function() {
        var $button = $(this);
        var originalText = $button.html();
        
        $button.prop('disabled', true).html('<i class="bi bi-arrow-repeat spin"></i> Sync...');
        $('#sync-alert').removeClass('d-none');
        
        $.ajax({
            url: "<?php echo e(route('employees.sync')); ?>",
            type: 'POST',
            data: {
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Succès',
                        text: response.message,
                        timer: 3000,
                        showConfirmButton: false
                    });
                    setTimeout(function() {
                        table.ajax.reload();
                    }, 1000);
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erreur',
                        text: response.message
                    });
                }
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: 'Erreur lors de la synchronisation'
                });
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
                setTimeout(function() {
                    $('#sync-alert').addClass('d-none');
                }, 2000);
            }
        });
    });

    // Vérifier le statut au chargement
    checkSyncStatus();

    function checkSyncStatus() {
        $.ajax({
            url: "<?php echo e(route('employees.status')); ?>",
            type: 'GET',
            success: function(response) {
                updateSyncStatusUI(response);
            }
        });
    }

    function updateSyncStatusUI(status) {
        var statusText = 'Synchronisé';
        var statusClass = 'text-success';
        var badgeClass = 'bg-success';
        var badgeText = 'À jour';
        
        if (!status.last_sync || status.last_sync === 'Jamais') {
            statusText = 'Jamais synchronisé';
            statusClass = 'text-danger';
            badgeClass = 'bg-danger';
            badgeText = 'Non sync';
        }
        
        $('#sync-status').html(statusText).removeClass('text-danger text-warning text-success').addClass(statusClass);
        $('#last-sync-info').html(badgeText).removeClass('bg-danger bg-warning bg-success bg-info bg-light').addClass(badgeClass);
    }

    // Vérifier périodiquement le statut
    setInterval(checkSyncStatus, 30000);

    $('<style>')
        .text('.spin { animation: spin 1s linear infinite; } @keyframes spin { 100% { transform: rotate(360deg); } }')
        .appendTo('head');
});
</script>
<style>
    .dataTables_wrapper {
        padding: 10px 0;
    }
    .dataTables_length,
    .dataTables_filter {
        margin-bottom: 15px;
    }
    .dataTables_filter input {
        margin-left: 10px;
    }
    .dt-responsive {
        width: 100% !important;
    }
    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }
    .btn-group .btn {
        border-radius: 4px !important;
    }
    .badge {
        font-size: 0.75em;
        padding: 0.35em 0.65em;
    }
    #sync-alert {
        margin-bottom: 1rem;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\CheckTime\resources\views/employees/index.blade.php ENDPATH**/ ?>