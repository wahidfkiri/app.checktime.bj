

<?php $__env->startSection('content'); ?>
<div id="main" class="layout-navbar navbar-fixed">
    <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = App\View\Components\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
    <div id="main-content">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Liste des appareils</h3>
                    </div>
                    <div class="col-12 col-md-6 order-md-2 order-first">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('home')); ?>">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item active">Appareils</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <section class="section">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="client_filter">Filtrer par client</label>
                                    <select class="form-select" id="client_filter">
                                        <option value="">Tous les clients</option>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($client->id); ?>"><?php echo e($client->raison_sociale); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="code_filter">SN Appareil</label>
                                    <input type="text" class="form-control" id="code_filter" placeholder="Rechercher par code...">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="status_filter">Statut</label>
                                    <select class="form-select" id="status_filter">
                                        <option value="">Tous les statuts</option>
                                        <option value="active">Actif</option>
                                        <option value="inactive">Inactif</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group text-start pt-4">
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-primary" id="sync_button">
                                            <i class="bi bi-arrow-repeat me-1"></i> Synchroniser
                                        </button>
                                        <button type="button" class="btn btn-secondary" id="reset_filters">
                                            <i class="bi bi-x-circle me-1"></i> Réinitialiser
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info alert-dismissible fade show d-none" id="sync-alert" role="alert">
                            <div class="d-flex align-items-center">
                                <div class="spinner-border spinner-border-sm me-2" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <strong>Synchronisation en cours...</strong> Veuillez patienter.
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table id="devices-table" class="table table-striped table-hover dt-responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>SN</th>
                                        <th>Alias</th>
                                        <th>IP</th>
                                        <th>Nom Zone</th>
                                        <th>Client</th>
                                        <th>Status</th>
                                        <th>Dernière synchronisation</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Les données seront chargées via AJAX -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
<script>
$(document).ready(function() {
    // Timer pour éviter les requêtes trop fréquentes
    var filterTimer = null;
    var debounceDelay = 500; // 500ms de délai
    
    // Initialiser DataTable
    var table = $('#devices-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('devices.local')); ?>",
            data: function (d) {
                d.device_sn = $('#code_filter').val();
                d.alias = $('#alias_filter').val();
                d.ip = $('#ip_filter').val();
                d.area_name = $('#zone_name_filter').val();
                d.client_id = $('#client_filter').val();
                d.status = $('#status_filter').val(); // Nouveau filtre statut
            },
            error: function(xhr, error, thrown) {
                console.error('Erreur AJAX:', error);
                if (xhr.responseJSON && xhr.responseJSON.error) {
                    alert('Erreur: ' + xhr.responseJSON.error);
                }
            }
        },
        columns: [
            { 
                data: 'code',
                name: 'device_sn', // Utiliser le nom réel de la colonne
                width: '15%'
            },
            { 
                data: 'alias',
                name: 'alias',
                width: '20%'
            },
            { 
                data: 'ip',
                name: 'ip',
                width: '15%'
            },
            { 
                data: 'area_name',
                name: 'area_name',
                width: '15%'
            },
            { 
                data: 'client',
                name: 'client.raison_sociale',
                width: '15%'
            },
            { 
                data: 'status',
                name: 'status',
                width: '10%',
                orderable: false,
                searchable: false,
                render: function(data, type, row) {
                    return data;
                }
            },
            { 
                data: 'last_sync',
                name: 'last_sync',
                width: '10%',
                orderable: true,
                searchable: false
            }
        ],
        language: {
            url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/French.json"
        },
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Tous"]],
        order: [[0, 'asc']],
        responsive: true,
        drawCallback: function(settings) {
            // Mettre à jour le nombre de résultats
            var api = this.api();
            var pageInfo = api.page.info();
            $('.dataTables_info').html(
                'Affichage de ' + (pageInfo.start + 1) + ' à ' + 
                (pageInfo.end) + ' sur ' + pageInfo.recordsTotal + ' entrées'
            );
        }
    });

    // Fonction pour appliquer les filtres avec debounce
    function applyFilters() {
        if (filterTimer) {
            clearTimeout(filterTimer);
        }
        filterTimer = setTimeout(function() {
            table.ajax.reload();
        }, debounceDelay);
    }

    // Événements pour les filtres avec debounce
    $('#client_filter, #status_filter').on('change', function() {
        applyFilters();
    });

    $('#code_filter, #alias_filter, #ip_filter, #zone_name_filter').on('keyup', function() {
        applyFilters();
    });

    // Réinitialiser les filtres
    $('#reset_filters').on('click', function() {
        $('#client_filter').val('');
        $('#code_filter').val('');
        $('#alias_filter').val('');
        $('#ip_filter').val('');
        $('#zone_name_filter').val('');
        $('#status_filter').val('');
        
        // Appliquer immédiatement
        table.ajax.reload();
    });

    // Synchronisation
    $('#sync_button').on('click', function() {
        var $button = $(this);
        var originalText = $button.html();
        
        $button.prop('disabled', true).html('<i class="bi bi-arrow-repeat spin"></i> Synchronisation...');
        $('#sync-alert').removeClass('d-none');
        
        $.ajax({
            url: "<?php echo e(url('devices/sync')); ?>",
            type: 'POST',
            data: {
                client_id: $('#client_filter').val(),
                _token: "<?php echo e(csrf_token()); ?>"
            },
            success: function(response) {
                if (response.success) {
                    showSweetAlert('success', 
                        'Synchronisation réussie', 
                        response.message
                    );
                    table.ajax.reload(); // Recharger les données
                } else {
                    showSweetAlert('error', 
                        'Erreur de synchronisation', 
                        response.message || 'Erreur lors de la synchronisation'
                    );
                }
            },
            error: function(xhr) {
                showSweetAlert('error', 
                    'Erreur de synchronisation', 
                    'Erreur lors de la synchronisation. ' + 
                    (xhr.responseJSON?.error || 'Veuillez réessayer ultérieurement.')
                );
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
                $('#sync-alert').addClass('d-none');
            }
        });
    });

    function showSweetAlert(icon, title, text, timer = null) {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: timer || 5000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });
        
        Toast.fire({
            icon: icon,
            title: title,
            text: text
        });
    }

    // Style pour l'icône de rotation
    $('<style>').text('.spin { animation: spin 1s linear infinite; } @keyframes spin { 100% { transform: rotate(360deg); } }').appendTo('head');
});
</script>
<style>
    .dataTables_wrapper {
        padding: 10px 0;
    }
    .dataTables_length,
    .dataTables_filter {
        margin-bottom: 15px;
    }
    .dataTables_filter input {
        margin-left: 10px;
    }
    .dt-responsive {
        width: 100% !important;
    }
    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }
    
    .btn-group .btn {
        border-radius: 4px !important;
    }
    .badge {
        font-size: 0.85em;
        padding: 0.5em 0.8em;
        border-radius: 20px;
        display: inline-flex;
        align-items: center;
        font-weight: 500;
    }
    
    .badge.bg-success-light {
        background-color: rgba(25, 135, 84, 0.1) !important;
        border: 1px solid rgba(25, 135, 84, 0.2);
    }
    
    .badge.bg-danger-light {
        background-color: rgba(220, 53, 69, 0.1) !important;
        border: 1px solid rgba(220, 53, 69, 0.2);
    }
    
    .badge .bi {
        font-size: 0.8em;
        margin-right: 4px;
    }
    
    .badge.bg-success-light .bi {
        color: #198754;
    }
    
    .badge.bg-danger-light .bi {
        color: #dc3545;
    }
    
    .text-success {
        color: #198754 !important;
    }
    
    .text-danger {
        color: #dc3545 !important;
    }
    
    .text-muted {
        color: #6c757d !important;
    }
    
    #sync-alert {
        margin-bottom: 1rem;
    }
    
    .table th, .table td {
        vertical-align: middle;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .badge {
            font-size: 0.75em;
            padding: 0.4em 0.6em;
        }
        
        .badge .bi {
            font-size: 0.7em;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\CheckTime\resources\views/devices/index.blade.php ENDPATH**/ ?>