<div id="sidebar">
        <div class="sidebar-wrapper active">
          <div class="sidebar-header position-relative">
            <div class="d-flex justify-content-center align-items-center">
              <div class="logo">
                <a href="index.html">
                    <img src="<?php echo e(asset('logo.jpg')); ?>" alt="Logo" srcset="" style="width: 150px; height: 100px;">
                </a>
              </div>
              <div class="sidebar-toggler x">
                <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
              </div>
            </div>
          </div>
          <div class="sidebar-menu">
            <ul class="menu">
              <li class="sidebar-title">Menu</li>

              <li class="sidebar-item <?php if(request()->routeIs('dashboard')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-link">
                  <i class="bi bi-grid-fill"></i>
                  <span>Tableau de bord</span>
                </a>
              </li>

              <li class="sidebar-item <?php if(request()->routeIs('clients.*')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('clients.index')); ?>" class="sidebar-link">
                  <i class="bi bi-people"></i>
                  <span>Clients</span>
                </a>
              </li>
              <li class="sidebar-item <?php if(request()->routeIs('areas.*')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('areas.index')); ?>" class="sidebar-link">
                  <i class="bi bi-geo-alt"></i>
                  <span>Zones</span>
                </a>
              </li>
              <li class="sidebar-item <?php if(request()->routeIs('departments.*')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('departments.index')); ?>" class="sidebar-link">
                  <i class="bi bi-building"></i>
                  <span>Départements</span>
                </a>
              </li>
              <li class="sidebar-item <?php if(request()->routeIs('employees.*')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('employees.index')); ?>" class="sidebar-link">
                  <i class="bi bi-person"></i>
                  <span>Employées</span>
                </a>
              </li>
              <li class="sidebar-item <?php if(request()->routeIs('devices.*')): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('devices.index')); ?>" class="sidebar-link">
                  <i class="bi bi-hdd"></i>
                  <span>Appareils</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div><?php /**PATH D:\My Project\CheckTime\resources\views/components/side-bar.blade.php ENDPATH**/ ?>