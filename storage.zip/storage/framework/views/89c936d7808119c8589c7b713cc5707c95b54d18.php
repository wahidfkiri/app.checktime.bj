

<?php $__env->startSection('content'); ?>
<div id="main" class="layout-navbar navbar-fixed">
    <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = App\View\Components\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
    <div id="main-content">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Plannings des Employés</h3>
                        <p class="text-subtitle text-muted">Gestion des emplois du temps individuels</p>
                    </div>
                    <div class="col-12 col-md-6 order-md-2 order-first">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                                </li>
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(url('plannings.index')); ?>">Plannings</a>
                                </li>
                                <li class="breadcrumb-item active">Plannings employés</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <section class="section">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="employee_filter">Employé</label>
                                    <select class="form-control" id="employee_filter">
                                        <option value="">Tous</option>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($employee->id); ?>">
                                            <?php echo e($employee->emp_code); ?> - <?php echo e($employee->first_name); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="type_filter">Type</label>
                                    <select class="form-control" id="type_filter">
                                        <option value="">Tous</option>
                                        <option value="fixe">Fixe</option>
                                        <option value="rotation">Rotation</option>
                                        <option value="planifie">Planifié</option>
                                        <option value="exception">Exception</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="start_date_filter">Du</label>
                                    <input type="date" class="form-control" id="start_date_filter">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="end_date_filter">Au</label>
                                    <input type="date" class="form-control" id="end_date_filter">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="status_filter">Statut</label>
                                    <select class="form-control" id="status_filter">
                                        <option value="">Tous</option>
                                        <option value="1">Actif</option>
                                        <option value="0">Inactif</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group text-start">
                                    <label class="form-label d-block" style="margin-bottom:0px;">&nbsp;</label>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-success" id="create-schedule-button" data-bs-toggle="modal" data-bs-target="#createScheduleModal">
                                            <i class="bi bi-plus-circle me-1"></i> Nouveau
                                        </button>
                                        <!-- <button type="button" class="btn btn-primary" id="import-schedule-button" data-bs-toggle="modal" data-bs-target="#importScheduleModal">
                                            <i class="bi bi-upload me-1"></i> Importer
                                        </button> -->
                                        <button type="button" class="btn btn-info" id="export_pdf_btn">
                                            <i class="bi bi-file-earmark-pdf me-1"></i> Exporter PDF
                                        </button>
                                        <button type="button" class="btn btn-secondary" id="reset_filters">
                                            <i class="bi bi-x-circle me-1"></i> Réinitialiser
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="schedules-table" class="table table-striped table-hover dt-responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <!-- <th>#</th> -->
                                        <!-- <th>Matricule</th> -->
                                        <th>Employé</th>
                                        <th>Période</th>
                                        <th>Type</th>
                                        <th>Horaire</th>
                                        <th>Heures</th>
                                        <th>Durée</th>
                                        <th>Travail</th>
                                        <th>Statut</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<!-- Modal création multiple -->
<div class="modal fade" id="createScheduleModal" tabindex="-1" aria-labelledby="createScheduleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createScheduleModalLabel">Créer des plannings</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="createScheduleForm">
                <div class="modal-body">
                    <!-- Section pour sélection multiple d'employés -->
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">Sélection d'employés <span class="text-danger">*</span></label>
                                <div class="d-flex gap-2 mb-2">
                                    <select class="form-control" id="employee_id" name="employee_id">
                                        <option value="">Sélectionner un employé</option>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($employee->id); ?>">
                                            <?php echo e($employee->emp_code); ?> - <?php echo e($employee->full_name); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="button" class="btn btn-outline-primary" id="addEmployeeBtn">
                                        <i class="bi bi-plus"></i>
                                    </button>
                                </div>
                                
                                <!-- Liste des employés sélectionnés -->
                                <div id="selectedEmployeesContainer" class="d-none">
                                    <label class="form-label">Employés sélectionnés:</label>
                                    <div id="selectedEmployeesList" class="border rounded p-2 mb-2" style="max-height: 150px; overflow-y: auto;">
                                        <!-- Les employés sélectionnés apparaîtront ici -->
                                    </div>
                                </div>
                                
                                <!-- Option pour tous les employés -->
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="select_all_employees">
                                    <label class="form-check-label" for="select_all_employees">
                                        Sélectionner tous les employés
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Section pour plage de dates -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="start_date" class="form-label">Date début<span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="start_date" name="start_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="end_date" class="form-label">Date fin<span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="end_date" name="end_date" required>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Option pour jours spécifiques -->
                    <div class="row mb-3 d-none">
                        <div class="col-md-12">
                            <label class="form-label">Jours à appliquer:</label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input day-checkbox" type="checkbox" id="day_all" value="all" checked>
                                <label class="form-check-label" for="day_all">Tous les jours</label>
                            </div>
                            <?php $__currentLoopData = ['Lun' => 1, 'Mar' => 2, 'Mer' => 3, 'Jeu' => 4, 'Ven' => 5, 'Sam' => 6, 'Dim' => 7]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayName => $dayValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input day-checkbox" type="checkbox" id="day_<?php echo e($dayValue); ?>" value="<?php echo e($dayValue); ?>" checked>
                                <label class="form-check-label" for="day_<?php echo e($dayValue); ?>"><?php echo e($dayName); ?></label>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="schedule_type" class="form-label">Type de planning <span class="text-danger">*</span></label>
                                <select class="form-control" id="schedule_type" name="schedule_type" required>
                                    <option value="planifie">Planifié</option>
                                    <option value="fixe">Fixe</option>
                                    <option value="rotation">Rotation</option>
                                    <option value="exception">Exception</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="work_hour_type_id" class="form-label">Type d'horaire</label>
                                <select class="form-control" id="work_hour_type_id" name="work_hour_type_id">
                                    <option value="">Sélectionner un horaire</option>
                                    <?php $__currentLoopData = $workHourTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>" 
                                            data-start="<?php echo e($type->start_time); ?>"
                                            data-end="<?php echo e($type->end_time); ?>"
                                            data-break="<?php echo e($type->break_minutes); ?>">
                                        <?php echo e($type->name); ?> (<?php echo e(date('H:i', strtotime($type->start_time))); ?> - <?php echo e(date('H:i', strtotime($type->end_time))); ?>)
                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="form-text">Laisser vide pour horaire personnalisé</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row" id="custom_hours_section" style="display: none;">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="start_time" class="form-label">Heure début</label>
                                <input type="time" class="form-control" id="start_time" name="start_time">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="end_time" class="form-label">Heure fin</label>
                                <input type="time" class="form-control" id="end_time" name="end_time">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="break_minutes" class="form-label">Pause (min)</label>
                                <input type="number" class="form-control" id="break_minutes" name="break_minutes" min="0" max="240" value="60">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control" id="notes" name="notes" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mt-4">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="is_working_day" name="is_working_day" checked>
                                    <label class="form-check-label" for="is_working_day">
                                        Jour travaillé
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" id="is_active" name="is_active" checked>
                                    <label class="form-check-label" for="is_active">
                                        Actif
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="override_existing" name="override_existing">
                                    <label class="form-check-label" for="override_existing">
                                        Remplacer si existe déjà
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary" id="submit-create-schedule">
                        <span id="create-schedule-text">Créer pour tous les sélectionnés</span>
                        <span id="create-schedule-spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal édition -->
<div class="modal fade" id="editScheduleModal" tabindex="-1" aria-labelledby="editScheduleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editScheduleModalLabel">Modifier le planning</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editScheduleForm">
                <div class="modal-body">
                    <input type="hidden" id="edit_schedule_id">
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">Employé</label>
                                <div class="form-control" id="edit_employee_name" style="background-color: #f8f9fa;"></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_schedule_date" class="form-label">Date début<span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="edit_start_date" name="start_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_schedule_date" class="form-label">Date fin<span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="edit_end_date" name="end_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_schedule_type" class="form-label">Type<span class="text-danger">*</span></label>
                                <select class="form-control" id="edit_schedule_type" name="schedule_type" required>
                                    <option value="planifie">Planifié</option>
                                    <option value="fixe">Fixe</option>
                                    <option value="rotation">Rotation</option>
                                    <option value="exception">Exception</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="edit_work_hour_type_id" class="form-label">Type d'horaire</label>
                                <select class="form-control" id="edit_work_hour_type_id" name="work_hour_type_id">
                                    <option value="">Sélectionner un horaire</option>
                                    <?php $__currentLoopData = $workHourTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type->id); ?>">
                                        <?php echo e($type->name); ?> (<?php echo e(date('H:i', strtotime($type->start_time))); ?> - <?php echo e(date('H:i', strtotime($type->end_time))); ?>)
                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                   
                    
                    <div class="row" id="edit_custom_hours_section" style="display: none;">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_start_time" class="form-label">Heure début</label>
                                <input type="time" class="form-control" id="edit_start_time" name="start_time">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_end_time" class="form-label">Heure fin</label>
                                <input type="time" class="form-control" id="edit_end_time" name="end_time">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="edit_break_minutes" class="form-label">Pause (min)</label>
                                <input type="number" class="form-control" id="edit_break_minutes" name="break_minutes" min="0" max="240" value="60">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label for="edit_notes" class="form-label">Notes</label>
                                <textarea class="form-control" id="edit_notes" name="notes" rows="2"></textarea>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mt-4">
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" id="edit_is_working_day" name="is_working_day">
                                    <label class="form-check-label" for="edit_is_working_day">
                                        Jour travaillé
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active">
                                    <label class="form-check-label" for="edit_is_active">
                                        Actif
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary" id="submit-edit-schedule">
                        <span id="edit-schedule-text">Modifier</span>
                        <span id="edit-schedule-spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal importation -->
<div class="modal fade" id="importScheduleModal" tabindex="-1" aria-labelledby="importScheduleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="importScheduleModalLabel">Importer des plannings</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="importScheduleForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Format CSV requis avec colonnes: <br>
                        <code>matricule,date,horaire,jour_travaille(Oui/Non),notes</code>
                    </div>
                    
                    <div class="mb-3">
                        <label for="import_file" class="form-label">Fichier CSV/Excel</label>
                        <input type="file" class="form-control" id="import_file" name="import_file" accept=".csv,.xlsx,.xls" required>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="import_override" name="override">
                            <label class="form-check-label" for="import_override">
                                Remplacer les plannings existants
                            </label>
                        </div>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        Les horaires doivent correspondre aux types d'horaires existants.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary" id="submit-import-schedule">
                        <i class="bi bi-upload me-1"></i> Importer
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal export PDF -->
<div class="modal fade" id="exportPdfModal" tabindex="-1" aria-labelledby="exportPdfModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exportPdfModalLabel">Exporter en PDF</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="exportPdfForm">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="pdf_start_date" class="form-label">Date début</label>
                                <input type="date" class="form-control" id="pdf_start_date" name="start_date">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="pdf_end_date" class="form-label">Date fin</label>
                                <input type="date" class="form-control" id="pdf_end_date" name="end_date">
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="pdf_employee_filter" class="form-label">Employé(s)</label>
                        <select class="form-control" id="pdf_employee_filter" name="employee_id" multiple style="height: 150px;">
                            <option value="">Tous les employés</option>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($employee->id); ?>">
                                <?php echo e($employee->emp_code); ?> - <?php echo e($employee->full_name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="pdf_group_by_employee" name="group_by_employee" checked>
                            <label class="form-check-label" for="pdf_group_by_employee">
                                Grouper par employé
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary" id="submit-export-pdf">
                        <i class="bi bi-file-earmark-pdf me-1"></i> Générer PDF
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    // ============================================
    // VARIABLES GLOBALES
    // ============================================
    let table;
    let selectedEmployees = [];
    
    // ============================================
    // INITIALISATION DATATABLE
    // ============================================
    table = $('#schedules-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?php echo e(route('employee-schedules.index')); ?>",
            data: function (d) {
                d.employee_id = $('#employee_filter').val();
                d.schedule_type = $('#type_filter').val();
                d.start_date = $('#start_date_filter').val();
                d.end_date = $('#end_date_filter').val();
                d.is_active = $('#status_filter').val();
            }
        },
        columns: [
            // { 
            //     data: 'DT_RowIndex', 
            //     name: 'DT_RowIndex',
            //     orderable: false, 
            //     searchable: false 
            // },
            // { 
            //     data: 'matricule', 
            //     name: 'employee.emp_code'
            // },
            { 
                data: 'employee_name', 
                name: 'employee.full_name'
            },
            { 
                data: 'date_range',
                name: 'start_date',
                orderable: true,
                searchable: true
            },
            { 
                data: 'schedule_type_badge', 
                name: 'schedule_type'
            },
            { 
                data: 'formatted_time', 
                name: 'work_hour_type_id'
            },
            { 
                data: 'work_hour_type_name', 
                name: 'workHourType.name'
            },
            { 
                data: 'total_hours',
                orderable: false,
                searchable: false
            },
            { 
                data: 'working_day_badge', 
                name: 'is_working_day'
            },
            { 
                data: 'status_badge', 
                name: 'is_active'
            },
            { 
                data: 'actions', 
                name: 'actions',
                orderable: false, 
                searchable: false 
            }
        ],
        language: { 
            url: "//cdn.datatables.net/plug-ins/1.10.25/i18n/French.json" 
        },
        pageLength: 25,
        responsive: true,
        order: [[3, 'desc']], // Trier par date par défaut
        dom: '<"top"<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>>rt<"bottom"<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>>',
        drawCallback: function(settings) {
            // Initialiser les tooltips après le chargement
            $('[data-bs-toggle="tooltip"]').tooltip();
        }
    });
    
    // ============================================
    // GESTION DES EMPLOYÉS MULTIPLES
    // ============================================
    $('#addEmployeeBtn').on('click', function() {
        let employeeId = $('#employee_id').val();
        let employeeText = $('#employee_id option:selected').text();
        
        if (employeeId && !selectedEmployees.includes(employeeId)) {
            selectedEmployees.push(employeeId);
            updateSelectedEmployeesList();
        }
    });
    
    function updateSelectedEmployeesList() {
        let listHtml = '';
        
        selectedEmployees.forEach((id, index) => {
            let employeeText = $(`#employee_id option[value="${id}"]`).text();
            listHtml += `
                <div class="selected-employee-item d-flex justify-content-between align-items-center mb-1 p-1 bg-light rounded">
                    <span>${employeeText}</span>
                    <button type="button" class="btn btn-sm btn-danger remove-employee-btn" data-id="${id}">
                        <i class="bi bi-x"></i>
                    </button>
                </div>
            `;
        });
        
        $('#selectedEmployeesList').html(listHtml);
        
        if (selectedEmployees.length > 0) {
            $('#selectedEmployeesContainer').removeClass('d-none');
        } else {
            $('#selectedEmployeesContainer').addClass('d-none');
        }
    }
    
    // Supprimer un employé
    $(document).on('click', '.remove-employee-btn', function() {
        let id = $(this).data('id');
        selectedEmployees = selectedEmployees.filter(empId => empId !== id);
        updateSelectedEmployeesList();
    });
    
    // Sélectionner tous les employés
    $('#select_all_employees').on('change', function() {
        if ($(this).is(':checked')) {
            selectedEmployees = [];
            $('#employee_id option').each(function() {
                if ($(this).val()) {
                    selectedEmployees.push($(this).val());
                }
            });
            updateSelectedEmployeesList();
            $('#employee_id').prop('disabled', true);
            $('#addEmployeeBtn').prop('disabled', true);
        } else {
            selectedEmployees = [];
            updateSelectedEmployeesList();
            $('#employee_id').prop('disabled', false);
            $('#addEmployeeBtn').prop('disabled', false);
        }
    });
    
    // ============================================
    // GESTION DES JOURS
    // ============================================
    $('#day_all').on('change', function() {
        $('.day-checkbox').not('#day_all').prop('checked', $(this).is(':checked'));
    });
    
    $('.day-checkbox').not('#day_all').on('change', function() {
        if (!$('.day-checkbox').not('#day_all').filter(':checked').length) {
            $('#day_all').prop('checked', false);
        } else if ($('.day-checkbox').not('#day_all').filter(':checked').length === 7) {
            $('#day_all').prop('checked', true);
        }
    });
    
    // ============================================
    // GESTION DES HORAIRES
    // ============================================
    $('#work_hour_type_id').on('change', function() {
        if ($(this).val()) {
            let selectedOption = $(this).find('option:selected');
            $('#start_time').val(selectedOption.data('start'));
            $('#end_time').val(selectedOption.data('end'));
            $('#break_minutes').val(selectedOption.data('break'));
            $('#custom_hours_section').hide();
        } else {
            $('#custom_hours_section').show();
        }
    });
    
    $('#edit_work_hour_type_id').on('change', function() {
        if ($(this).val()) {
            $('#edit_custom_hours_section').hide();
        } else {
            $('#edit_custom_hours_section').show();
        }
    });
    
    // ============================================
    // CREATE - Création multiple
    // ============================================
    $('#createScheduleForm').on('submit', function(e) {
        e.preventDefault();
        
        // Récupérer les jours sélectionnés
        let daysOfWeek = [];
        if (!$('#day_all').is(':checked')) {
            $('.day-checkbox').not('#day_all').filter(':checked').each(function() {
                daysOfWeek.push(parseInt($(this).val()));
            });
        }
        
        // Vérifier si on utilise tous les employés ou une sélection
        let employeeIds = $('#select_all_employees').is(':checked') 
            ? 'all' 
            : (selectedEmployees.length > 0 ? selectedEmployees : [$('#employee_id').val()]);
        
        if (!employeeIds || (Array.isArray(employeeIds) && employeeIds.length === 0)) {
            Swal.fire('Erreur', 'Veuillez sélectionner au moins un employé', 'error');
            return;
        }
        
        // Validation des dates
        let startDate = $('#start_date').val();
        let endDate = $('#end_date').val();
        
        if (!startDate || !endDate) {
            Swal.fire('Erreur', 'Veuillez sélectionner une plage de dates', 'error');
            return;
        }
        
        if (new Date(endDate) < new Date(startDate)) {
            Swal.fire('Erreur', 'La date de fin doit être postérieure à la date de début', 'error');
            return;
        }
        
        // Préparer les données
        let formData = {
            employee_ids: employeeIds,
            start_date: startDate,
            end_date: endDate,
            schedule_type: $('#schedule_type').val(),
            work_hour_type_id: $('#work_hour_type_id').val() || null,
            start_time: $('#start_time').val() || null,
            end_time: $('#end_time').val() || null,
            break_minutes: $('#break_minutes').val() || 0,
            is_working_day: $('#is_working_day').is(':checked') ? 1 : 0,
            is_active: $('#is_active').is(':checked') ? 1 : 0,
            notes: $('#notes').val(),
            days_of_week: daysOfWeek.length > 0 ? daysOfWeek : null,
            override_existing: $('#override_existing').is(':checked') ? 1 : 0,
            _token: "<?php echo e(csrf_token()); ?>"
        };
        
        // Supprimer les champs vides
        Object.keys(formData).forEach(key => {
            if (formData[key] === '' || formData[key] === null) {
                delete formData[key];
            }
        });
        
        // Envoyer la requête
        $('#submit-create-schedule').prop('disabled', true);
        $('#create-schedule-text').addClass('d-none');
        $('#create-schedule-spinner').removeClass('d-none');
        
        $.ajax({
            url: "<?php echo e(route('employee-schedules.bulk-create')); ?>",
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $('#createScheduleModal').modal('hide');
                    $('#createScheduleForm')[0].reset();
                    selectedEmployees = [];
                    updateSelectedEmployeesList();
                    $('#select_all_employees').prop('checked', false);
                    $('#employee_id').prop('disabled', false);
                    $('#addEmployeeBtn').prop('disabled', false);
                    
                    Swal.fire({
                        icon: 'success',
                        title: 'Succès',
                        html: `<strong>${response.created} plannings créés</strong><br>
                               ${response.skipped} plannings non créés (déjà existants)<br>
                               ${response.employees_count} employés concernés`,
                        timer: 5000,
                        showConfirmButton: true
                    });
                    
                    table.ajax.reload();
                } else {
                    if (response.errors) {
                        showValidationErrors(response.errors);
                    } else {
                        Swal.fire('Erreur', response.message || 'Une erreur est survenue', 'error');
                    }
                }
            },
            error: function(xhr) {
                Swal.fire('Erreur', 'Une erreur est survenue lors de la création', 'error');
            },
            complete: function() {
                $('#submit-create-schedule').prop('disabled', false);
                $('#create-schedule-text').removeClass('d-none');
                $('#create-schedule-spinner').addClass('d-none');
            }
        });
    });
    
    // ============================================
    // EDIT - Modification
    // ============================================
    $(document).on('click', '.edit-schedule-btn', function() {
        let scheduleId = $(this).data('id');
        
        $.ajax({
            url: "<?php echo e(url('employee-schedules')); ?>/" + scheduleId + "/edit",
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    let schedule = response.data;
                    // schedule = JSON data from backend
function formatForDateInput(isoDate) {
    return new Date(isoDate.split('.')[0] + 'Z').toISOString().slice(0, 10);
}

// Set start_date
$('#edit_start_date').val(formatForDateInput(schedule.start_date));

// Set end_date
$('#edit_end_date').val(formatForDateInput(schedule.end_date));

                    // Remplir le formulaire d'édition
                    $('#edit_schedule_id').val(schedule.id);
                    $('#edit_employee_name').text(schedule.employee.first_name);
                 
                   
                    $('#edit_schedule_type').val(schedule.schedule_type);
                    $('#edit_work_hour_type_id').val(schedule.work_hour_type_id);
                    $('#edit_day_of_week').val(schedule.day_of_week);
                    $('#edit_start_time').val(schedule.start_time);
                    $('#edit_end_time').val(schedule.end_time);
                    $('#edit_break_minutes').val(schedule.break_minutes);
                    $('#edit_is_working_day').prop('checked', schedule.is_working_day);
                    $('#edit_is_active').prop('checked', schedule.is_active);
                    $('#edit_notes').val(schedule.notes);
                    
                    // Afficher/masquer les champs personnalisés
                    if (schedule.work_hour_type_id) {
                        $('#edit_custom_hours_section').hide();
                    } else {
                        $('#edit_custom_hours_section').show();
                    }
                    
                    $('#editScheduleModal').modal('show');
                } else {
                    Swal.fire('Erreur', response.message, 'error');
                }
            }
        });
    });
    
    // Soumission du formulaire d'édition
    $('#editScheduleForm').on('submit', function(e) {
        e.preventDefault();
         // Validation des dates
        let startDate = $('#edit_start_date').val();
        let endDate = $('#edit_end_date').val();
        
        if (!startDate || !endDate) {
            Swal.fire('Erreur', 'Veuillez sélectionner une plage de dates', 'error');
            return;
        }
        
        if (new Date(endDate) < new Date(startDate)) {
            Swal.fire('Erreur', 'La date de fin doit être postérieure à la date de début', 'error');
            return;
        }
        let scheduleId = $('#edit_schedule_id').val();
        
        let formData = {
            schedule_date: $('#edit_schedule_date').val(),
            schedule_type: $('#edit_schedule_type').val(),
            work_hour_type_id: $('#edit_work_hour_type_id').val() || null,
            day_of_week: $('#edit_day_of_week').val(),
            start_date: startDate,
            end_date: endDate,
            start_time: $('#edit_start_time').val() || null,
            end_time: $('#edit_end_time').val() || null,
            break_minutes: $('#edit_break_minutes').val() || 0,
            is_working_day: $('#edit_is_working_day').is(':checked') ? 1 : 0,
            is_active: $('#edit_is_active').is(':checked') ? 1 : 0,
            notes: $('#edit_notes').val(),
            _token: "<?php echo e(csrf_token()); ?>",
            _method: 'PUT'
        };
        
        // Supprimer les champs vides
        Object.keys(formData).forEach(key => {
            if (formData[key] === '' || formData[key] === null) {
                delete formData[key];
            }
        });
        
        $('#submit-edit-schedule').prop('disabled', true);
        $('#edit-schedule-text').addClass('d-none');
        $('#edit-schedule-spinner').removeClass('d-none');
        
        $.ajax({
            url: "<?php echo e(url('employee-schedules')); ?>/" + scheduleId,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $('#editScheduleModal').modal('hide');
                    
                    Swal.fire({
                        icon: 'success',
                        title: 'Succès',
                        text: response.message,
                        timer: 3000,
                        showConfirmButton: false
                    });
                    
                    table.ajax.reload();
                } else {
                    showValidationErrors(response.errors);
                }
            },
            error: function(xhr) {
                Swal.fire('Erreur', 'Une erreur est survenue', 'error');
            },
            complete: function() {
                $('#submit-edit-schedule').prop('disabled', false);
                $('#edit-schedule-text').removeClass('d-none');
                $('#edit-schedule-spinner').addClass('d-none');
            }
        });
    });
    
    // ============================================
    // DELETE - Suppression
    // ============================================
    $(document).on('click', '.delete-schedule-btn', function() {
        let scheduleId = $(this).data('id');
        let employeeName = $(this).data('employee');
        let scheduleDate = $(this).data('date');
        
        Swal.fire({
            title: 'Confirmer la suppression',
            html: `Êtes-vous sûr de vouloir supprimer le planning de <strong>${employeeName}</strong> du <strong>${scheduleDate}</strong> ?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "<?php echo e(url('employee-schedules')); ?>/" + scheduleId,
                    type: 'DELETE',
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        _method: 'DELETE'
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Succès',
                                text: response.message,
                                timer: 3000,
                                showConfirmButton: false
                            });
                            
                            table.ajax.reload();
                        } else {
                            Swal.fire('Erreur', response.message, 'error');
                        }
                    },
                    error: function(xhr) {
                        Swal.fire('Erreur', 'Une erreur est survenue', 'error');
                    }
                });
            }
        });
    });
    
  // ============================================
// EXPORT PDF
// ============================================
$('#export_pdf_btn').on('click', function() {
    // Remplir les dates par défaut
    let today = new Date();
    let firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    let lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    $('#pdf_start_date').val(firstDay.toISOString().split('T')[0]);
    $('#pdf_end_date').val(lastDay.toISOString().split('T')[0]);
    
    // Réinitialiser la sélection
    $('#pdf_employee_filter').val('');
    
    $('#exportPdfModal').modal('show');
});

$('#exportPdfForm').on('submit', function(e) {
    e.preventDefault();
    
    let startDate = $('#pdf_start_date').val();
    let endDate = $('#pdf_end_date').val();
    let employeeIds = $('#pdf_employee_filter').val();
    let groupByEmployee = $('#pdf_group_by_employee').is(':checked');
    
    if (!startDate || !endDate) {
        Swal.fire('Erreur', 'Veuillez sélectionner une plage de dates', 'error');
        return;
    }
    
    if (new Date(endDate) < new Date(startDate)) {
        Swal.fire('Erreur', 'La date de fin doit être postérieure à la date de début', 'error');
        return;
    }
    
    let formData = {
        format: 'pdf',
        start_date: startDate,
        end_date: endDate,
        group_by_employee: groupByEmployee ? 1 : 0,
        _token: "<?php echo e(csrf_token()); ?>"
    };
    
    // Ajouter les IDs d'employés si sélectionnés
    if (employeeIds && employeeIds.length > 0 && employeeIds[0] !== '') {
        formData.employee_ids = employeeIds;
    }
    
    $('#submit-export-pdf').prop('disabled', true);
    
    Swal.fire({
        title: 'Génération du PDF',
        text: 'Veuillez patienter...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    $.ajax({
        url: "<?php echo e(route('employee-schedules.export')); ?>",
        type: 'POST',
        data: formData,
        success: function(response) {
            Swal.close();
            
            if (response.success) {
                // Télécharger le PDF
                let link = document.createElement('a');
                link.href = response.download_url;
                link.download = response.filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                $('#exportPdfModal').modal('hide');
                
                // Afficher un message de succès
                Swal.fire({
                    icon: 'success',
                    title: 'PDF généré avec succès',
                    html: `Fichier téléchargé: <strong>${response.filename}</strong><br>
                           <br>
                           <small>${response.data.total_schedules} plannings exportés<br>
                           ${response.data.total_employees} employés</small>`,
                    timer: 3000,
                    showConfirmButton: false
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    html: response.message || 'Erreur lors de la génération du PDF',
                    showConfirmButton: true
                });
            }
        },
        error: function(xhr, status, error) {
            Swal.close();
            
            let errorMessage = 'Une erreur est survenue lors de la génération du PDF';
            
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage = xhr.responseJSON.message;
            } else if (xhr.statusText) {
                errorMessage = xhr.statusText;
            }
            
            Swal.fire({
                icon: 'error',
                title: 'Erreur ' + xhr.status,
                text: errorMessage,
                showConfirmButton: true
            });
        },
        complete: function() {
            $('#submit-export-pdf').prop('disabled', false);
        }
    });
});
    
    $('#exportPdfForm').on('submit', function(e) {
        e.preventDefault();
        
        let startDate = $('#pdf_start_date').val();
        let endDate = $('#pdf_end_date').val();
        let employeeIds = $('#pdf_employee_filter').val();
        let groupByEmployee = $('#pdf_group_by_employee').is(':checked');
        
        if (!startDate || !endDate) {
            Swal.fire('Erreur', 'Veuillez sélectionner une plage de dates', 'error');
            return;
        }
        
        if (new Date(endDate) < new Date(startDate)) {
            Swal.fire('Erreur', 'La date de fin doit être postérieure à la date de début', 'error');
            return;
        }
        
        let formData = {
            format: 'pdf',
            start_date: startDate,
            end_date: endDate,
            group_by_employee: groupByEmployee ? 1 : 0,
            _token: "<?php echo e(csrf_token()); ?>"
        };
        
        if (employeeIds && employeeIds.length > 0) {
            formData.employee_ids = employeeIds;
        }
        
        $('#submit-export-pdf').prop('disabled', true);
        
        Swal.fire({
            title: 'Génération du PDF',
            text: 'Veuillez patienter...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
        
        $.ajax({
            url: "<?php echo e(route('employee-schedules.export')); ?>",
            type: 'POST',
            data: formData,
            success: function(response) {
                Swal.close();
                
                if (response.success) {
                    // Télécharger le PDF
                    let link = document.createElement('a');
                    link.href = response.download_url;
                    link.download = response.filename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    
                    $('#exportPdfModal').modal('hide');
                } else {
                    Swal.fire('Erreur', response.message || 'Erreur lors de la génération du PDF', 'error');
                }
            },
            error: function(xhr) {
               // Swal.close();
               // Swal.fire('Erreur', 'Une erreur est survenue lors de la génération du PDF', 'error');
            },
            complete: function() {
                $('#submit-export-pdf').prop('disabled', false);
            }
        });
    });
    
    // ============================================
    // IMPORT
    // ============================================
    $('#importScheduleForm').on('submit', function(e) {
        e.preventDefault();
        
        let formData = new FormData(this);
        formData.append('_token', "<?php echo e(csrf_token()); ?>");
        
        $('#submit-import-schedule').prop('disabled', true);
        
        Swal.fire({
            title: 'Import en cours',
            text: 'Veuillez patienter...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
        
        $.ajax({
            url: "<?php echo e(route('employee-schedules.import')); ?>",
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                Swal.close();
                
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Succès',
                        html: `${response.message}<br>
                               ${response.errors && response.errors.length > 0 ? 
                                 '<br>Erreurs:<br>' + response.errors.join('<br>') : ''}`,
                        confirmButtonText: 'OK'
                    });
                    
                    $('#importScheduleModal').modal('hide');
                    $('#importScheduleForm')[0].reset();
                    table.ajax.reload();
                } else {
                    Swal.fire('Erreur', response.message, 'error');
                }
            },
            error: function(xhr) {
                Swal.close();
                Swal.fire('Erreur', 'Erreur lors de l\'import', 'error');
            },
            complete: function() {
                $('#submit-import-schedule').prop('disabled', false);
            }
        });
    });
    
    // ============================================
    // FILTRES
    // ============================================
    $('#employee_filter, #type_filter, #start_date_filter, #end_date_filter, #status_filter').on('change', function() {
        table.ajax.reload();
    });
    
    $('#reset_filters').on('click', function() {
        $('#employee_filter').val('');
        $('#type_filter').val('');
        $('#start_date_filter').val('');
        $('#end_date_filter').val('');
        $('#status_filter').val('');
        table.ajax.reload();
    });
    
    // ============================================
    // INITIALISATION DES DATES
    // ============================================
    function initializeDates() {
        let today = new Date();
        let firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        let lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        
        $('#start_date_filter').val(firstDay.toISOString().split('T')[0]);
        $('#end_date_filter').val(lastDay.toISOString().split('T')[0]);
        $('#start_date').val(today.toISOString().split('T')[0]);
        $('#end_date').val(today.toISOString().split('T')[0]);
    }
    
    initializeDates();
    
    // ============================================
    // FONCTIONS UTILITAIRES
    // ============================================
    function showValidationErrors(errors) {
        if (typeof errors === 'string') {
            Swal.fire('Erreur', errors, 'error');
            return;
        }
        
        let errorHtml = '<ul class="text-start">';
        if (typeof errors === 'object') {
            $.each(errors, function(field, messages) {
                if (Array.isArray(messages)) {
                    $.each(messages, function(index, message) {
                        errorHtml += `<li>${field}: ${message}</li>`;
                    });
                } else {
                    errorHtml += `<li>${field}: ${messages}</li>`;
                }
            });
        }
        errorHtml += '</ul>';
        
        Swal.fire({
            icon: 'error',
            title: 'Erreur de validation',
            html: errorHtml
        });
    }
    
    // Réinitialiser le formulaire de création
    $('#createScheduleModal').on('hidden.bs.modal', function() {
        $('#createScheduleForm')[0].reset();
        selectedEmployees = [];
        updateSelectedEmployeesList();
        $('#select_all_employees').prop('checked', false);
        $('#employee_id').prop('disabled', false);
        $('#addEmployeeBtn').prop('disabled', false);
        initializeDates();
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\CheckTime-Client\resources\views/employee-schedules/index.blade.php ENDPATH**/ ?>