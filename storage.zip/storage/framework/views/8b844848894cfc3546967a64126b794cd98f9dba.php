
<?php $__env->startSection('content'); ?>
<div id="main" class="layout-navbar navbar-fixed">
    <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = App\View\Components\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
    <div id="main-content">
        <div class="page-heading">
            <div class="page-title">
                <div class="row">
                    <div class="col-12 col-md-6 order-md-1 order-last">
                        <h3>Tableau de Bord Super Admin</h3>
                        <p class="text-subtitle text-muted">
                            Vue d'ensemble du système et statistiques globales
                        </p>
                    </div>
                    <div class="col-12 col-md-6 order-md-2 order-first">
                        <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Super Admin</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <!-- Statistiques Principales -->
            <section class="section">
                <div class="row">
                    <!-- Clients -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4-5">
                                <div class="row">
                                    <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                        <div class="stats-icon blue mb-2">
                                            <i class="fas fa-building"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                        <h6 class="text-muted font-semibold">Clients</h6>
                                        <h4 class="font-extrabold mb-0"><?php echo e($totalClients ?? 0); ?></h4>
                                        <small class="text-success">
                                            <i class="fas fa-arrow-up"></i> <?php echo e($activeClients ?? 0); ?> actifs
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Employés Totaux -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4-5">
                                <div class="row">
                                    <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                        <div class="stats-icon purple mb-2">
                                            <i class="fas fa-users"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                        <h6 class="text-muted font-semibold">Employés</h6>
                                        <h4 class="font-extrabold mb-0"><?php echo e($totalEmployees ?? 0); ?></h4>
                                        <small class="text-success">
                                            <i class="fas fa-user-check"></i> <?php echo e($activeEmployees ?? 0); ?> actifs
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Départements -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4-5">
                                <div class="row">
                                    <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                        <div class="stats-icon green mb-2">
                                            <i class="fas fa-layer-group"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                        <h6 class="text-muted font-semibold">Départements</h6>
                                        <h4 class="font-extrabold mb-0"><?php echo e($totalDepartments ?? 0); ?></h4>
                                        <small class="text-info">
                                            <i class="fas fa-sitemap"></i> <?php echo e($hierarchicalDepartments ?? 0); ?> hiérarchiques
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Zones -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4-5">
                                <div class="row">
                                    <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                        <div class="stats-icon orange mb-2">
                                            <i class="fas fa-map-marked-alt"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                        <h6 class="text-muted font-semibold">Zones</h6>
                                        <h4 class="font-extrabold mb-0"><?php echo e($totalZones ?? 0); ?></h4>
                                        <small class="text-warning">
                                            <i class="fas fa-globe"></i> Répartition sur <?php echo e($clientsWithZones ?? 0); ?> clients
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Deuxième Ligne de Statistiques -->
                <div class="row mt-3 d-none">
                    <!-- Appareils -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4-5">
                                <div class="row">
                                    <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                        <div class="stats-icon red mb-2">
                                            <i class="fas fa-fingerprint"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                        <h6 class="text-muted font-semibold">Appareils</h6>
                                        <h4 class="font-extrabold mb-0"><?php echo e($totalDevices ?? 0); ?></h4>
                                        <small class="text-secondary">
                                            <i class="fas fa-wifi"></i> Synchronisés récemment: <?php echo e($recentlySyncedDevices ?? 0); ?>

                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Utilisateurs Plateforme -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4-5">
                                <div class="row">
                                    <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                        <div class="stats-icon indigo mb-2">
                                            <i class="fas fa-user-tie"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                        <h6 class="text-muted font-semibold">Utilisateurs</h6>
                                        <h4 class="font-extrabold mb-0"><?php echo e($totalPlatformUsers ?? 0); ?></h4>
                                        <small class="text-primary">
                                            <i class="fas fa-user-shield"></i> <?php echo e($superAdmins ?? 0); ?> super admins
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pointages Journaliers -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4-5">
                                <div class="row">
                                    <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                        <div class="stats-icon teal mb-2">
                                            <i class="fas fa-clock"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                        <h6 class="text-muted font-semibold">Pointages Aujourd'hui</h6>
                                        <h4 class="font-extrabold mb-0"><?php echo e($todayAttendance ?? 0); ?></h4>
                                        <small class="text-danger">
                                            <i class="fas fa-exclamation-triangle"></i> Retards: <?php echo e($lateToday ?? 0); ?>

                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Logs -->
                    <div class="col-lg-3 col-md-6">
                        <div class="card">
                            <div class="card-body px-4 py-4-5">
                                <div class="row">
                                    <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                                        <div class="stats-icon dark mb-2">
                                            <i class="fas fa-history"></i>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                                        <h6 class="text-muted font-semibold">Activité 7 jours</h6>
                                        <h4 class="font-extrabold mb-0"><?php echo e($recentLogs ?? 0); ?></h4>
                                        <small class="text-muted">
                                            <i class="fas fa-envelope"></i> Emails: <?php echo e($emailLogs ?? 0); ?>

                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Graphiques et Visualisations -->
            <section class="section">
                <div class="row">
                    <!-- Distribution des Clients -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>Distribution des Clients</h4>
                            </div>
                            <div class="card-body">
                                <div id="client-distribution-chart"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Employés par Client -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>Top Clients par Employés</h4>
                            </div>
                            <div class="card-body">
                                <div id="employees-by-client-chart"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tableau des Derniers Clients -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Clients Récemment Inscrits</h4>
                                <a href="<?php echo e(route('clients.index')); ?>" class="btn btn-primary btn-sm">Voir tous</a>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Raison Sociale</th>
                                                <th>Sigle</th>
                                                <th>Email</th>
                                                <th>Employés</th>
                                                <th>Zones</th>
                                                <th>Départements</th>
                                                <th>Date Inscription</th>
                                                <th>Statut</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $recentClients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($client->id); ?></td>
                                                <td>
                                                    <strong><?php echo e($client->raison_sociale); ?></strong>
                                                </td>
                                                <td><?php echo e($client->sigle ?? 'N/A'); ?></td>
                                                <td><?php echo e($client->email); ?></td>
                                                <td>
                                                    <span class="badge bg-primary">
                                                        <?php echo e($client->employees_count ?? 0); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-info">
                                                        <?php echo e($client->zones_count ?? 0); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-success">
                                                        <?php echo e($client->departments_count ?? 0); ?>

                                                    </span>
                                                </td>
                                                <td><?php echo e($client->created_at->format('d/m/Y')); ?></td>
                                                <td>
                                                    <?php if($client->is_active): ?>
                                                    <span class="badge bg-success">Actif</span>
                                                    <?php else: ?>
                                                    <span class="badge bg-danger">Inactif</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="9" class="text-center">Aucun client trouvé</td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Statistiques Détaillées -->
                <div class="row mt-4">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>Répartition par Type</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="d-flex align-items-center">
                                            <div class="stats-icon-sm blue me-3">
                                                <i class="fas fa-building"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0">Clients avec Zones</h6>
                                                <h4 class="font-extrabold mb-0"><?php echo e($clientsWithZones ?? 0); ?></h4>
                                                <small class="text-muted">Sur <?php echo e($totalClients ?? 0); ?> clients</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="d-flex align-items-center">
                                            <div class="stats-icon-sm green me-3">
                                                <i class="fas fa-users"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0">Clients avec Employés</h6>
                                                <h4 class="font-extrabold mb-0"><?php echo e($clientsWithEmployees ?? 0); ?></h4>
                                                <small class="text-muted">Déjà configurés</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-6">
                                        <div class="d-flex align-items-center">
                                            <div class="stats-icon-sm purple me-3">
                                                <i class="fas fa-sitemap"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0">Départements Racine</h6>
                                                <h4 class="font-extrabold mb-0"><?php echo e($rootDepartments ?? 0); ?></h4>
                                                <small class="text-muted">Sans parent</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="d-flex align-items-center">
                                            <div class="stats-icon-sm orange me-3">
                                                <i class="fas fa-fingerprint"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0">Clients avec Appareils</h6>
                                                <h4 class="font-extrabold mb-0"><?php echo e($clientsWithDevices ?? 0); ?></h4>
                                                <small class="text-muted">Appareils configurés</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h4>Performance du Système</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="progress mb-3">
                                            <div class="progress-bar bg-success" role="progressbar" 
                                                 style="width: <?php echo e($activeClientsPercentage ?? 0); ?>%">
                                                <?php echo e($activeClientsPercentage ?? 0); ?>%
                                            </div>
                                        </div>
                                        <small class="text-muted">Clients Actifs</small>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-12">
                                        <div class="progress mb-3">
                                            <div class="progress-bar bg-info" role="progressbar" 
                                                 style="width: <?php echo e($employeesCoveragePercentage ?? 0); ?>%">
                                                <?php echo e($employeesCoveragePercentage ?? 0); ?>%
                                            </div>
                                        </div>
                                        <small class="text-muted">Couverture Employés</small>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-12">
                                        <div class="progress mb-3">
                                            <div class="progress-bar bg-warning" role="progressbar" 
                                                 style="width: <?php echo e($zonesCoveragePercentage ?? 0); ?>%">
                                                <?php echo e($zonesCoveragePercentage ?? 0); ?>%
                                            </div>
                                        </div>
                                        <small class="text-muted">Couverture Zones</small>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-12">
                                        <div class="progress mb-3">
                                            <div class="progress-bar bg-primary" role="progressbar" 
                                                 style="width: <?php echo e($departmentsCoveragePercentage ?? 0); ?>%">
                                                <?php echo e($departmentsCoveragePercentage ?? 0); ?>%
                                            </div>
                                        </div>
                                        <small class="text-muted">Couverture Départements</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Vue d'Ensemble Graphique -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Évolution Mensuelle</h4>
                            </div>
                            <div class="card-body">
                                <div id="monthly-growth-chart"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
.stats-icon {
    width: 50px;
    height: 50px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: white;
}

.stats-icon-sm {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    color: white;
}

.stats-icon.blue { background-color: #0d6efd; }
.stats-icon.purple { background-color: #6f42c1; }
.stats-icon.green { background-color: #198754; }
.stats-icon.orange { background-color: #fd7e14; }
.stats-icon.red { background-color: #dc3545; }
.stats-icon.indigo { background-color: #6610f2; }
.stats-icon.teal { background-color: #20c997; }
.stats-icon.dark { background-color: #212529; }

.stats-icon-sm.blue { background-color: #0d6efd; }
.stats-icon-sm.green { background-color: #198754; }
.stats-icon-sm.purple { background-color: #6f42c1; }
.stats-icon-sm.orange { background-color: #fd7e14; }

.card {
    transition: transform 0.3s;
    border: 1px solid #e0e0e0;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

.progress {
    height: 10px;
    border-radius: 5px;
}

.badge {
    font-size: 0.75em;
    padding: 0.4em 0.8em;
}

.table th {
    background-color: #f8f9fa;
    font-weight: 600;
}
</style>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Graphique de distribution des clients
    var clientDistributionOptions = {
        series: [{
            name: 'Clients',
            data: <?php echo json_encode($clientDistributionData ?? [], 15, 512) ?>
        }],
        chart: {
            type: 'bar',
            height: 350,
            toolbar: {
                show: true
            }
        },
        plotOptions: {
            bar: {
                horizontal: false,
                columnWidth: '55%',
                endingShape: 'rounded'
            },
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
        },
        xaxis: {
            categories: ['Total', 'Actifs', 'Avec Zones', 'Avec Employés', 'Avec Appareils'],
        },
        yaxis: {
            title: {
                text: 'Nombre'
            }
        },
        fill: {
            opacity: 1
        },
        colors: ['#435ebe'],
        tooltip: {
            y: {
                formatter: function (val) {
                    return val + " clients"
                }
            }
        }
    };

    var clientChart = new ApexCharts(document.querySelector("#client-distribution-chart"), clientDistributionOptions);
    clientChart.render();

    // Graphique des employés par client
    var employeesByClientOptions = {
        series: [{
            data: <?php echo json_encode($topClientsEmployeesData ?? [], 15, 512) ?>
        }],
        chart: {
            type: 'bar',
            height: 350,
            toolbar: {
                show: true
            }
        },
        plotOptions: {
            bar: {
                borderRadius: 4,
                horizontal: true,
            }
        },
        dataLabels: {
            enabled: true
        },
        xaxis: {
            categories: <?php echo json_encode($topClientsLabels ?? [], 15, 512) ?>,
            title: {
                text: "Nombre d'employés"
            }
        },
        colors: ['#198754'],
        tooltip: {
            y: {
                formatter: function (val) {
                    return val + " employés"
                }
            }
        }
    };

    var employeesChart = new ApexCharts(document.querySelector("#employees-by-client-chart"), employeesByClientOptions);
    employeesChart.render();

    // Graphique de croissance mensuelle
    var monthlyGrowthOptions = {
        series: [
            {
                name: "Nouveaux Clients",
                data: <?php echo json_encode($monthlyNewClients ?? [], 15, 512) ?>
            },
            {
                name: "Nouveaux Employés",
                data: <?php echo json_encode($monthlyNewEmployees ?? [], 15, 512) ?>
            }
        ],
        chart: {
            height: 350,
            type: 'area',
            toolbar: {
                show: true
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'smooth'
        },
        xaxis: {
            type: 'datetime',
            categories: <?php echo json_encode($monthlyLabels ?? [], 15, 512) ?>
        },
        yaxis: {
            title: {
                text: 'Nombre'
            }
        },
        tooltip: {
            x: {
                format: 'MMM yyyy'
            },
        },
        colors: ['#0d6efd', '#20c997'],
        fill: {
            type: 'gradient',
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.7,
                opacityTo: 0.3,
                stops: [0, 90, 100]
            }
        }
    };

    var monthlyChart = new ApexCharts(document.querySelector("#monthly-growth-chart"), monthlyGrowthOptions);
    monthlyChart.render();

    // Rafraîchir les statistiques toutes les 5 minutes
    setInterval(function() {
        fetch('/admin/dashboard/stats')
            .then(response => response.json())
            .then(data => {
                // Mettre à jour les valeurs dynamiques
                updateStats(data);
            })
            .catch(error => console.error('Error:', error));
    }, 300000); // 5 minutes
});

function updateStats(data) {
    // Mettre à jour les compteurs dynamiquement
    const counters = [
        { id: 'totalClients', value: data.totalClients },
        { id: 'activeClients', value: data.activeClients },
        { id: 'totalEmployees', value: data.totalEmployees },
        // Ajouter d'autres compteurs selon besoin
    ];

    counters.forEach(counter => {
        const element = document.querySelector(`[data-counter="${counter.id}"]`);
        if (element) {
            animateCounter(element, counter.value);
        }
    });
}

function animateCounter(element, targetValue) {
    let current = parseInt(element.innerText);
    const increment = targetValue > current ? 1 : -1;
    
    const timer = setInterval(() => {
        current += increment;
        element.innerText = current;
        
        if (current === targetValue) {
            clearInterval(timer);
        }
    }, 10);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\CheckTime\resources\views/dashboard.blade.php ENDPATH**/ ?>