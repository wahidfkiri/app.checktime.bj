<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Carbon\Carbon;

class EmployeeSchedule extends Model
{
    protected $fillable = [
        'client_id',
        'employee_id',
        'schedule_type',
        'day_of_week',
        'specific_date',
        'work_hour_type_id',
        'schedule_date',
        'is_working_day',
        'start_time',
        'end_time',
        'break_minutes',
        'repeat_weekly',
        'start_date',
        'end_date',
        'custom_days',
        'notes',
        'is_active',
        'work_hour_type_id' // Ajouter cette ligne si vous ajoutez la relation
    ];

    protected $casts = [
        'custom_days' => 'array',
        'repeat_weekly' => 'boolean',
        'is_active' => 'boolean',
        'is_working_day' => 'boolean',
        'schedule_date' => 'date',
        'start_time' => 'datetime:H:i',
        'end_time' => 'datetime:H:i',
        'specific_date' => 'date',
        'start_date' => 'date',
        'end_date' => 'date'
    ];

    // Relations
    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function workHourType(): BelongsTo
    {
        return $this->belongsTo(WorkHourType::class);
    }

    public function dailyPlannings()
    {
        return $this->hasMany(DailyPlanning::class, 'schedule_id');
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeForDate($query, $date)
    {
        $dayOfWeek = Carbon::parse($date)->dayOfWeekIso; // 1=Lundi, 7=Dimanche
        
        return $query->where(function($q) use ($date, $dayOfWeek) {
            // Pour les horaires spécifiques à une date
            $q->where('specific_date', $date)
              // Pour les horaires fixes par jour de semaine
              ->orWhere(function($q2) use ($dayOfWeek, $date) {
                  $q2->where('schedule_type', 'fixe')
                     ->where('day_of_week', $dayOfWeek)
                     ->where('repeat_weekly', true)
                     ->where(function($q3) use ($date) {
                         $q3->whereNull('start_date')
                            ->orWhere('start_date', '<=', $date);
                     })
                     ->where(function($q3) use ($date) {
                         $q3->whereNull('end_date')
                            ->orWhere('end_date', '>=', $date);
                     });
              })
              // Pour les horaires planifiés (custom_days)
              ->orWhere(function($q2) use ($date) {
                  $dayName = Carbon::parse($date)->locale('fr')->dayName;
                  $q2->where('schedule_type', 'planifie')
                     ->whereJsonContains('custom_days', strtolower($dayName));
              });
        });
    }

    public function scopeForEmployee($query, $employeeId)
    {
        return $query->where('employee_id', $employeeId);
    }

    // Méthodes utiles
    public function getDayNameAttribute()
    {
        $days = ['', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
        return $days[$this->day_of_week] ?? null;
    }

    public function getFormattedTimeAttribute()
    {
        if ($this->start_time && $this->end_time) {
            return date('H:i', strtotime($this->start_time)) . ' - ' . date('H:i', strtotime($this->end_time));
        }
        
        if ($this->workHourType) {
            return $this->workHourType->formatted_hours;
        }
        
        return null;
    }

    public function getTotalWorkMinutesAttribute()
    {
        if ($this->start_time && $this->end_time) {
            $start = strtotime($this->start_time);
            $end = strtotime($this->end_time);
            
            if ($end < $start) {
                $end = strtotime($this->end_time . ' +1 day');
            }
            
            return (($end - $start) / 60) - $this->break_minutes;
        }
        
        if ($this->workHourType) {
            return $this->workHourType->total_work_minutes;
        }
        
        return 0;
    }
}