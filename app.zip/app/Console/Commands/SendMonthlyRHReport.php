<?php

namespace App\Console\Commands;

use App\Models\Client;
use App\Models\Employee;
use App\Models\Device;
use App\Models\EmployeeSchedule;
use App\Models\Leave;
use App\Models\EmployeePermission;
use App\Models\Setting;
use App\Models\User;
use App\Mail\MonthlyRHReport;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade\Pdf;

class SendMonthlyRHReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'reports:send-monthly-rh {--test : Mode test} {--date= : Date spécifique}';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('🚀 Début de l\'envoi des rapports mensuels RH...');
        
        // Mode test
       
            // Mode production - s'exécute uniquement le dernier jour du mois
            // $today = Carbon::now();
            $today = Carbon::create(2025, 12, 31, 9, 0, 0);
            $lastDayOfMonth = $today->copy()->endOfMonth();
            
            // if (!$today->isSameDay($lastDayOfMonth)) {
            //     $this->info('📅 Aujourd\'hui n\'est pas le dernier jour du mois. Arrêt de la commande.');
            //     return;
            // }
        
        // Calculer la période du mois (du 1er au dernier jour)
        $startOfMonth = $today->copy()->startOfMonth();
        $endOfMonth = $today->copy()->endOfMonth();
        
        $this->info("📊 Période du rapport: " . $startOfMonth->format('d/m/Y') . " au " . $endOfMonth->format('d/m/Y'));
        
        // Récupérer tous les clients actifs avec leurs utilisateurs
        $clients = Client::with('user')
            ->whereHas('user', function($query) {
                $query->where('is_active', 1);
            })
            ->get();
        
        if ($clients->isEmpty()) {
            $this->warn('❌ Aucun client actif trouvé.');
            return;
        }
        
        $this->info('👥 Nombre de clients à traiter: ' . $clients->count());
        
        $totalEmailsSent = 0;
        $clientsProcessed = 0;
        
        foreach ($clients as $client) {
            try {
                $clientsProcessed++;
                
                // Get user name for the client
                $userName = $this->getClientUserName($client);
                
                $this->info("[{$clientsProcessed}/{$clients->count()}] Traitement du client: " . $userName);
                
                // Vérifier les paramètres
                $settings = Setting::where('client_id', $client->id)->first();
                
                if (!$settings) {
                    $this->warn("⚠️  Aucun paramètre trouvé pour le client: " . $userName);
                    continue;
                }
                
                if (!$settings->email_is_active) {
                    $this->warn("❌  Emails RH désactivés pour le client: " . $userName);
                    continue;
                }
                
                if (empty($settings->email)) {
                    $this->warn("⚠️  Email RH non configuré pour le client: " . $userName);
                    continue;
                }
                
                $rhEmail = trim($settings->email);
                
                if (!filter_var($rhEmail, FILTER_VALIDATE_EMAIL)) {
                    $this->error("❌  Email RH invalide: " . $rhEmail);
                    continue;
                }
                
                $this->info("✅  Configuration OK pour " . $userName . " (" . $rhEmail . ")");
                
                // Récupérer les données du rapport
                $this->info("📊  Récupération des données du rapport...");
                $reportData = $this->getPresencePonctualiteData($client, $startOfMonth->format('Y-m-d'), $endOfMonth->format('Y-m-d'), 'all');
                
                if (empty($reportData)) {
                    $this->warn("⚠️  Aucune donnée de présence pour " . $userName);
                    continue;
                }
                
                $this->info("📊  " . count($reportData) . " employé(s) analysé(s)");
                
                // Générer le PDF - FIX: use $endOfMonth instead of $endDate
                $this->info("🔄  Génération du PDF...");
                $pdfPath = $this->generateMonthlyReportPDF($client, $reportData, $startOfMonth, $endOfMonth); // FIXED HERE
                
                if (!$pdfPath) {
                    $this->error("❌  Échec de génération du PDF pour " . $userName);
                    continue;
                }
                
                $this->info("✅  PDF généré: " . basename($pdfPath));
                
                // Envoyer l'email avec pièce jointe
                $this->info("📤  Envoi de l'email à " . $rhEmail . "...");
                $this->sendReportToRH($client, $userName, $rhEmail, $reportData, $startOfMonth, $endOfMonth, $pdfPath);
                $totalEmailsSent++;
                
                $this->info("✅  Rapport envoyé avec PDF à " . $rhEmail);
                
                // Nettoyer le fichier temporaire
                $this->cleanupTempFile($pdfPath);
                
                // Pause entre les clients
                if ($clientsProcessed < $clients->count()) {
                    sleep(2);
                }
                
            } catch (\Exception $e) {
                $clientName = $userName ?? 'Client #' . $client->id;
                $this->error("❌  Erreur avec " . $clientName . ": " . $e->getMessage());
                Log::error('Erreur client ' . $client->id . ': ' . $e->getMessage());
                Log::error('Trace: ' . $e->getTraceAsString());
            }
        }
        
        $this->info("\n✅  Terminé! " . $totalEmailsSent . " email(s) envoyé(s) sur " . $clients->count() . " client(s)");
    }
    
    /**
     * Générer le PDF du rapport mensuel
     */
    private function generateMonthlyReportPDF($client, $reportData, $startDate, $endDate) // Parameter name is $endDate
    {
        try {
            // Get user name for the client
            $userName = $this->getClientUserName($client);
            
            // Calculer les totaux comme dans le controller
            $totals = $this->calculateTotals($reportData);
            
            // Préparer les données pour le PDF
            $pdfData = [
                'client' => $client,
                'client_name' => $userName,
                'start_date' => $startDate->format('d/m/Y'),
                'end_date' => $endDate->format('d/m/Y'),
                'month_name' => $startDate->locale('fr')->monthName,
                'year' => $startDate->year,
                'report_data' => $reportData,
                'totals' => $totals,
                'total_employees' => count($reportData),
                'period_days' => $startDate->diffInDays($endDate) + 1,
                'generated_at' => Carbon::now(),
                'filters' => [
                    'emp_code' => 'Tous les employés'
                ]
            ];
            
            $this->info("📝 Préparation des données PDF pour " . $userName);
            
            // Générer le PDF - essayer différentes vues
            $viewName = 'reports.exports.custom-report-pdf';
            
            // Vérifier si la vue existe
            if (!view()->exists($viewName)) {
                $this->error("❌ Vue non trouvée: " . $viewName);
                
                // Essayer une vue alternative
                $viewName = 'emails.monthly-rh-report-pdf';
                if (!view()->exists($viewName)) {
                    $this->error("❌ Vue alternative non trouvée: " . $viewName);
                    return null;
                }
                $this->info("✅ Utilisation de la vue alternative: " . $viewName);
            }
            
            $pdf = PDF::loadView($viewName, $pdfData);
            
            // Options du PDF
            $pdf->setPaper('A4', 'landscape');
            $pdf->setOption('defaultFont', 'DejaVu Sans');
            $pdf->setOption('isHtml5ParserEnabled', true);
            $pdf->setOption('isRemoteEnabled', true);
            
            // Créer un nom de fichier unique
            $filename = 'rapport_mensuel_rh_' . $client->id . '_' . 
                       $startDate->format('Y_m') . '_' . 
                       Carbon::now()->format('Ymd_His') . '.pdf';
            
            // Chemin temporaire
            $tempPath = storage_path('app/temp/' . $filename);
            
            // S'assurer que le dossier existe
            $tempDir = dirname($tempPath);
            if (!is_dir($tempDir)) {
                if (!mkdir($tempDir, 0755, true)) {
                    $this->error("❌ Impossible de créer le dossier temporaire: " . $tempDir);
                    return null;
                }
                $this->info("✅ Dossier temporaire créé: " . $tempDir);
            }
            
            // Sauvegarder le PDF
            $this->info("💾 Sauvegarde du PDF: " . $tempPath);
            $pdf->save($tempPath);
            
            if (!file_exists($tempPath)) {
                $this->error("❌ Le fichier PDF n'a pas été créé: " . $tempPath);
                return null;
            }
            
            $fileSize = filesize($tempPath);
            $this->info("✅ PDF généré avec succès: " . basename($tempPath) . " (" . number_format($fileSize / 1024, 2) . " KB)");
            
            Log::info('PDF généré pour client ' . $client->id . ' (' . $userName . '): ' . $tempPath . ' (' . $fileSize . ' bytes)');
            
            return $tempPath;
            
        } catch (\Exception $e) {
            $userName = $this->getClientUserName($client);
            $this->error("❌ Erreur génération PDF pour " . $userName . ": " . $e->getMessage());
            Log::error('Erreur génération PDF client ' . $client->id . ': ' . $e->getMessage());
            Log::error('Trace: ' . $e->getTraceAsString());
            return null;
        }
    }
    
    /**
     * Envoyer le rapport au RH avec pièce jointe PDF
     */
    private function sendReportToRH($client, $userName, $rhEmail, $reportData, $startDate, $endDate, $pdfPath)
    {
        try {
            // Calculer les totaux
            $totals = $this->calculateTotals($reportData);
            
            // Préparer les données pour l'email
            $emailData = [
                'client' => $client,
                'client_name' => $userName,
                'email' => $rhEmail,
                'start_date' => $startDate->format('d/m/Y'),
                'end_date' => $endDate->format('d/m/Y'),
                'month_name' => $startDate->locale('fr')->monthName,
                'year' => $startDate->year,
                'report_data' => $reportData,
                'totals' => $totals,
                'total_employees' => count($reportData),
                'period_days' => $startDate->diffInDays($endDate) + 1,
                'generated_at' => Carbon::now(),
                'has_pdf_attachment' => true,
                'pdf_filename' => basename($pdfPath)
            ];
            
            $this->info("📧 Préparation de l'email pour " . $rhEmail);
            
            // Créer le Mailable avec pièce jointe
            $mail = new \App\Mail\MonthlyRHReport($emailData);
            
            // Attacher le PDF
            $mail->attach($pdfPath, [
                'as' => 'Rapport_Mensuel_RH_' . $userName . '_' . 
                       $startDate->format('Y_m') . '.pdf',
                'mime' => 'application/pdf'
            ]);
            
            // Envoyer l'email
            Mail::to($rhEmail)->send($mail);
            
            $logMessage = 'Rapport mensuel RH avec PDF envoyé à ' . $rhEmail . 
                         ' pour client ' . $client->id . ' (' . $userName . ')';
            Log::info($logMessage);
            
        } catch (\Exception $e) {
            $errorMessage = 'Erreur envoi email avec PDF à ' . $rhEmail . 
                           ' pour client ' . $client->id . ' (' . $userName . '): ' . $e->getMessage();
            Log::error($errorMessage);
            throw $e;
        }
    }
    
    /**
     * Get client user name
     */
    private function getClientUserName($client)
    {
        if ($client->user) {
            return $client->user->name ?: ($client->user->email ?: 'Client #' . $client->id);
        } else {
            // Fallback to getting user from user_id
            $user = User::find($client->user_id);
            if ($user) {
                return $user->name ?: ($user->email ?: 'Client #' . $client->id);
            } else {
                return 'Client #' . $client->id;
            }
        }
    }
    
    /**
     * Nettoyer le fichier temporaire
     */
    private function cleanupTempFile($filePath)
    {
        try {
            if (file_exists($filePath)) {
                unlink($filePath);
                Log::info('Fichier temporaire supprimé: ' . $filePath);
            }
        } catch (\Exception $e) {
            Log::warning('Impossible de supprimer le fichier temporaire: ' . $e->getMessage());
        }
    }
    
    /**
     * Récupérer les données de présence et ponctualité (comme dans le controller)
     */
    private function getPresencePonctualiteData($client, $startDate, $endDate, $empCode)
    {
        // Récupérer les employés selon le filtre
        $employeesQuery = Employee::where('client_id', $client->id)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '');
        
        if ($empCode && $empCode !== 'all') {
            $employeesQuery->where('emp_code', $empCode);
        }
        
        $employees = $employeesQuery->orderBy('emp_code')->get();
        
        if ($employees->isEmpty()) {
            Log::info("Aucun employé trouvé pour client " . $client->id);
            return [];
        }
        
        // Récupérer le token d'authentification
        $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
        $token = $accessConfig->general_token ?? null;
        
        if (!$token) {
            Log::warning("Token d'accès non configuré pour client: " . $client->id);
            return [];
        }
        
        // Récupérer tous les devices
        $devices = Device::where('client_id', $client->id)->get();
        
        if ($devices->isEmpty()) {
            Log::warning("Aucun device trouvé pour client: " . $client->id);
            return [];
        }
        
        // Récupérer les permissions approuvées
        $permissions = EmployeePermission::where('client_id', $client->id)
            ->where('status', 'approved')
            ->whereBetween('date', [$startDate, $endDate])
            ->get()
            ->groupBy('employee_id');
        
        // Récupérer les congés
        $leaves = Leave::where('client_id', $client->id)
            ->whereBetween('start_date', [$startDate, $endDate])
            ->get();
        
        $reportData = [];
        $orderNumber = 1;
        $totalEmployees = $employees->count();
        $processed = 0;
        
        foreach ($employees as $employee) {
            $processed++;
            
            // Log de progression
            if ($processed % 10 === 0 || $processed === $totalEmployees) {
                $userName = $this->getClientUserName($client);
                $this->info("   Analyse employé {$processed}/{$totalEmployees} pour " . $userName);
            }
            
            // Analyser chaque jour de la période
            $analysis = $this->analyzeEmployeePeriod(
                $employee,
                $startDate,
                $endDate,
                $devices,
                $token,
                $permissions,
                $leaves
            );
            
            if ($analysis) {
                $reportData[] = [
                    'order_number' => $orderNumber++,
                    'employee_code' => $employee->emp_code,
                    'employee_name' => $employee->first_name . ($employee->last_name ? ' ' . $employee->last_name : ''),
                    'presence_data' => $analysis['presence'],
                    'ponctualite_data' => $analysis['ponctualite'],
                    'total_days' => $analysis['total_days'],
                    'observation' => $analysis['observation']
                ];
            }
        }
        
        $userName = $this->getClientUserName($client);
        Log::info("Données récupérées pour " . $userName . " (ID: {$client->id}): " . count($reportData) . " employés");
        
        return $reportData;
    }
    
    /**
     * Analyser la période pour un employé (comme dans le controller)
     */
    private function analyzeEmployeePeriod($employee, $startDate, $endDate, $devices, $token, $permissions, $leaves)
    {
        $currentDate = Carbon::parse($startDate);
        $endDateObj = Carbon::parse($endDate);
        
        $presenceData = [
            'present_count' => 0,
            'absent_count' => 0,
            'present_days' => [],
            'absent_days' => []
        ];
        
        $ponctualiteData = [
            'on_time_count' => 0,
            'late_count' => 0,
            'late_minutes_total' => 0,
            'on_time_days' => [],
            'late_days' => []
        ];
        
        $totalWorkingDays = 0;
        $observations = [];
        
        while ($currentDate <= $endDateObj) {
            $dateStr = $currentDate->format('Y-m-d');
            $dayOfWeek = $currentDate->dayOfWeekIso;
            
            // Vérifier si c'est un jour de travail (lundi-vendredi)
            $isWorkingDay = ($dayOfWeek >= 1 && $dayOfWeek <= 5);
            
            if ($isWorkingDay) {
                $totalWorkingDays++;
                
                // Récupérer le planning de l'employé
                $schedule = $this->getEmployeeScheduleForDate($employee, $dateStr);
                
                // Récupérer les transactions pour ce jour
                $transactions = $this->getEmployeeTransactionsForDate($employee, $currentDate, $devices, $token);
                
                // Vérifier les permissions
                $hasPermission = $this->hasPermission($employee->id, $dateStr, $permissions);
                
                // Vérifier les congés
                $isOnLeave = $this->isEmployeeOnLeave($employee->id, $dateStr, $leaves);
                
                // Analyser la présence
                $arrivalTime = $transactions['arrival_time'] ?? null;
                $departureTime = $transactions['departure_time'] ?? null;
                
                $isPresent = ($arrivalTime !== null || $departureTime !== null);
                
                if ($isOnLeave) {
                    // Congé
                    $observations[] = 'Congé le ' . $currentDate->format('d/m');
                } else if ($hasPermission) {
                    // Permission
                    $observations[] = 'Permission le ' . $currentDate->format('d/m');
                } else if ($isPresent) {
                    $presenceData['present_count']++;
                    $presenceData['present_days'][] = $currentDate->format('d/m');
                    
                    // Analyser la ponctualité si c'est un jour avec planning
                    if ($schedule && $schedule->start_time && $arrivalTime !== null) {
                        $scheduleStart = Carbon::createFromFormat('H:i:s', $schedule->start_time->format('H:i:s'));
                        $actualArrival = Carbon::createFromFormat('H:i:s', $arrivalTime);
                        
                        if ($actualArrival > $scheduleStart) {
                            $lateMinutes = $actualArrival->diffInMinutes($scheduleStart);
                            
                            // Tolérance de 5 minutes
                            if ($lateMinutes > 5) {
                                $ponctualiteData['late_count']++;
                                $ponctualiteData['late_minutes_total'] += $lateMinutes;
                                $ponctualiteData['late_days'][] = $currentDate->format('d/m') . ' (' . $lateMinutes . ' min)';
                                $observations[] = 'Retard de ' . $lateMinutes . ' min le ' . $currentDate->format('d/m');
                            } else {
                                $ponctualiteData['on_time_count']++;
                                $ponctualiteData['on_time_days'][] = $currentDate->format('d/m');
                            }
                        } else {
                            $ponctualiteData['on_time_count']++;
                            $ponctualiteData['on_time_days'][] = $currentDate->format('d/m');
                        }
                    } else if ($isPresent) {
                        // Présent mais pas de planning ou pas d'arrivée enregistrée
                        $ponctualiteData['on_time_count']++;
                        $ponctualiteData['on_time_days'][] = $currentDate->format('d/m');
                    }
                } else {
                    // Absent sans justification
                    $presenceData['absent_count']++;
                    $presenceData['absent_days'][] = $currentDate->format('d/m');
                    
                    // Vérifier si c'est un jour avec planning
                    if ($schedule && $schedule->is_working_day) {
                        $observations[] = 'Absent le ' . $currentDate->format('d/m');
                    }
                }
            }
            
            $currentDate->addDay();
        }
        
        // Calculer les taux
        $presenceRate = $totalWorkingDays > 0 ? round(($presenceData['present_count'] / $totalWorkingDays) * 100, 1) : 0;
        $ponctualiteRate = $presenceData['present_count'] > 0 ? round(($ponctualiteData['on_time_count'] / $presenceData['present_count']) * 100, 1) : 0;
        
        // Calculer la moyenne des minutes de retard
        $avgLateMinutes = $ponctualiteData['late_count'] > 0 ? 
            round($ponctualiteData['late_minutes_total'] / $ponctualiteData['late_count'], 1) : 0;
        
        return [
            'presence' => [
                'present' => $presenceData['present_count'],
                'absent' => $presenceData['absent_count'],
                'rate' => $presenceRate,
                'present_days_display' => $presenceData['present_count'] . '/' . $totalWorkingDays,
                'absent_days_display' => $presenceData['absent_count'] . '/' . $totalWorkingDays,
                'present_days_list' => $presenceData['present_days'],
                'absent_days_list' => $presenceData['absent_days']
            ],
            'ponctualite' => [
                'on_time' => $ponctualiteData['on_time_count'],
                'late' => $ponctualiteData['late_count'],
                'rate' => $ponctualiteRate,
                'avg_late_minutes' => $avgLateMinutes,
                'total_late_minutes' => $ponctualiteData['late_minutes_total'],
                'on_time_days' => $ponctualiteData['on_time_days'],
                'late_days' => $ponctualiteData['late_days']
            ],
            'total_days' => $totalWorkingDays,
            'observation' => implode(', ', array_slice($observations, 0, 3)) . 
                (count($observations) > 3 ? '... (+' . (count($observations) - 3) . ' autres)' : ''),
            'total_observations' => count($observations)
        ];
    }
    
    /**
     * Récupérer les transactions d'un employé pour une date
     */
    private function getEmployeeTransactionsForDate($employee, $date, $devices, $token)
    {
        $startTime = $date->copy()->startOfDay()->format('Y-m-d H:i:s');
        $endTime = $date->copy()->endOfDay()->format('Y-m-d H:i:s');
        
        $allTransactions = collect();
        
        foreach ($devices as $device) {
            try {
                $response = Http::withHeaders([
                    'Authorization' => 'Token ' . $token,
                    'Accept' => 'application/json',
                ])->withOptions([
                    'verify' => false,
                    'timeout' => 30,
                ])->get('http://54.37.15.111/iclock/api/transactions/', [
                    'page' => 1,
                    'limit' => 50,
                    'terminal_sn' => $device->device_sn,
                    'emp_code' => $employee->emp_code,
                    'start_time' => $startTime,
                    'end_time' => $endTime
                ]);
                
                if ($response->successful()) {
                    $data = $response->json();
                    if (isset($data['data']) && is_array($data['data'])) {
                        $allTransactions = $allTransactions->merge($data['data']);
                    }
                }
                
            } catch (\Exception $e) {
                Log::error("Erreur récupération transactions pour {$employee->emp_code}: " . $e->getMessage());
            }
        }
        
        // Grouper les transactions
        return $this->groupTransactions($allTransactions);
    }
    
    /**
     * Grouper les transactions
     */
    private function groupTransactions($transactions)
    {
        $grouped = [
            'arrival_time' => null,
            'departure_time' => null,
            'all_punches' => []
        ];
        
        foreach ($transactions as $transaction) {
            $punchTime = Carbon::parse($transaction['punch_time']);
            $timeStr = $punchTime->format('H:i:s');
            
            $grouped['all_punches'][] = $timeStr;
            
            // Déterminer si c'est une arrivée ou un départ
            $hour = $punchTime->hour;
            $isArrival = ($hour < 14);
            
            // Garder la première arrivée et le dernier départ
            if ($isArrival) {
                if (!$grouped['arrival_time'] || $timeStr < $grouped['arrival_time']) {
                    $grouped['arrival_time'] = $timeStr;
                }
            } else {
                if (!$grouped['departure_time'] || $timeStr > $grouped['departure_time']) {
                    $grouped['departure_time'] = $timeStr;
                }
            }
        }
        
        return $grouped;
    }
    
    /**
     * Récupérer le planning d'un employé pour une date
     */
    private function getEmployeeScheduleForDate($employee, $dateStr)
    {
        $date = Carbon::parse($dateStr);
        $dayOfWeek = $date->dayOfWeekIso;
        $dayName = $date->locale('fr')->dayName;
        
        // Chercher d'abord les plannings spécifiques à la date
        $specificSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('specific_date', $dateStr)
            ->first();
        
        if ($specificSchedule) {
            return $specificSchedule;
        }
        
        // Chercher les plannings fixes par jour de semaine
        $fixedSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('schedule_type', 'fixe')
            ->where('day_of_week', $dayOfWeek)
            ->where('repeat_weekly', true)
            ->where(function($query) use ($dateStr) {
                $query->whereNull('start_date')
                      ->orWhere('start_date', '<=', $dateStr);
            })
            ->where(function($query) use ($dateStr) {
                $query->whereNull('end_date')
                      ->orWhere('end_date', '>=', $dateStr);
            })
            ->first();
        
        if ($fixedSchedule) {
            return $fixedSchedule;
        }
        
        // Chercher un planning par défaut
        $defaultSchedule = EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->where('schedule_type', 'fixe')
            ->where('day_of_week', $dayOfWeek)
            ->first();
        
        if ($defaultSchedule) {
            return $defaultSchedule;
        }
        
        // Dernier recours: premier planning disponible
        return EmployeeSchedule::where('client_id', $employee->client_id)
            ->where('employee_id', $employee->id)
            ->orderBy('created_at', 'desc')
            ->first();
    }
    
    /**
     * Vérifier si l'employé a une permission
     */
    private function hasPermission($employeeId, $date, $permissions)
    {
        if (isset($permissions[$employeeId])) {
            foreach ($permissions[$employeeId] as $permission) {
                if ($permission->date->format('Y-m-d') == $date) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Vérifier si l'employé est en congé
     */
    private function isEmployeeOnLeave($employeeId, $date, $leaves)
    {
        foreach ($leaves as $leave) {
            if ($leave->employee_id == $employeeId) {
                $leaveStart = Carbon::parse($leave->start_date);
                $leaveEnd = Carbon::parse($leave->end_date);
                $checkDate = Carbon::parse($date);
                
                if ($checkDate->between($leaveStart, $leaveEnd)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Calculer les totaux pour le rapport (comme dans le controller)
     */
    private function calculateTotals($reportData)
    {
        $totals = [
            'total_employees' => count($reportData),
            'total_presence_present' => 0,
            'total_presence_absent' => 0,
            'total_ponctualite_on_time' => 0,
            'total_ponctualite_late' => 0,
            'avg_presence_rate' => 0,
            'avg_ponctualite_rate' => 0
        ];
        
        if (count($reportData) > 0) {
            $totalPresenceRate = 0;
            $totalPonctualiteRate = 0;
            
            foreach ($reportData as $data) {
                $totals['total_presence_present'] += $data['presence_data']['present'];
                $totals['total_presence_absent'] += $data['presence_data']['absent'];
                $totals['total_ponctualite_on_time'] += $data['ponctualite_data']['on_time'];
                $totals['total_ponctualite_late'] += $data['ponctualite_data']['late'];
                
                $totalPresenceRate += $data['presence_data']['rate'];
                $totalPonctualiteRate += $data['ponctualite_data']['rate'];
            }
            
            $totals['avg_presence_rate'] = round($totalPresenceRate / count($reportData), 1);
            $totals['avg_ponctualite_rate'] = round($totalPonctualiteRate / count($reportData), 1);
        }
        
        return $totals;
    }
}