<?php

namespace App\Console\Commands;

use App\Models\Client;
use App\Models\Employee;
use App\Models\Device;
use App\Models\Setting;
use App\Models\User; // Ajouter cette importation
use App\Mail\WeeklyAttendanceReport;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class SendWeeklyAttendanceReports extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'attendance:send-weekly-reports';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Envoyer les rapports de présence hebdomadaires aux employés chaque samedi à 9h';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('🚀 Début de l\'envoi des rapports de présence hebdomadaires...');
        
        // Vérifier si on est samedi
        $today = Carbon::now();
        // if ($today->dayOfWeek !== Carbon::SATURDAY) {
        //     $this->info('📅 Aujourd\'hui n\'est pas samedi. Arrêt de la commande.');
        //     $this->info('⏰ Prochaine exécution: Samedi prochain à 9h');
        //     return;
        // }
        
        // Calculer la période de la semaine (du lundi au vendredi)
        $startOfWeek = $today->copy()->startOfWeek(Carbon::MONDAY); // Lundi de cette semaine
        $endOfWeek = $today->copy()->endOfWeek(Carbon::FRIDAY);    // Vendredi de cette semaine
        
        $this->info("📊 Période du rapport: " . $startOfWeek->format('d/m/Y') . " au " . $endOfWeek->format('d/m/Y'));
        
        // Récupérer tous les clients actifs avec leurs utilisateurs
        $clients = Client::with('user')
            ->whereHas('user', function($query) {
                $query->where('status', 'active');
            })
            ->get();
        
        $totalEmailsSent = 0;
        $clientsProcessed = 0;
        $totalClients = $clients->count();
        
        $this->info("👥 Nombre de clients à traiter: " . $totalClients);
        
        foreach ($clients as $client) {
            try {
                $clientsProcessed++;
                
                // Get user name for the client
                $userName = $this->getClientUserName($client);
                
                $this->info("\n--- [{$clientsProcessed}/{$totalClients}] Traitement du client: " . $userName . " ---");
                
                // VÉRIFICATION 1: Vérifier les paramètres du client
                $settings = Setting::where('client_id', $client->id)->first();
                
                if (!$settings) {
                    $this->warn("⚠️  Aucun paramètre trouvé pour le client: " . $userName);
                    Log::info('Aucun paramètre trouvé pour client ' . $client->id . ' (' . $userName . ') - Rapports non envoyés');
                    continue;
                }
                
                // VÉRIFICATION 2: Vérifier si les emails aux employés sont activés
                if (!$settings->email_employees_is_active) {
                    $this->warn("❌  Emails aux employés désactivés pour le client: " . $userName);
                    Log::info('Emails employés désactivés pour client ' . $client->id . ' (' . $userName . ') - Rapports non envoyés');
                    continue;
                }
                
                $this->info("✅  Emails aux employés activés pour " . $userName);
                
                // VÉRIFICATION 3: Récupérer les données de présence
                $this->info("📡  Récupération des données de présence...");
                $attendanceData = $this->getWeeklyAttendanceData($client, $startOfWeek, $endOfWeek);
                
                if (empty($attendanceData)) {
                    $this->warn("⚠️  Aucune donnée de présence pour le client " . $userName);
                    continue;
                }
                
                $this->info("✅  " . count($attendanceData) . " transactions récupérées");
                
                // VÉRIFICATION 4: Grouper les données par employé
                $this->info("📊  Regroupement des données par employé...");
                $groupedData = $this->groupDataByEmployee($attendanceData, $client->id);
                
                if (empty($groupedData)) {
                    $this->warn("⚠️  Aucune donnée regroupée pour le client " . $userName);
                    continue;
                }
                
                $this->info("✅  " . count($groupedData) . " employé(s) trouvé(s)");
                
                // VÉRIFICATION 5: Filtrer les employés avec email valide
                $employeesWithEmail = 0;
                foreach ($groupedData as $empCode => $employeeData) {
                    if (isset($employeeData['employee']) && 
                        !empty($employeeData['employee']->email) && 
                        filter_var($employeeData['employee']->email, FILTER_VALIDATE_EMAIL)) {
                        $employeesWithEmail++;
                    }
                }
                
                if ($employeesWithEmail === 0) {
                    $this->warn("⚠️  Aucun employé avec email valide pour le client " . $userName);
                    continue;
                }
                
                $this->info("📧  " . $employeesWithEmail . " employé(s) avec email valide");
                
                // ENVOI DES EMAILS
                $clientEmailsSent = 0;
                $emailErrors = 0;
                
                foreach ($groupedData as $empCode => $employeeData) {
                    if (isset($employeeData['employee']) && 
                        !empty($employeeData['employee']->email) &&
                        filter_var($employeeData['employee']->email, FILTER_VALIDATE_EMAIL)) {
                        
                        try {
                            $this->sendReportToEmployee($employeeData, $client, $userName, $startOfWeek, $endOfWeek);
                            $clientEmailsSent++;
                            $totalEmailsSent++;
                            
                            // Log détaillé
                            Log::info('Email hebdomadaire envoyé à ' . $employeeData['employee']->email . 
                                     ' (Code: ' . $empCode . ') pour client ' . $client->id . ' (' . $userName . ')');
                            
                            // Pause courte entre les emails pour éviter la surcharge
                            if ($clientEmailsSent % 5 === 0) {
                                sleep(1);
                            }
                            
                        } catch (\Exception $e) {
                            $emailErrors++;
                            Log::error('Erreur envoi email à ' . $employeeData['employee']->email . 
                                      ' (Code: ' . $empCode . '): ' . $e->getMessage());
                        }
                    }
                }
                
                // Résumé pour ce client
                if ($clientEmailsSent > 0) {
                    $this->info("✅  " . $clientEmailsSent . " email(s) envoyé(s) pour " . $userName);
                    if ($emailErrors > 0) {
                        $this->warn("⚠️  " . $emailErrors . " erreur(s) d'envoi pour " . $userName);
                    }
                } else {
                    $this->warn("⚠️  Aucun email envoyé pour " . $userName . " (erreurs: " . $emailErrors . ")");
                }
                
                // Pause entre les clients pour éviter la surcharge
                if ($clientsProcessed < $totalClients) {
                    sleep(3);
                }
                
            } catch (\Exception $e) {
                $clientName = $userName ?? 'Client #' . $client->id;
                $this->error("❌  Erreur avec le client " . $clientName . ": " . $e->getMessage());
                Log::error('Erreur générale client ' . $client->id . ' (' . $clientName . '): ' . $e->getMessage());
                Log::error('Trace: ' . $e->getTraceAsString());
            }
        }
        
        // RÉSUMÉ FINAL
        $this->line('');
        $this->info("═══════════════════════════════════════════");
        $this->info("📋  RÉSUMÉ DE L'EXÉCUTION HEBDOMADAIRE");
        $this->info("═══════════════════════════════════════════");
        $this->info("Date d'exécution : " . $today->format('d/m/Y H:i'));
        $this->info("Période analysée : " . $startOfWeek->format('d/m/Y') . " au " . $endOfWeek->format('d/m/Y'));
        $this->info("Clients traités  : " . $clientsProcessed . "/" . $totalClients);
        $this->info("Emails envoyés   : " . $totalEmailsSent);
        
        if ($totalEmailsSent > 0) {
            $this->info("✅  Rapports hebdomadaires envoyés avec succès !");
            $this->info("⏰  Prochaine exécution: Samedi prochain à 9h");
        } else {
            $this->warn("⚠️  Aucun email n'a été envoyé");
            $this->info("🔍  Vérifiez: 1) Paramètres emails employés, 2) Emails employés valides, 3) Données de présence");
        }
        
        // Log final
        Log::info('Rapports hebdomadaires terminés: ' . $totalEmailsSent . ' emails envoyés sur ' . 
                 $totalClients . ' clients, Date: ' . $today->format('Y-m-d'));
    }
    
    /**
     * Get client user name
     */
    private function getClientUserName($client)
    {
        if ($client->user) {
            return $client->user->name ?: ($client->user->email ?: 'Client #' . $client->id);
        } else {
            // Fallback to getting user from user_id
            $user = User::find($client->user_id);
            if ($user) {
                return $user->name ?: ($user->email ?: 'Client #' . $client->id);
            } else {
                return 'Client #' . $client->id;
            }
        }
    }
    
    /**
     * Récupérer les données de présence depuis l'API
     */
    private function getWeeklyAttendanceData($client, $startDate, $endDate)
    {
        try {
            // Récupérer le token d'authentification
            $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
            
            if (!$accessConfig || empty($accessConfig->general_token)) {
                $userName = $this->getClientUserName($client);
                Log::warning("Token d'accès non configuré pour client: " . $client->id . ' (' . $userName . ')');
                return [];
            }
            
            $token = $accessConfig->general_token;
            
            // Récupérer tous les devices
            $devices = Device::where('client_id', $client->id)->get();
            
            if ($devices->isEmpty()) {
                $userName = $this->getClientUserName($client);
                Log::warning("Aucun device trouvé pour client: " . $client->id . ' (' . $userName . ')');
                return [];
            }
            
            // Collecter toutes les transactions depuis l'API
            $allTransactions = collect();
            
            foreach ($devices as $device) {
                $deviceTransactions = $this->getDeviceTransactions(
                    $device,
                    $startDate->format('Y-m-d H:i:s'),
                    $endDate->format('Y-m-d H:i:s'),
                    $token
                );
                
                if (!empty($deviceTransactions)) {
                    $allTransactions = $allTransactions->merge($deviceTransactions);
                    Log::debug('Device ' . $device->device_sn . ': ' . count($deviceTransactions) . ' transactions');
                }
            }
            
            $totalTransactions = $allTransactions->count();
            $userName = $this->getClientUserName($client);
            Log::info("Total transactions récupérées pour client " . $client->id . ' (' . $userName . '): ' . $totalTransactions);
            
            if ($totalTransactions === 0) {
                Log::warning("Aucune transaction trouvée pour client " . $client->id . ' (' . $userName . ')' .
                           " du " . $startDate->format('Y-m-d') . " au " . $endDate->format('Y-m-d'));
            }
            
            return $allTransactions;
            
        } catch (\Exception $e) {
            $userName = $this->getClientUserName($client);
            Log::error('Erreur récupération données hebdomadaires client ' . $client->id . ' (' . $userName . '): ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Récupérer les transactions d'un device depuis l'API
     */
    private function getDeviceTransactions($device, $startTime, $endTime, $token)
    {
        $page = 1;
        $limit = 500;
        $allTransactions = collect();
        $maxPages = 5; // Réduit pour éviter les timeouts
        
        do {
            try {
                $apiParams = [
                    'page' => $page,
                    'limit' => $limit,
                    'terminal_sn' => $device->device_sn,
                    'start_time' => $startTime,
                    'end_time' => $endTime
                ];
                
                $response = Http::withHeaders([
                    'Authorization' => 'Token ' . $token,
                    'Accept' => 'application/json',
                ])->withOptions([
                    'verify' => false,
                    'timeout' => 30, // Timeout réduit
                ])->get('http://54.37.15.111/iclock/api/transactions/', $apiParams);
                
                if (!$response->successful()) {
                    Log::warning("Erreur API device {$device->device_sn}: " . $response->status() . 
                                " - " . $response->body());
                    break;
                }
                
                $data = $response->json();
                
                if (!isset($data['data']) || !is_array($data['data'])) {
                    Log::warning("Format de réponse invalide pour device {$device->device_sn}");
                    break;
                }
                
                if (empty($data['data'])) {
                    // Aucune donnée pour ce device
                    break;
                }
                
                $transactions = collect($data['data'])->map(function($transaction) use ($device) {
                    $transaction['device_sn'] = $device->device_sn;
                    $transaction['device_name'] = $device->terminal_name ?: $device->device_sn;
                    return $transaction;
                });
                
                $allTransactions = $allTransactions->merge($transactions);
                
                // Vérifier s'il y a une page suivante
                $hasNextPage = !empty($data['next']);
                
                if (!$hasNextPage || $page >= $maxPages) {
                    break;
                }
                
                $page++;
                usleep(50000); // Réduit à 50ms
                
            } catch (\Exception $e) {
                Log::error("Erreur récupération device {$device->device_sn}: " . $e->getMessage());
                break;
            }
            
        } while (true);
        
        return $allTransactions;
    }
    
    /**
     * Grouper les données par employé
     */
    private function groupDataByEmployee($transactions, $clientId)
    {
        $grouped = [];
        
        // Récupérer tous les employés du client
        $employees = Employee::where('client_id', $clientId)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '')
            ->whereNotNull('email')
            ->where('email', '!=', '')
            ->get()
            ->keyBy('emp_code');
        
        if ($employees->isEmpty()) {
            Log::warning("Aucun employé avec email trouvé pour client: " . $clientId);
            return [];
        }
        
        Log::info("Employés avec email pour client " . $clientId . ": " . $employees->count());
        
        foreach ($transactions as $transaction) {
            $empCode = $transaction['emp_code'] ?? null;
            if (!$empCode) continue;
            
            $empCode = trim($empCode);
            
            // Vérifier si l'employé existe et a un email
            if (!isset($employees[$empCode])) {
                continue; // Ignorer les transactions des employés sans email
            }
            
            if (!isset($grouped[$empCode])) {
                $grouped[$empCode] = [
                    'employee' => $employees[$empCode],
                    'attendances' => [],
                    'total_hours' => 0
                ];
            }
            
            $punchTime = Carbon::parse($transaction['punch_time']);
            $dateStr = $punchTime->format('Y-m-d');
            $timeStr = $punchTime->format('H:i:s');
            
            if (!isset($grouped[$empCode]['attendances'][$dateStr])) {
                $grouped[$empCode]['attendances'][$dateStr] = [
                    'date' => $dateStr,
                    'arrival_time' => null,
                    'departure_time' => null,
                    'device_name' => $transaction['device_name'] ?? null
                ];
            }
            
            // Déterminer si c'est une arrivée ou un départ
            $hour = $punchTime->hour;
            $isArrival = ($hour < 14);
            
            if ($isArrival) {
                if (!$grouped[$empCode]['attendances'][$dateStr]['arrival_time'] || 
                    $timeStr < $grouped[$empCode]['attendances'][$dateStr]['arrival_time']) {
                    $grouped[$empCode]['attendances'][$dateStr]['arrival_time'] = $timeStr;
                }
            } else {
                if (!$grouped[$empCode]['attendances'][$dateStr]['departure_time'] || 
                    $timeStr > $grouped[$empCode]['attendances'][$dateStr]['departure_time']) {
                    $grouped[$empCode]['attendances'][$dateStr]['departure_time'] = $timeStr;
                }
            }
        }
        
        // Calculer le total d'heures pour chaque employé
        foreach ($grouped as $empCode => $data) {
            $totalMinutes = 0;
            $daysWithAttendance = 0;
            
            foreach ($data['attendances'] as $attendance) {
                if ($attendance['arrival_time'] && $attendance['departure_time']) {
                    try {
                        $arrival = Carbon::createFromFormat('H:i:s', $attendance['arrival_time']);
                        $departure = Carbon::createFromFormat('H:i:s', $attendance['departure_time']);
                        
                        if ($departure > $arrival) {
                            $totalMinutes += $departure->diffInMinutes($arrival);
                            $daysWithAttendance++;
                        }
                    } catch (\Exception $e) {
                        Log::warning("Erreur calcul heures pour employé " . $empCode . ": " . $e->getMessage());
                    }
                }
            }
            
            $grouped[$empCode]['total_hours'] = round($totalMinutes / 60, 2);
            $grouped[$empCode]['days_with_attendance'] = $daysWithAttendance;
            $grouped[$empCode]['total_days'] = count($data['attendances']);
        }
        
        // Filtrer les employés sans données de présence
        $grouped = array_filter($grouped, function($data) {
            return $data['total_days'] > 0;
        });
        
        Log::info("Employés avec données de présence pour client " . $clientId . ": " . count($grouped));
        
        return $grouped;
    }
    
    /**
     * Envoyer le rapport à un employé
     */
    private function sendReportToEmployee($employeeData, $client, $userName, $startDate, $endDate)
    {
        try {
            $employee = $employeeData['employee'];
            
            // Validation supplémentaire de l'email
            if (empty($employee->email) || !filter_var($employee->email, FILTER_VALIDATE_EMAIL)) {
                throw new \Exception("Email invalide ou vide: " . ($employee->email ?? 'null'));
            }
            
            // Préparer les données pour l'email
            $emailData = [
                'employee' => $employee,
                'client' => $client,
                'client_name' => $userName, // Ajouter le nom du client (utilisateur)
                'start_date' => $startDate->format('d/m/Y'),
                'end_date' => $endDate->format('d/m/Y'),
                'attendances' => $employeeData['attendances'],
                'total_hours' => $employeeData['total_hours'],
                'days_with_attendance' => $employeeData['days_with_attendance'] ?? 0,
                'total_days' => $employeeData['total_days'] ?? 0
            ];
            
            // Vérifier s'il y a des données de présence
            if (empty($emailData['attendances'])) {
                throw new \Exception("Aucune donnée de présence pour la période");
            }
            
            // Envoyer l'email
            Mail::to($employee->email)->send(new \App\Mail\WeeklyAttendanceReport($emailData));
            
            // Log de succès
            $logMessage = 'Email hebdomadaire envoyé à ' . $employee->email . 
                         ' (Code: ' . $employee->emp_code . ')' .
                         ' - Client: ' . $userName .
                         ' - Jours: ' . ($emailData['days_with_attendance'] ?? 0) .
                         ' - Heures: ' . ($emailData['total_hours'] ?? 0);
            
            Log::info($logMessage);
            
        } catch (\Exception $e) {
            $errorMessage = 'Erreur envoi email à ' . ($employee->email ?? 'inconnu') . 
                           ' (Code: ' . ($employee->emp_code ?? 'inconnu') . '): ' . $e->getMessage();
            
            Log::error($errorMessage);
            throw $e;
        }
    }
}