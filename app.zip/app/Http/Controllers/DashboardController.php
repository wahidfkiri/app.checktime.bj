<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\User;
use App\Models\Employee;
use App\Models\Department;
use App\Models\Zone;
use App\Models\Device;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;

class DashboardController extends Controller
{
    public function index()
    {
        // Récupérer le client de l'utilisateur connecté
        $client = Client::where('user_id', auth()->id())->first();
        
        // Si l'utilisateur n'a pas de client associé
        if (!$client) {
            return view('dashboard')->with('error', 'Aucun client associé à votre compte.');
        }
        
        $clientId = $client->id;
        
        // Statistiques Principales pour le client
        $totalEmployees = Employee::where('client_id', $clientId)->count();
        $activeEmployees = Employee::where('client_id', $clientId)->where('status', 'active')->count();
        $inactiveEmployees = Employee::where('client_id', $clientId)->where('status', 'inactive')->count();
        $suspendedEmployees = Employee::where('client_id', $clientId)->where('status', 'suspended')->count();
        
        $totalDepartments = Department::where('client_id', $clientId)->count();
        $totalZones = Zone::where('client_id', $clientId)->count();
        $totalDevices = Device::where('client_id', $clientId)->count();
        
        // Appareils récemment synchronisés
        $recentlySyncedDevices = Device::where('client_id', $clientId)
            ->whereNotNull('last_sync')
            ->where('last_sync', '>=', Carbon::now()->subDay())
            ->count();
        
        // Données pour graphiques
        $employeeStatusData = [
            'active' => $activeEmployees,
            'inactive' => $inactiveEmployees,
            'suspended' => $suspendedEmployees
        ];
        
        // Top départements par nombre d'employés
        $topDepartments = Employee::where('client_id', $clientId)
            ->select('dept_name', DB::raw('COUNT(*) as count'))
            ->whereNotNull('dept_name')
            ->groupBy('dept_name')
            ->orderBy('count', 'desc')
            ->take(5)
            ->get();
        
        $topDepartmentsLabels = $topDepartments->pluck('dept_name')->toArray();
        $topDepartmentsCountData = $topDepartments->pluck('count')->toArray();
        
        // Top zones par nombre d'employés
        $topZones = Employee::where('client_id', $clientId)
            ->select('area_name', DB::raw('COUNT(*) as count'))
            ->whereNotNull('area_name')
            ->groupBy('area_name')
            ->orderBy('count', 'desc')
            ->take(5)
            ->get();
        
        $topZonesLabels = $topZones->pluck('area_name')->toArray();
        $topZonesCountData = $topZones->pluck('count')->toArray();
        
        // Croissance mensuelle des employés
        $monthlyStats = $this->getMonthlyStats($clientId);
        $monthlyLabels = $monthlyStats['labels'];
        $monthlyNewEmployees = $monthlyStats['new_employees'];
        
        // Derniers employés ajoutés
        $recentEmployees = Employee::where('client_id', $clientId)
            ->orderBy('created_at', 'desc')
            ->take(10)
            ->get();
        
        // Statut des appareils
        $activeDevices = Device::where('client_id', $clientId)
            ->whereNotNull('last_sync')
            ->where('last_sync', '>=', Carbon::now()->subDays(15))
            ->count();
        
        $inactiveDevices = Device::where('client_id', $clientId)
            ->where(function($query) {
                $query->whereNull('last_sync')
                      ->orWhere('last_sync', '<', Carbon::now()->subDays(15));
            })
            ->count();
        
        // Calcul des pourcentages
        $activeEmployeesPercentage = $totalEmployees > 0 ? round(($activeEmployees / $totalEmployees) * 100) : 0;
        $activeDevicesPercentage = $totalDevices > 0 ? round(($activeDevices / $totalDevices) * 100) : 0;
        
        // Synchronisation status
        $lastSyncTime = Cache::get('employees_last_sync_' . $clientId);
        $lastSyncText = $lastSyncTime ? Carbon::createFromTimestamp($lastSyncTime)->diffForHumans() : 'Jamais';
        
        return view('dashboard', compact(
            'client',
            'totalEmployees',
            'activeEmployees',
            'inactiveEmployees',
            'suspendedEmployees',
            'totalDepartments',
            'totalZones',
            'totalDevices',
            'recentlySyncedDevices',
            'employeeStatusData',
            'topDepartmentsLabels',
            'topDepartmentsCountData',
            'topZonesLabels',
            'topZonesCountData',
            'monthlyLabels',
            'monthlyNewEmployees',
            'recentEmployees',
            'activeDevices',
            'inactiveDevices',
            'activeEmployeesPercentage',
            'activeDevicesPercentage',
            'lastSyncText'
        ));
    }

    private function getMonthlyStats($clientId, $months = 6)
    {
        $labels = [];
        $newEmployees = [];

        for ($i = $months - 1; $i >= 0; $i--) {
            $date = Carbon::now()->subMonths($i);
            $startOfMonth = $date->copy()->startOfMonth();
            $endOfMonth = $date->copy()->endOfMonth();
            
            $labels[] = $date->format('M Y');
            
            // Nouveaux employés ce mois-ci
            $newEmployees[] = Employee::where('client_id', $clientId)
                ->whereBetween('created_at', [$startOfMonth, $endOfMonth])
                ->count();
        }

        return [
            'labels' => $labels,
            'new_employees' => $newEmployees
        ];
    }

    public function getStatsJson()
    {
        // Récupérer le client de l'utilisateur connecté
        $client = Client::where('user_id', auth()->id())->first();
        
        if (!$client) {
            return response()->json([
                'error' => 'Aucun client associé à votre compte.'
            ], 404);
        }
        
        $clientId = $client->id;
        
        return response()->json([
            'totalEmployees' => Employee::where('client_id', $clientId)->count(),
            'activeEmployees' => Employee::where('client_id', $clientId)->where('status', 'active')->count(),
            'totalDepartments' => Department::where('client_id', $clientId)->count(),
            'totalZones' => Zone::where('client_id', $clientId)->count(),
            'totalDevices' => Device::where('client_id', $clientId)->count(),
            'recentlySyncedDevices' => Device::where('client_id', $clientId)
                ->whereNotNull('last_sync')
                ->where('last_sync', '>=', Carbon::now()->subDay())
                ->count(),
        ]);
    }

    public function getClientDetails($clientId)
    {
        // Vérifier que l'utilisateur a accès à ce client
        $client = Client::where('id', $clientId)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        $details = [
            'client' => $client,
            'stats' => [
                'employees' => Employee::where('client_id', $clientId)->count(),
                'zones' => Zone::where('client_id', $clientId)->count(),
                'departments' => Department::where('client_id', $clientId)->count(),
                'devices' => Device::where('client_id', $clientId)->count(),
                'active_employees' => Employee::where('client_id', $clientId)->where('status', 'active')->count(),
                'inactive_employees' => Employee::where('client_id', $clientId)->where('status', 'inactive')->count(),
                'created_at' => $client->created_at->format('d/m/Y H:i'),
                'is_active' => $client->is_active
            ]
        ];

        return response()->json($details);
    }
}