<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Client;
use App\Models\Device; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class DailyAttendanceController extends Controller
{
    /**
     * Afficher la page des pointages avec synchronisation automatique d'aujourd'hui
     */
    public function index(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client) {
            return redirect()->route('home')->with('error', 'Client non trouvé.');
        }
        
        // Récupérer les devices pour les filtres
        $devices = Device::where('client_id', $client->id)
            ->orderBy('terminal_name')
            ->get();
        
        // Récupérer les employés avec leurs codes pour le filtre
        $employees = Employee::where('client_id', $client->id)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '')
            ->orderBy('emp_code')
            ->get()
            ->map(function($employee) {
                $fullName = $employee->first_name ?? '';
                if ($employee->last_name) {
                    $fullName .= ' ' . $employee->last_name;
                }
                $fullName = trim($fullName) ?: 'Code: ' . $employee->emp_code;
                
                return [
                    'emp_code' => $employee->emp_code,
                    'full_name' => $fullName
                ];
            });
        
        // Données d'aujourd'hui par défaut (18-12-2025)
        $todayData = $this->getTodayData($client);
        
        return view('daily-attendance.index', compact('devices', 'employees', 'client', 'todayData'));
    }
    
    /**
     * Récupérer les données d'aujourd'hui depuis l'API
     */
    private function getTodayData($client)
    {
        try {
            // Utiliser la vraie date d'aujourd'hui : 18-12-2025
           $today = Carbon::today(); // Système détermine la date
        $startTime = $today->startOfDay()->format('Y-m-d H:i:s');
        $endTime = $today->endOfDay()->format('Y-m-d H:i:s');
        
        Log::info("Récupération données pour aujourd'hui (système): " . $today->format('d-m-Y'));
            
            // Récupérer le token d'authentification
            $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
            
            if (!$accessConfig || empty($accessConfig->general_token)) {
                Log::warning("Token d'accès non configuré pour client: " . $client->id);
                return [
                    'success' => false,
                    'message' => 'Token d\'accès non configuré',
                    'data' => []
                ];
            }
            
            $token = $accessConfig->general_token;
            
            // Récupérer tous les devices
            $devices = Device::where('client_id', $client->id)->get();
            
            if ($devices->isEmpty()) {
                Log::warning("Aucun device trouvé pour client: " . $client->id);
                return [
                    'success' => false,
                    'message' => 'Aucun device trouvé',
                    'data' => []
                ];
            }
            
            // Collecter toutes les transactions depuis l'API
            $allTransactions = collect();
            
            foreach ($devices as $device) {
                $deviceTransactions = $this->getDeviceTransactionsFromApi(
                    $device,
                    $startTime,
                    $endTime,
                    $token,
                    null
                );
                
                $allTransactions = $allTransactions->merge($deviceTransactions);
            }
            
            Log::info("Total transactions récupérées: " . $allTransactions->count());
            
            if ($allTransactions->isEmpty()) {
                return [
                    'success' => false,
                    'message' => 'Aucune transaction trouvée pour ' . $today->format('d-m-Y'),
                    'data' => []
                ];
            }
            
            // DEBUG: Afficher tous les emp_code de l'API
            $uniqueEmpCodes = $allTransactions->pluck('emp_code')->unique()->values();
            Log::info("Tous les emp_code de l'API (" . $uniqueEmpCodes->count() . "): " . $uniqueEmpCodes->implode(', '));
            
            // Récupérer tous les employés pour la correspondance
            $allEmployees = Employee::where('client_id', $client->id)
                ->whereNotNull('emp_code')
                ->where('emp_code', '!=', '')
                ->get();
            
            Log::info("Employés en base (" . $allEmployees->count() . "): " . $allEmployees->pluck('emp_code')->implode(', '));
            
            $employeesByCode = $allEmployees->keyBy('emp_code');
            
            // DEBUG: Vérifier la correspondance
            $matched = [];
            $unmatched = [];
            
            foreach ($uniqueEmpCodes as $apiEmpCode) {
                // Nettoyer l'emp_code (enlever espaces, etc.)
                $cleanEmpCode = trim($apiEmpCode);
                
                if (isset($employeesByCode[$cleanEmpCode])) {
                    $matched[] = $cleanEmpCode;
                } else {
                    $unmatched[] = $cleanEmpCode;
                    Log::warning("emp_code non trouvé en base: '" . $cleanEmpCode . "'");
                }
            }
            
            Log::info("Correspondance: " . count($matched) . " trouvés, " . count($unmatched) . " non trouvés");
            
            // Grouper et transformer les données - AFFICHER TOUS même sans correspondance
            $groupedData = $this->groupAndTransformData($allTransactions);
            
            // Formater pour l'affichage - AFFICHER TOUS
            $formattedData = $this->formatForDisplay($groupedData, $employeesByCode);
            
            return [
                'success' => true,
                'message' => 'Données récupérées avec succès',
                'date' => $today->format('d/m/Y'),
                'total_attendances' => count($formattedData),
                'matched_employees' => count($matched),
                'unmatched_employees' => count($unmatched),
                'unmatched_codes' => $unmatched, // Ajouter les codes non trouvés
                'data' => $formattedData
            ];
            
        } catch (\Exception $e) {
            Log::error('Erreur récupération données: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage(),
                'data' => []
            ];
        }
    }

    /**
     * Récupérer les données pour DataTables directement depuis l'API
     */
    public function getData(Request $request)
{
    try {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client) {
            return response()->json(['error' => 'Client non trouvé'], 404);
        }
        
        // Valider les paramètres
        $request->validate([
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date|after_or_equal:start_date',
            'emp_code' => 'nullable|string',
            'terminal_sn' => 'nullable|string'
        ]);
        
        // Récupérer les paramètres
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');
        $empCode = $request->input('emp_code');
        $terminalSn = $request->input('terminal_sn');
        
        // Si aucune date n'est fournie, utiliser aujourd'hui
        if (!$startDate && !$endDate) {
            $today = Carbon::today();
            $startDate = $today->format('Y-m-d');
            $endDate = $today->format('Y-m-d');
        } elseif ($startDate && !$endDate) {
            $endDate = $startDate;
        } elseif (!$startDate && $endDate) {
            $startDate = $endDate;
        }
        
        Log::info("Récupération données pour: " . $startDate . " à " . $endDate . 
                 ", emp_code: " . ($empCode ?: 'all') . 
                 ", terminal_sn: " . ($terminalSn ?: 'all'));
        
        // Convertir en format datetime pour l'API
        $startTime = Carbon::parse($startDate)->startOfDay()->format('Y-m-d H:i:s');
        $endTime = Carbon::parse($endDate)->endOfDay()->format('Y-m-d H:i:s');
        
        // Récupérer le token d'authentification
        $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
        
        if (!$accessConfig || empty($accessConfig->general_token)) {
            return response()->json(['error' => 'Token d\'accès non configuré'], 400);
        }
        
        $token = $accessConfig->general_token;
        
        // Récupérer les devices selon le filtre
        $devicesQuery = Device::where('client_id', $client->id);
        
        if ($terminalSn && $terminalSn !== 'all') {
            $devicesQuery->where('device_sn', $terminalSn);
        }
        
        $devices = $devicesQuery->get();
        
        if ($devices->isEmpty()) {
            return response()->json(['error' => 'Aucun device trouvé'], 400);
        }
        
        // Récupérer tous les employés pour la correspondance
        $employees = Employee::where('client_id', $client->id)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '')
            ->get()
            ->keyBy('emp_code');
        
        // Collecter toutes les transactions depuis l'API
        $allTransactions = collect();
        
        foreach ($devices as $device) {
            $deviceTransactions = $this->getDeviceTransactionsFromApi(
                $device,
                $startTime,
                $endTime,
                $token,
                $empCode
            );
            
            $allTransactions = $allTransactions->merge($deviceTransactions);
        }
        
        Log::info("Total transactions récupérées: " . $allTransactions->count());
        
        if ($allTransactions->isEmpty()) {
            return response()->json([
                'draw' => $request->input('draw', 1),
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => []
            ]);
        }
        
        // Grouper et transformer les données
        $groupedData = $this->groupAndTransformData($allTransactions);
        
        // Convertir en tableau pour DataTables
        $data = $this->formatForDataTables($groupedData, $employees);
        
        // Pagination manuelle pour DataTables
        $totalRecords = count($data);
        $start = $request->input('start', 0);
        $length = $request->input('length', 25);
        $pageData = array_slice($data, $start, $length);
        
        return response()->json([
            'draw' => $request->input('draw', 1),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords,
            'data' => $pageData
        ]);
        
    } catch (\Exception $e) {
        Log::error('Erreur récupération données pointages: ' . $e->getMessage());
        return response()->json(['error' => $e->getMessage()], 500);
    }
}
    
    /**
     * Récupérer les transactions d'un device depuis l'API
     */
    private function getDeviceTransactionsFromApi($device, $startTime, $endTime, $token, $empCode = null)
    {
        $page = 1;
        $limit = 500;
        $allTransactions = collect();
        $maxPages = 20;
        
        do {
            try {
                $apiParams = [
                    'page' => $page,
                    'limit' => $limit,
                    'terminal_sn' => $device->device_sn,
                    'start_time' => $startTime,
                    'end_time' => $endTime
                ];
                
                if ($empCode && $empCode !== 'all') {
                    $apiParams['emp_code'] = $empCode;
                }
                
                $response = Http::withHeaders([
                    'Authorization' => 'Token ' . $token,
                    'Accept' => 'application/json',
                ])->withOptions([
                    'verify' => false,
                    'timeout' => 60,
                ])->get('http://54.37.15.111/iclock/api/transactions/', $apiParams);
                
                if (!$response->successful()) {
                    Log::warning("Erreur API device {$device->device_sn}: " . $response->status());
                    break;
                }
                
                $data = $response->json();
                
                if (!isset($data['data']) || !is_array($data['data'])) {
                    break;
                }
                
                if (empty($data['data'])) {
                    break;
                }
                
                // Ajouter le device_sn à chaque transaction
                $transactions = collect($data['data'])->map(function($transaction) use ($device) {
                    $transaction['device_sn'] = $device->device_sn;
                    $transaction['device_name'] = $device->terminal_name ?: $device->device_sn;
                    return $transaction;
                });
                
                $allTransactions = $allTransactions->merge($transactions);
                
                $hasNextPage = !empty($data['next']);
                
                if (!$hasNextPage || $page >= $maxPages) {
                    break;
                }
                
                $page++;
                usleep(100000);
                
            } catch (\Exception $e) {
                Log::error("Erreur récupération device {$device->device_sn}: " . $e->getMessage());
                break;
            }
            
        } while (true);
        
        return $allTransactions;
    }
    
    /**
     * Grouper et transformer les données - MODIFIÉ pour afficher tous
     */
    private function groupAndTransformData($transactions)
    {
        $grouped = [];
        
        foreach ($transactions as $transaction) {
            $empCode = $transaction['emp_code'] ?? null;
            if (!$empCode) continue;
            
            // Nettoyer l'emp_code
            $empCode = trim($empCode);
            
            $punchTime = Carbon::parse($transaction['punch_time']);
            $dateStr = $punchTime->format('Y-m-d');
            $timeStr = $punchTime->format('H:i:s');
            
            if (!isset($grouped[$empCode])) {
                $grouped[$empCode] = [];
            }
            
            if (!isset($grouped[$empCode][$dateStr])) {
                $grouped[$empCode][$dateStr] = [
                    'arrival_time' => null,
                    'departure_time' => null,
                    'device_sn' => $transaction['device_sn'] ?? null,
                    'device_name' => $transaction['device_name'] ?? null
                ];
            }
            
            // Déterminer si c'est une arrivée ou un départ
            $hour = $punchTime->hour;
            $isArrival = ($hour < 14);
            
            if ($isArrival) {
                if (!$grouped[$empCode][$dateStr]['arrival_time'] || 
                    $timeStr < $grouped[$empCode][$dateStr]['arrival_time']) {
                    $grouped[$empCode][$dateStr]['arrival_time'] = $timeStr;
                }
            } else {
                if (!$grouped[$empCode][$dateStr]['departure_time'] || 
                    $timeStr > $grouped[$empCode][$dateStr]['departure_time']) {
                    $grouped[$empCode][$dateStr]['departure_time'] = $timeStr;
                }
            }
        }
        
        return $grouped;
    }
    
    /**
     * Formater les données pour DataTables - MODIFIÉ pour afficher tous
     */
   private function formatForDataTables($groupedData, $employees)
{
    $formattedData = [];
    
    foreach ($groupedData as $empCode => $dates) {
        foreach ($dates as $dateStr => $attendanceData) {
            // Récupérer les informations de l'employé (peut être null)
            $employee = $employees[$empCode] ?? null;
            
            // Calculer le temps de travail en HEURES
            $totalWorkHours = null;
            if ($attendanceData['arrival_time'] && $attendanceData['departure_time']) {
                try {
                    $arrival = Carbon::createFromFormat('H:i:s', $attendanceData['arrival_time']);
                    $departure = Carbon::createFromFormat('H:i:s', $attendanceData['departure_time']);
                    if ($departure > $arrival) {
                        // Convertir les minutes en heures avec 2 décimales
                        $totalWorkMinutes = $departure->diffInMinutes($arrival);
                        $totalWorkHours = round($totalWorkMinutes / 60, 2);
                    }
                } catch (\Exception $e) {
                    // Ignorer
                }
            }
            
            // Déterminer le statut
            $status = 'present';
            if (!$attendanceData['arrival_time'] && !$attendanceData['departure_time']) {
                $status = 'absent';
            }
            
            // Construire le nom complet
            $fullName = 'Non enregistré';
            if ($employee) {
                $fullName = $employee->first_name ?? '';
                if ($employee->last_name) {
                    $fullName .= ' ' . $employee->last_name;
                }
                $fullName = trim($fullName) ?: 'Employé ' . $empCode;
            }
            
            $formattedData[] = [
                'date' => $dateStr,
                'employee' => [
                    'first_name' => $employee->first_name ?? '',
                    'last_name' => $employee->last_name ?? '',
                    'emp_code' => $empCode,
                    'full_name' => $fullName
                ],
                'emp_code' => $empCode,
                'arrival_time' => $attendanceData['arrival_time'],
                'departure_time' => $attendanceData['departure_time'],
                'total_work_hours' => $totalWorkHours, // Changé de minutes à heures
                'status' => $status,
                'observation' => $attendanceData['device_name'] ? 'Terminal: ' . $attendanceData['device_name'] : null,
                'employee_found' => $employee ? 'yes' : 'no'
            ];
        }
    }
    
    // Trier par date décroissante
    usort($formattedData, function($a, $b) {
        return strcmp($b['date'], $a['date']);
    });
    
    return $formattedData;
}

private function formatForDisplay($groupedData, $employees)
{
    $formattedData = [];
    
    foreach ($groupedData as $empCode => $dates) {
        foreach ($dates as $dateStr => $attendanceData) {
            $employee = $employees[$empCode] ?? null;
            
            // Calculer le temps de travail en HEURES
            $totalWorkHours = null;
            if ($attendanceData['arrival_time'] && $attendanceData['departure_time']) {
                try {
                    $arrival = Carbon::createFromFormat('H:i:s', $attendanceData['arrival_time']);
                    $departure = Carbon::createFromFormat('H:i:s', $attendanceData['departure_time']);
                    if ($departure > $arrival) {
                        $totalWorkMinutes = $departure->diffInMinutes($arrival);
                        $totalWorkHours = round($totalWorkMinutes / 60, 2);
                    }
                } catch (\Exception $e) {
                    // Ignorer
                }
            }
            
            $fullName = 'Non enregistré';
            if ($employee) {
                $fullName = $employee->first_name ?? '';
                if ($employee->last_name) {
                    $fullName .= ' ' . $employee->last_name;
                }
                $fullName = trim($fullName) ?: 'Employé ' . $empCode;
            }
            
            $formattedData[] = [
                'date' => $dateStr,
                'emp_code' => $empCode,
                'full_name' => $fullName,
                'arrival_time' => $attendanceData['arrival_time'],
                'departure_time' => $attendanceData['departure_time'],
                'total_work_hours' => $totalWorkHours, // Changé
                'device_name' => $attendanceData['device_name'],
                'employee_found' => $employee ? 'oui' : 'non'
            ];
        }
    }
    
    return $formattedData;
}
    
    
    /**
     * Récupérer le statut (maintenant basé sur l'API)
     */
    public function syncStatus(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json([
                    'client_name' => 'Non associé',
                    'last_sync' => 'N/A',
                    'current_date' => date('d/m/Y')
                ]);
            }
            
            // Récupérer les données d'aujourd'hui
            $todayData = $this->getTodayData($client);
            
            return response()->json([
                'client_name' => $client->name,
                'last_sync' => 'Direct API',
                'current_date' => date('d/m/Y'),
                'today_count' => $todayData['success'] ? count($todayData['data']) : 0,
                'today_message' => $todayData['message']
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'client_name' => 'Erreur',
                'last_sync' => 'N/A',
                'current_date' => date('d/m/Y')
            ]);
        }
    }
    
    /**
     * Récupérer un employé par son code
     */
    public function getEmployeeByCode(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client || !$request->has('emp_code')) {
            return response()->json(null);
        }
        
        $employee = Employee::where('client_id', $client->id)
            ->where('emp_code', $request->emp_code)
            ->first();
            
        if ($employee) {
            // Construire le nom complet
            $fullName = $employee->first_name ?? '';
            if ($employee->last_name) {
                $fullName .= ' ' . $employee->last_name;
            }
            $fullName = trim($fullName) ?: 'Employé ' . $employee->emp_code;
            
            return response()->json([
                'id' => $employee->id,
                'employee_id' => $employee->employee_id,
                'emp_code' => $employee->emp_code,
                'first_name' => $employee->first_name,
                'last_name' => $employee->last_name,
                'full_name' => $fullName
            ]);
        }
        
        return response()->json(null);
    }
}