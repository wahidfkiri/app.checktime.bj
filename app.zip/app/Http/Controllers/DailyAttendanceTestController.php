<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Client;
use App\Models\Device; 
use App\Models\DailyAttendance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use Carbon\Carbon;

class DailyAttendanceController extends Controller
{
    /**
     * Afficher la page des pointages
     */
    public function index(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client) {
            return redirect()->route('home')->with('error', 'Client non trouvé.');
        }
        
        // Récupérer les devices pour les filtres
        $devices = Device::where('client_id', $client->id)
            ->orderBy('terminal_name')
            ->get();
        
        // Récupérer les emp_codes uniques pour le filtre
        $employeeCodes = Employee::where('client_id', $client->id)
            ->whereNotNull('emp_code')
            ->where('emp_code', '!=', '')
            ->orderBy('emp_code')
            ->pluck('emp_code')
            ->unique()
            ->values()
            ->toArray();
        
        // Récupérer le statut de synchronisation
        $clientId = $client->id;
        
        $lastSync = DailyAttendance::where('client_id', $clientId)
            ->orderBy('updated_at', 'desc')
            ->value('updated_at');
            
        $totalAttendances = DailyAttendance::where('client_id', $clientId)->count();
        
        // Formater la date de dernière synchronisation
        if ($lastSync) {
            $lastSync = Carbon::parse($lastSync)->format('d/m/Y H:i');
        } else {
            $lastSync = 'Jamais';
        }
        
        return view('daily-attendance.index', compact('devices', 'employeeCodes', 'client', 'lastSync', 'totalAttendances'));
    }

    /**
     * Récupérer les données pour DataTables
     */
    public function getData(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client) {
            return response()->json(['error' => 'Client non trouvé'], 404);
        }
        
        $query = DailyAttendance::with('employee')
            ->where('client_id', $client->id);
            
        // Filtrer par code employé si spécifié
        if ($request->has('emp_code') && !empty($request->emp_code) && $request->emp_code !== 'all') {
            $query->whereHas('employee', function($q) use ($request) {
                $q->where('emp_code', $request->emp_code);
            });
        }
        
        // Filtrer par date si spécifié
        if ($request->has('date') && !empty($request->date)) {
            $query->whereDate('date', $request->date);
        }
        
        // Filtrer par période si spécifiée
        if ($request->has('start_date') && !empty($request->start_date) && 
            $request->has('end_date') && !empty($request->end_date)) {
            $query->whereBetween('date', [$request->start_date, $request->end_date]);
        }
        
        return DataTables::of($query)
            ->addIndexColumn()
            ->editColumn('employee.emp_code', function($attendance) {
                return $attendance->employee ? $attendance->employee->emp_code : '-';
            })
            ->editColumn('employee.full_name', function($attendance) {
                return $attendance->employee ? 
                    $attendance->employee->first_name . ' ' . $attendance->employee->last_name : 
                    'N/A';
            })
            ->make(true);
    }

    /**
     * Synchroniser avec l'API externe - RÉCUPÉRATION COMPLÈTE
     */
    public function sync(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client non trouvé.'
                ]);
            }
            
            // Valider les paramètres
            $request->validate([
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
                'terminal_sn' => 'nullable|string',
                'emp_code' => 'nullable|string'
            ]);
            
            // Récupérer les paramètres
            $startDate = $request->input('start_date');
            $endDate = $request->input('end_date');
            $terminalSn = $request->input('terminal_sn');
            $empCode = $request->input('emp_code');
            
            // Si aucune date n'est fournie, utiliser aujourd'hui
            if (!$startDate && !$endDate) {
                $startDate = Carbon::today()->format('Y-m-d');
                $endDate = Carbon::today()->format('Y-m-d');
            } elseif ($startDate && !$endDate) {
                $endDate = $startDate;
            } elseif (!$startDate && $endDate) {
                $startDate = $endDate;
            }
            
            // Convertir en format datetime pour l'API
            $startTime = Carbon::parse($startDate)->startOfDay()->format('Y-m-d H:i:s');
            $endTime = Carbon::parse($endDate)->endOfDay()->format('Y-m-d H:i:s');
            
            // Récupérer le token d'authentification
            $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
            
            if (!$accessConfig || empty($accessConfig->general_token)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Token d\'accès non configuré pour ce client.'
                ]);
            }
            
            $token = $accessConfig->general_token;
            
            // Récupérer les devices selon le filtre
            $devicesQuery = Device::where('client_id', $client->id);
            
            if ($terminalSn && $terminalSn !== 'all') {
                $devicesQuery->where('device_sn', $terminalSn);
            }
            
            $devices = $devicesQuery->get();
            
            if ($devices->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Aucun device trouvé pour ce client.'
                ]);
            }
            
            $totalSynced = 0;
            $totalInserted = 0;
            $syncDetails = [];
            $employeeMismatches = [];
            
            // Pour chaque device, récupérer les transactions
            foreach ($devices as $device) {
                $deviceSyncResult = $this->syncDeviceTransactions(
                    $client, 
                    $device, 
                    $startTime, 
                    $endTime, 
                    $token,
                    $empCode
                );
                
                $totalSynced += $deviceSyncResult['synced'];
                $totalInserted += $deviceSyncResult['inserted'];
                $employeeMismatches = array_merge($employeeMismatches, $deviceSyncResult['mismatches']);
                
                $syncDetails[] = [
                    'device' => $device->terminal_name . ' (' . $device->device_sn . ')',
                    'synced' => $deviceSyncResult['synced'],
                    'inserted' => $deviceSyncResult['inserted'],
                    'mismatches' => count($deviceSyncResult['mismatches']),
                    'pages_processed' => $deviceSyncResult['pages_processed']
                ];
            }
            
            // Message de résultat
            $dateMessage = ($startDate == $endDate) 
                ? "pour la date du " . Carbon::parse($startDate)->format('d/m/Y')
                : "du " . Carbon::parse($startDate)->format('d/m/Y') . " au " . Carbon::parse($endDate)->format('d/m/Y');
            
            $filterMessage = '';
            if ($terminalSn && $terminalSn !== 'all') {
                $filterMessage .= ", terminal: $terminalSn";
            }
            if ($empCode && $empCode !== 'all') {
                $filterMessage .= ", employé code: $empCode";
            }
            
            $resultMessage = "Synchronisation terminée $dateMessage$filterMessage. $totalSynced transactions récupérées, $totalInserted nouveaux pointages insérés.";
            
            // Ajouter un avertissement si des emp_codes ne correspondent pas
            if (!empty($employeeMismatches)) {
                $uniqueMismatches = array_unique($employeeMismatches);
                $resultMessage .= " Attention: " . count($uniqueMismatches) . " codes employé de l'API ne correspondent à aucun employé dans la base: " . implode(', ', array_slice($uniqueMismatches, 0, 10));
                if (count($uniqueMismatches) > 10) {
                    $resultMessage .= " et " . (count($uniqueMismatches) - 10) . " autres...";
                }
            }
            
            return response()->json([
                'success' => true,
                'message' => $resultMessage,
                'data' => [
                    'synced' => $totalSynced,
                    'inserted' => $totalInserted,
                    'start_date' => $startDate,
                    'end_date' => $endDate,
                    'terminal_sn' => $terminalSn,
                    'emp_code' => $empCode,
                    'details' => $syncDetails,
                    'mismatches' => array_unique($employeeMismatches),
                    'total_pages_processed' => array_sum(array_column($syncDetails, 'pages_processed'))
                ]
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Erreur de validation.',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            Log::error('Erreur synchronisation pointages: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Erreur lors de la synchronisation : ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Synchroniser les transactions d'un device spécifique - RÉCUPÉRATION DE TOUTES LES PAGES
     */
    private function syncDeviceTransactions($client, $device, $startTime, $endTime, $token, $empCode = null)
    {
        $page = 1;
        $limit = 100;
        $syncedCount = 0;
        $insertedCount = 0;
        $mismatches = [];
        $pagesProcessed = 0;
        $maxRetries = 3;
        
        // Pré-chercher les employés par emp_code pour optimiser
        $employeesByCode = [];
        $allEmployees = Employee::where('client_id', $client->id)->get();
        foreach ($allEmployees as $employee) {
            if ($employee->emp_code) {
                $employeesByCode[$employee->emp_code] = $employee;
            }
        }
        
        // Variable pour suivre la dernière transaction traitée
        $lastProcessedTransactionId = null;
        $consecutiveEmptyPages = 0;
        
        do {
            $retryCount = 0;
            $pageSuccess = false;
            
            while ($retryCount < $maxRetries && !$pageSuccess) {
                try {
                    // Préparer les paramètres API
                    $apiParams = [
                        'page' => $page,
                        'limit' => $limit,
                        'terminal_sn' => $device->device_sn,
                        'start_time' => $startTime,
                        'end_time' => $endTime
                    ];
                    
                    // Ajouter le filtre emp_code si spécifié et différent de "all"
                    if ($empCode && $empCode !== 'all') {
                        $apiParams['emp_code'] = $empCode;
                    }
                    
                    Log::info("Device {$device->device_sn} - Page $page - Paramètres: " . json_encode($apiParams));
                    
                    // Appeler l'API externe
                    $response = Http::withHeaders([
                        'Authorization' => 'Token ' . $token,
                        'Accept' => 'application/json',
                    ])->withOptions([
                        'verify' => false,
                        'timeout' => 120, // Augmenter le timeout pour les grosses requêtes
                    ])->get('http://54.37.15.111/iclock/api/transactions/', $apiParams);
                    
                    if (!$response->successful()) {
                        Log::error('Erreur API pour device ' . $device->device_sn . ' page ' . $page . ': ' . $response->status() . ' - ' . $response->body());
                        
                        if ($response->status() === 429) { // Too Many Requests
                            $retryAfter = $response->header('Retry-After') ?? 5;
                            Log::warning("Rate limit atteint, attente de {$retryAfter} secondes...");
                            sleep($retryAfter);
                            $retryCount++;
                            continue;
                        }
                        
                        if ($response->status() >= 500) {
                            // Erreur serveur, réessayer
                            $retryCount++;
                            sleep(2); // Attendre 2 secondes avant de réessayer
                            continue;
                        }
                        
                        break; // Autre erreur, sortir
                    }
                    
                    $data = $response->json();
                    
                    if (!isset($data['data']) || !is_array($data['data'])) {
                        Log::error('Format de réponse invalide pour device: ' . $device->device_sn . ' page ' . $page);
                        break;
                    }
                    
                    $transactionsCount = count($data['data']);
                    Log::info("Device {$device->device_sn} - Page {$page}: {$transactionsCount} transactions");
                    
                    // Si pas de données, vérifier si c'est la fin
                    if ($transactionsCount === 0) {
                        $consecutiveEmptyPages++;
                        Log::info("Page {$page} vide, pages vides consécutives: {$consecutiveEmptyPages}");
                        
                        // Si 3 pages vides consécutives, arrêter
                        if ($consecutiveEmptyPages >= 3) {
                            Log::info("3 pages vides consécutives, arrêt de la synchronisation pour device: " . $device->device_sn);
                            break 2; // Sortir des deux boucles
                        }
                        
                        $pageSuccess = true;
                        $page++;
                        $pagesProcessed++;
                        continue;
                    }
                    
                    $consecutiveEmptyPages = 0; // Réinitialiser le compteur
                    
                    // Grouper les transactions par employé et date
                    $groupedTransactions = $this->groupTransactionsByEmployeeAndDate($data['data']);
                    
                    // Traiter chaque groupe
                    foreach ($groupedTransactions as $empCodeFromApi => $dates) {
                        $syncedCount += count($dates);
                        
                        // Trouver l'employé par emp_code
                        $employee = $employeesByCode[$empCodeFromApi] ?? null;
                        
                        if (!$employee) {
                            Log::warning('Employé non trouvé pour emp_code: ' . $empCodeFromApi);
                            $mismatches[] = $empCodeFromApi;
                            continue;
                        }
                        
                        // Pour chaque date, créer ou mettre à jour le pointage
                        foreach ($dates as $dateStr => $times) {
                            $attendanceData = $this->createAttendanceData(
                                $client->id,
                                $employee->id, // Utiliser employees.id
                                $dateStr,
                                $times['arrival'] ?? null,
                                $times['departure'] ?? null,
                                $device
                            );
                            
                            if ($attendanceData) {
                                $inserted = $this->saveOrUpdateAttendance($attendanceData, $client->id);
                                if ($inserted) {
                                    $insertedCount++;
                                }
                            }
                        }
                    }
                    
                    // Vérifier s'il y a une page suivante
                    $hasNextPage = !empty($data['next']);
                    $totalCount = $data['count'] ?? 0;
                    
                    Log::info("Device {$device->device_sn} - Page {$page} traitée. Total API: {$totalCount}, Suivante: " . ($hasNextPage ? 'Oui' : 'Non'));
                    
                    $pageSuccess = true;
                    $pagesProcessed++;
                    
                    // Passer à la page suivante si elle existe
                    if ($hasNextPage) {
                        $page++;
                        
                        // Petite pause pour éviter de surcharger l'API
                        usleep(300000); // 0.3 seconde
                    } else {
                        // Pas de page suivante, on a fini
                        break 2; // Sortir des deux boucles
                    }
                    
                } catch (\Exception $e) {
                    Log::error('Erreur sync device ' . $device->device_sn . ' page ' . $page . ': ' . $e->getMessage());
                    $retryCount++;
                    
                    if ($retryCount < $maxRetries) {
                        Log::info("Nouvelle tentative ($retryCount/$maxRetries) dans 3 secondes...");
                        sleep(3); // Attendre 3 secondes avant de réessayer
                    }
                }
            }
            
            // Si toutes les tentatives ont échoué
            if (!$pageSuccess) {
                Log::error("Échec après {$maxRetries} tentatives pour device {$device->device_sn} page {$page}");
                break;
            }
            
            // Limite de sécurité: maximum 1000 pages pour éviter les boucles infinies
            if ($page > 1000) {
                Log::warning('Limite de sécurité atteinte: 1000 pages maximum pour device: ' . $device->device_sn);
                break;
            }
            
        } while (true); // La condition de sortie est gérée par break dans la boucle
        
        Log::info("Device {$device->device_sn}: {$syncedCount} transactions, {$insertedCount} nouveaux/MAJ pointages, " . 
                  count($mismatches) . " mismatches, {$pagesProcessed} pages traitées");
        
        return [
            'synced' => $syncedCount,
            'inserted' => $insertedCount,
            'mismatches' => $mismatches,
            'pages_processed' => $pagesProcessed
        ];
    }
    
    /**
     * Grouper les transactions par employé et date
     */
    private function groupTransactionsByEmployeeAndDate($transactions)
    {
        $grouped = [];
        
        foreach ($transactions as $transaction) {
            $empCode = $transaction['emp_code'] ?? null;
            if (!$empCode) continue;
            
            $punchTime = Carbon::parse($transaction['punch_time']);
            $dateStr = $punchTime->format('Y-m-d');
            $timeStr = $punchTime->format('H:i:s');
            
            // Déterminer si c'est une arrivée ou un départ
            $hour = $punchTime->hour;
            $isArrival = ($hour < 12); // Arrivée avant 12h
            
            if (!isset($grouped[$empCode])) {
                $grouped[$empCode] = [];
            }
            
            if (!isset($grouped[$empCode][$dateStr])) {
                $grouped[$empCode][$dateStr] = [
                    'arrival' => null,
                    'departure' => null
                ];
            }
            
            // Garder la première arrivée et le dernier départ
            if ($isArrival) {
                if (!$grouped[$empCode][$dateStr]['arrival'] || $timeStr < $grouped[$empCode][$dateStr]['arrival']) {
                    $grouped[$empCode][$dateStr]['arrival'] = $timeStr;
                }
            } else {
                if (!$grouped[$empCode][$dateStr]['departure'] || $timeStr > $grouped[$empCode][$dateStr]['departure']) {
                    $grouped[$empCode][$dateStr]['departure'] = $timeStr;
                }
            }
        }
        
        return $grouped;
    }
    
    /**
     * Créer les données de pointage
     */
    private function createAttendanceData($clientId, $employeeId, $date, $arrivalTime, $departureTime, $device)
    {
        // Calculer le temps de travail si on a les deux heures
        $totalWorkMinutes = null;
        if ($arrivalTime && $departureTime) {
            try {
                $arrival = Carbon::createFromFormat('H:i:s', $arrivalTime);
                $departure = Carbon::createFromFormat('H:i:s', $departureTime);
                if ($departure > $arrival) {
                    $totalWorkMinutes = $departure->diffInMinutes($arrival);
                }
            } catch (\Exception $e) {
                Log::error('Erreur calcul temps travail: ' . $e->getMessage());
            }
        }
        
        return [
            'client_id' => $clientId,
            'employee_id' => $employeeId, // employees.id
            'date' => $date,
            'arrival_time' => $arrivalTime,
            'departure_time' => $departureTime,
            'total_work_minutes' => $totalWorkMinutes,
            'late_minutes' => 0,
            'early_leave_minutes' => 0,
            'status' => ($arrivalTime || $departureTime) ? 'present' : 'absent',
            'observation' => 'Terminal: ' . ($device->terminal_name ?: $device->device_sn) // Changé Device → Terminal
        ];
    }
    
    /**
     * Sauvegarder ou mettre à jour un pointage
     */
    private function saveOrUpdateAttendance($attendanceData, $clientId)
    {
        try {
            // Rechercher un pointage existant pour cet employé à cette date
            $existingAttendance = DailyAttendance::where('client_id', $clientId)
                ->where('employee_id', $attendanceData['employee_id'])
                ->where('date', $attendanceData['date'])
                ->first();
            
            if ($existingAttendance) {
                // Mettre à jour l'existant
                $updated = false;
                
                if ($attendanceData['arrival_time'] && (!$existingAttendance->arrival_time || $attendanceData['arrival_time'] < $existingAttendance->arrival_time)) {
                    $existingAttendance->arrival_time = $attendanceData['arrival_time'];
                    $updated = true;
                }
                
                if ($attendanceData['departure_time'] && (!$existingAttendance->departure_time || $attendanceData['departure_time'] > $existingAttendance->departure_time)) {
                    $existingAttendance->departure_time = $attendanceData['departure_time'];
                    $updated = true;
                }
                
                // Recalculer le temps de travail si on a les deux heures
                if ($existingAttendance->arrival_time && $existingAttendance->departure_time) {
                    try {
                        $arrival = Carbon::createFromFormat('H:i:s', $existingAttendance->arrival_time);
                        $departure = Carbon::createFromFormat('H:i:s', $existingAttendance->departure_time);
                        if ($departure > $arrival) {
                            $existingAttendance->total_work_minutes = $departure->diffInMinutes($arrival);
                        }
                    } catch (\Exception $e) {
                        // Ignorer l'erreur de calcul
                    }
                }
                
                if ($updated) {
                    $existingAttendance->observation = $attendanceData['observation'];
                    $existingAttendance->save();
                    Log::debug('Pointage mis à jour:', [
                        'employee_id' => $attendanceData['employee_id'],
                        'date' => $attendanceData['date'],
                        'arrival' => $attendanceData['arrival_time'],
                        'departure' => $attendanceData['departure_time']
                    ]);
                    return true;
                }
                
                return false; // Pas de mise à jour nécessaire
            } else {
                // Créer un nouveau pointage
                DailyAttendance::create($attendanceData);
                Log::debug('Nouveau pointage créé:', [
                    'employee_id' => $attendanceData['employee_id'],
                    'date' => $attendanceData['date'],
                    'arrival' => $attendanceData['arrival_time'],
                    'departure' => $attendanceData['departure_time']
                ]);
                return true;
            }
            
        } catch (\Exception $e) {
            Log::error('Erreur sauvegarde pointage: ' . $e->getMessage(), [
                'attendance_data' => $attendanceData
            ]);
            return false;
        }
    }

    /**
     * Récupérer le statut de synchronisation (AJAX)
     */
    public function syncStatus(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json([
                    'client_name' => 'Non associé',
                    'last_sync' => 'N/A',
                    'total_attendances' => 0
                ]);
            }
            
            $lastSync = DailyAttendance::where('client_id', $client->id)
                ->orderBy('updated_at', 'desc')
                ->value('updated_at');
                
            $totalAttendances = DailyAttendance::where('client_id', $client->id)->count();
            
            return response()->json([
                'client_name' => $client->name,
                'last_sync' => $lastSync ? Carbon::parse($lastSync)->format('d/m/Y H:i') : 'Jamais',
                'total_attendances' => $totalAttendances
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'client_name' => 'Erreur',
                'last_sync' => 'N/A',
                'total_attendances' => 0
            ]);
        }
    }
    
    /**
     * Tester la connexion API
     */
    public function testSync(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client non trouvé.'
                ]);
            }
            
            // Récupérer le token d'authentification
            $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
            
            if (!$accessConfig || empty($accessConfig->general_token)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Token d\'accès non configuré pour ce client.'
                ]);
            }
            
            $token = $accessConfig->general_token;
            
            // Paramètres statiques pour le test
            $testParams = [
                'page' => 1,
                'limit' => 5,
                'terminal_sn' => 'BSTI230914001',
                'start_time' => Carbon::today()->format('Y-m-d 00:00:00'),
                'end_time' => Carbon::today()->format('Y-m-d 23:59:59')
            ];
            
            Log::info('Test API avec paramètres:', $testParams);
            
            // Appeler l'API externe
            $response = Http::withHeaders([
                'Authorization' => 'Token ' . $token,
                'Accept' => 'application/json',
            ])->withOptions([
                'verify' => false,
                'timeout' => 30,
            ])->get('http://54.37.15.111/iclock/api/transactions/', $testParams);
            
            // Log de la réponse
            Log::info('Status de la réponse API:', ['status' => $response->status()]);
            
            if (!$response->successful()) {
                $errorDetails = [
                    'status' => $response->status(),
                    'body' => $response->body(),
                    'headers' => $response->headers()
                ];
                
                Log::error('Erreur API test:', $errorDetails);
                
                return response()->json([
                    'success' => false,
                    'message' => 'Erreur API: ' . $response->status(),
                    'details' => $errorDetails
                ]);
            }
            
            $data = $response->json();
            
            return response()->json([
                'success' => true,
                'message' => 'Test API réussi',
                'data' => [
                    'params_utilises' => $testParams,
                    'reponse_api' => [
                        'count' => $data['count'] ?? 'N/A',
                        'next' => $data['next'] ?? 'N/A',
                        'previous' => $data['previous'] ?? 'N/A',
                        'msg' => $data['msg'] ?? 'N/A',
                        'code' => $data['code'] ?? 'N/A',
                        'nombre_transactions' => count($data['data'] ?? [])
                    ],
                    'exemple_transaction' => !empty($data['data']) ? $data['data'][0] : null
                ]
            ]);

        } catch (\Exception $e) {
            Log::error('Erreur test API: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'message' => 'Exception: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Debug: Vérifier la correspondance des emp_codes
     */
    public function debugEmpCodes(Request $request)
    {
        try {
            $client = Client::where('user_id', auth()->user()->id)->first();
            
            if (!$client) {
                return response()->json([
                    'success' => false,
                    'message' => 'Client non trouvé.'
                ]);
            }
            
            // Récupérer quelques transactions de l'API
            $accessConfig = DB::table('access_configs')->where('client_id', $client->id)->first();
            
            if (!$accessConfig || empty($accessConfig->general_token)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Token non configuré.'
                ]);
            }
            
            $token = $accessConfig->general_token;
            
            $response = Http::withHeaders([
                'Authorization' => 'Token ' . $token,
                'Accept' => 'application/json',
            ])->withOptions([
                'verify' => false,
                'timeout' => 30,
            ])->get('http://54.37.15.111/iclock/api/transactions/', [
                'page' => 1,
                'limit' => 50,
                'start_time' => Carbon::today()->format('Y-m-d 00:00:00'),
                'end_time' => Carbon::today()->format('Y-m-d 23:59:59')
            ]);
            
            if (!$response->successful()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Erreur API: ' . $response->status()
                ]);
            }
            
            $apiData = $response->json();
            $apiEmpCodes = collect($apiData['data'] ?? [])->pluck('emp_code')->filter()->unique()->values();
            
            // Récupérer les emp_codes de la base
            $dbEmpCodes = Employee::where('client_id', $client->id)
                ->whereNotNull('emp_code')
                ->where('emp_code', '!=', '')
                ->pluck('emp_code')
                ->map(function($code) {
                    return (string) $code;
                })
                ->unique()
                ->values();
            
            // Trouver les correspondances
            $matches = [];
            $mismatches = [];
            
            foreach ($apiEmpCodes as $apiCode) {
                $found = false;
                foreach ($dbEmpCodes as $dbCode) {
                    if ((string)$apiCode === (string)$dbCode) {
                        $matches[] = $apiCode;
                        $found = true;
                        break;
                    }
                }
                if (!$found) {
                    $mismatches[] = $apiCode;
                }
            }
            
            return response()->json([
                'success' => true,
                'data' => [
                    'api_emp_codes' => $apiEmpCodes,
                    'db_emp_codes' => $dbEmpCodes,
                    'matches' => $matches,
                    'mismatches' => $mismatches,
                    'counts' => [
                        'api_total' => count($apiEmpCodes),
                        'db_total' => count($dbEmpCodes),
                        'matches_count' => count($matches),
                        'mismatches_count' => count($mismatches)
                    ]
                ]
            ]);
            
        } catch (\Exception $e) {
            Log::error('Debug emp_codes error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Erreur: ' . $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Récupérer un employé par son code
     */
    public function getEmployeeByCode(Request $request)
    {
        $client = Client::where('user_id', auth()->user()->id)->first();
        
        if (!$client || !$request->has('emp_code')) {
            return response()->json(null);
        }
        
        $employee = Employee::where('client_id', $client->id)
            ->where('emp_code', $request->emp_code)
            ->first(['id', 'employee_id', 'emp_code', 'first_name', 'last_name']);
            
        return response()->json($employee);
    }
}